# 官方依据与检索登记

本清单在 **2026-10-03** 联网核对，仅作为调查规划的证据入口。调用 Skill 时仍需核对任务日期有效版本和当地补充规范。未核实的发布日期记未知；检索日期不冒充发布/生效日期。多数网页可变更，正式项目应保存许可范围内的引用位置和数据版本。下述均为 WHO、CDC、ECDC 或国家/地方政府一手来源；内容仅作简要用途说明。

| ID | 官方来源与版本/日期 | 在本 Skill 中的用途 | 适用限制 |
|---|---|---|---|
| G01 | [WHO Global vector control response 2017–2030](https://tdr.who.int/publications/i/item/global-vector-control-response-2017-2030)，2017-07-01，ISBN 9789241512978 | 跨部门与综合媒介监测框架 | 战略框架，不是各城市统一执行阈值 |
| G02 | [WHO 疟疾监测、监测评价参考手册第二版](https://www.who.int/publications/i/item/9789240112476)，2025-07-10 | 按传播情境与地方层级设计疟疾监测 | 实施前需当地疟疾项目规范；[2018 年版网页](https://www.who.int/publications-detail-redirect/9789241565578)注明被第二版替代 |
| G03 | [ECDC 入侵蚊种监测指南](https://www.ecdc.europa.eu/en/publications-data/guidelines-surveillance-invasive-mosquitoes-europe)，2012-08-28 | 媒介引入/定殖调查及调查成本设计参考 | 历史方法学指南，不能单独作为当前疫情响应依据 |
| G04 | [ECDC 欧盟/欧洲经济区本地伊蚊相关病毒病指导](https://www.ecdc.europa.eu/en/publications-data/public-health-guidance-assessing-and-mitigating-risk-locally-acquired-aedes-borne)，2025-07-01 | 区分媒介适宜条件、输入与本地传播背景 | 适用 EU/EEA，不是全球法定响应分级 |
| G05 | [ECDC 蚊、白蛉、蠓和蜱野外采样方法](https://www.ecdc.europa.eu/en/publications-data/field-sampling-methods-mosquitoes-sandflies-biting-midges-and-ticks)，具体发布日期本次未确认 | 选择调查对象、时段、点位、方法和质量控制的专业入口 | 重点面向欧洲；本包不复制采样操作流程 |
| G06 | [CDC West Nile Virus Surveillance and Control Guidelines](https://www.cdc.gov/west-nile-virus/php/surveillance-and-control-guidelines/index.html)，网页显示 2026-08-26 | 蚊媒、人群、动物与环境监测的关联设计 | 美国业务指导，需当地解释与本地阈值 |
| G07 | [CDC West Nile: Causes and How It Spreads](https://www.cdc.gov/west-nile-virus/causes/index.html)，2026-07-15 | 说明鸟—蚊循环及人通常为终末宿主，防止套用登革热人—蚊模式 | 不用于推定具体患者来源或城市当前病例 |
| G08 | [CDC Ixodes scapularis 与相关病原监测指南](https://www.cdc.gov/ticks/resources/TickSurveillance_Iscapularis-P.pdf)，具体发布日期本次未确认 | 特定蜱种、生命阶段、地点与有效调查努力量设计 | 美国与特定物种背景，不能视为全球蜱种通则 |
| G09 | [Copernicus ERA5 单层小时数据](https://cds.climate.copernicus.eu/datasets/reanalysis-era5-single-levels?tab=documentation)，持续更新数据集，DOI 10.24381/cds.adbb2d47 | 历史气象再分析和数据类别说明 | 格点再分析不是小区现场实测；延迟、许可和变量约定另核实 |
| C01 | [新加坡 NEA Dengue & Zika](https://www.nea.gov.sg/dengue-zika)，网页显示更新 2026-04-13 | Aedes、Gravitrap 与当地疾病资料入口 | 公开展示不等于取得底层数据许可；监测指标不能任意互换 |
| C02 | [里约市卫生局 Dengue—dados epidemiológicos](https://saude.prefeitura.rio/dengue-dados-epidemiologicos/)，动态页面 | 历史数据和 2025 年起 EpiRio 面板入口 | 统计定义、空间分母与修订规则需项目中检查 |
| C03 | [坦桑尼亚卫生部国家健康门户 NMCP](https://hmisportal.moh.go.tz/themes/nmcp)，动态页面 | 国家疟疾项目背景及资料线索 | 页面含历史目标，非达市当期观测；本次访问偶有超时 |
| C04 | [NYC Health Mosquito Control](https://www.nyc.gov/site/doh/health/health-topics/west-nile-virus-spray.page)，含 2026 年城市计划入口 | 城市监测、防控与通知程序资料入口 | 不将网页作业记录当所有街区风险；接口和许可需核实 |
| C05 | [法国公共卫生局 2026 年虫媒监测说明](https://www.santepubliquefrance.fr/les-actualites/arboviroses-en-2026-les-maladies-transmises-par-les-moustiques-continuent-leur-progression-cet-ete)，2026-08-14 | 当年全国监测背景及 Aedes/Culex 分支区分 | 全国信息不代表马赛所有社区；需大区和地方规则 |
| C06 | [马德里自治区 Leishmaniasis](https://www.comunidad.madrid/salud/leishmaniasis)，动态页面 | 白蛉、环境和动物相关部门协作背景 | 市与自治区/都会区不得混同，历史聚集不等于当前疫情 |
| C07 | [国家疾控局《关于依法做好重点虫媒传染病防控工作的通知》](https://www.ndcpa.gov.cn/jbkzzx/c100014/common/content/content_2042601950245457920.html)，2026-04-10 发布、2026-04-08 落款 | 宝安示例本地规则版本入口 | 不能成为其他国家/病种默认值；仍需核实本地补充规范 |

## 每次任务的来源登记字段

对实际用于结论的每条来源记录 `source_id / title / issuer / source_url_or_local_path / published_at / effective_at / retrieved_at / covered_period / jurisdiction / vector / pathogen / section_or_page / evidence_type / access_status / license / superseded_by / local_applicability / limitations`。

只有搜索摘要可见时标明 `access_status: search_excerpt_only`，不得声称已经核对全文关键条款。网页访问超时可在合理次数内重试，或使用同机构正式 PDF；不能把无法取得的关键规范补写成常识。国外指导与当地法规冲突时呈现冲突并交当地专业负责人判断，不暗中合并。

本清单没有给出任何城市的当下病例数或风险等级。未来真实调查必须获取该城市、该病种、该时段的资料后才形成具体研判。
