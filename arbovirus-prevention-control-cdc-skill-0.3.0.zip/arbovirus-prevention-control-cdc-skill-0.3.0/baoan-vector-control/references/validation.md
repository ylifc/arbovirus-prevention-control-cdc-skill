# 发布包运行验证与能力边界

本包是可运行的辅助研判 Skill，不是经前瞻校准的医学预测系统。以下为执行方法与验收标准，不代表本次测试已通过；实际运行结果应另存测试日期、命令、解释器版本及日志。

## 随包能力

1. 本地 TXT/MD、CSV、JSON、DOCX 和 XLSX 只读提取，保留原文定位、指纹、合并单元格和日期信息；原文命令、链接及表格公式不执行。
2. 结构化流调 JSON 校验，匿名病例去重、时段核验及未知状态保留。结构通过不证明医学事实已经复核。
3. Open-Meteo 公开模型备用联网天气；授权的规范 JSON/CSV 本地天气导入；完整自然日质控、日值及多时间窗汇总。
4. 两病分别按来源、场所及报告时间窗研判；P0—P3 工作优先级与规范条件候选独立保存，职业名及家庭人数不直接加分。
5. 对已接入的授权历史库按病种、街道、地点、职业、气候及交集比较，并区分回顾最终标签与判定时点可知资料。
6. 冻结本地资料、气象、画像、规则、解释器和代码指纹；生产重放离线，漂移停止，输出目录不可覆盖。
7. HTML 报告、风险及历史 CSV/JSON、气象 CSV 与质控、已核验坐标 GeoJSON、来源记录。HTML 转义，CSV 防公式注入。

## 发布包不提供的资源

- 不含真实病例、私有历史库、六年气象档案、既往个案报告或已冻结生产包。
- 不预登记任何私人 XLS 转换。未登记的 XLS 须在维护阶段核验本地转换；不会自行安装、执行 Office 或外传文件。
- 未配置历史库时明确报告“历史库未接入，历史病例与暴发数未知”，不把缺资源当零病例。已有指针但资源缺失或漂移时应报错。
- 深圳官方鉴权 API、官方小区/站点映射、媒介监测、干预接口及完整人口分母尚需使用方接入。两个公共天气点是粗尺度背景。
- 不提供经过训练校准的概率预测器；`probability`、`uncertainty_interval`、`score_1_to_10` 保持 `null`。不自动确认传播链、解除措施或发布行政响应。

## 本地合成测试

需要 Python ≥3.11，运行依赖为标准库。在 `baoan-vector-control` 目录执行：

```bash
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 scripts/vector_control.py validate --input assets/example_input.json
python3 scripts/vector_control.py prepare --input assets/example_input.json --output /tmp/baoan-release-demo-bundle --weather none --history none
python3 scripts/vector_control.py run --lock /tmp/baoan-release-demo-bundle/lock.json --output /tmp/baoan-release-demo-result
python3 scripts/vector_control.py run --lock /tmp/baoan-release-demo-bundle/lock.json --output /tmp/baoan-release-demo-replay
```

示例文件完全合成；重复执行须更换输出目录。验收应检查：命令成功、报告保留天气和历史未知、规则与评分状态真实、同锁两次结构化输出一致、运行阶段无网络请求。不得将示例场所或人数解读为真实疫情。

## 自动天气验证

```bash
python3 scripts/vector_control.py analyze --input assets/example_input.json --output /tmp/baoan-release-weather-demo --weather auto --history none --weather-cache /tmp/baoan-release-weather-cache
```

必须检查 `provider_status`、`quality`、`errors`、`missing`、请求及取得时刻、来源、模型、实际格点与完整日覆盖；仅生成报告不代表天气取得成功。网络失败或发布延迟应保留原因和缺测，不能据此降低病例处置优先级。联网只发送已登记公共坐标、日期及天气变量，不发送姓名、地址、职业或原始材料。

## 历史资源接入验证

使用合成临时资源验证指纹、去重、来源时点、气候兼容、交集、自我排除和前后结果对照。部署真实资源时另按使用方权限及维护清单登记，不把真实资料纳入公开测试夹具。已配置资源缺失或指纹漂移应在联网前停止；冻结后原库变化不影响已核验快照重放。

## 必须保持的不变量

病例来源不明或地点模糊不伪造规范计数；缺天气不能抵消病例证据；同住不等于感染；职业换名但实际事实相同不得改变级别；活动时段为左闭右开并拒绝零长度。正式暴发事件缺证据时保持未知，候选配对数不是传播链数。

同一冻结锁只能使用匹配的解释器、代码、配置和输入。发生漂移须停止，在维护阶段生成新版本及新锁，不能绕过检查、覆盖 READY 资源或在生产阶段联网修复。冻结包会包含原始材料及历史快照，应置于授权本地目录，不能随程序再次发布。

软件测试证明工程行为，不代替地方业务审核、独立时空验证或前瞻静默试运行。
