# 宝安流调输入契约

运行输入是经过事实复核的本地JSON。`assets/example_input.json` 是完整合成示例，所有人、场所、观察和证据均为虚构，不能用作真实风险判断。Schema见 `../schemas/input.schema.json`；运行时还检查交叉引用、日期、ID冲突和规范有效范围。结构校验不证明事实属实。

## 顶层与时间

`schema_version="1.0"`、`profile_id="baoan"`、`assessment_at`（带时区ISO时间）和至少一个 `sites` 为必填。集合包括 `cases, activities, households, observations, interventions, prior_risks`，缺省为空。未知顶层字段拒绝，避免拼写错误静默失效。

所有时间在引擎中转换为Asia/Shanghai。发病与报告日期格式YYYY-MM-DD，活动和观测为带时区ISO时间。未知用null，不猜测整点。活动起止任一个未知都保留待核；不能把诊断日填成发病日。`known_at`用于防止回放使用之后才得知的病例资料；原始来源本身的获知时间也必须由调查人员核对。

`source_documents`为 `[{"path":"本地材料路径","sha256":"可选的已有散列"}]`；相对路径相对结构化输入所在目录。prepare在任何天气请求前检查文件和散列，复制到私有冻结包。没有原始文件时应在notes注明人工整理来源，不虚构源文件。

## 病例 cases

- `case_id`：稳定匿名ID；相同ID完全相同记录去重，冲突则停止。不同ID是否同一人必须在事实整理阶段核实；不能仅凭同名自动合并。
- `disease`：DENV或CHIKV。`status`：confirmed、suspected或unknown。
- `confirmation_ref`：确诊证据定位。`diagnosis_basis`可记检测种类和结果；抗体阳性、核酸阳性、临床确诊不能混写。
- `origin`：local、imported、unknown；`origin_ref`保留调查依据。旅居史不自动等于输入；规范计数只收有确诊与本地来源证据的记录。
- `onset_date, report_date, known_at`：发病、报告、获知日期时间分别记录。计数使用报告日期，包含判定当日的N个自然日。日期边界是版本化实现口径，若当地采用不同业务口径需维护更新。
- `site_links`：`site_id, role, aggregation_eligible, evidence_ref`。role为residence/work/other/source_investigation。`aggregation_eligible=true`表示调查已核实适合纳入该场所本地病例聚集计数，不表示已证明在此感染；单纯路过或未核实关联填false/null。来源回溯地点不能仅凭怀疑就填true。
- `occupation, work_pattern`保留职业原文和实际班次/室内外/防护；职业名不参与数值升级。`household_id`引用家庭。
- 可选`age`为0至120岁的数值，仅用于同年龄组历史对照和照护提示。`historical_case_ids`为已人工确认属于本次病例的历史匿名ID数组，用于排除自我比较；未知不随意填写。
- 可选 `infectious_window={start,end,status,evidence_ref}`。status为reviewed或candidate。没有个体窗口时按发病日生成典型活动核查窗口，并始终标candidate。它不是个体传染期确认，也不决定任何隔离解除。

## 场所与活动

`sites`包含site_id、name、street、community、site_type、location_status、weather_point_id。street是宝安10个街道之一或null。跨区活动保留在原始材料中，需另建适用地区配置，不能强行归入宝安。location_status为verified/ambiguous/unresolved；verified需事实整理人员核验标准地点，建议保存location_evidence_ref。

历史名称不完全一致时自动列候选；可选`historical_site_key`与`historical_match_ref`仅在原文核实同一地点后提供，key使用历史库comparison_key。同街道同名跨社区时必须另明确community，不能因key同名强行合并。历史候选名匹配不改变location_status或坐标核验状态。

`coordinates`可为null；非空需latitude/longitude/crs/source_ref。只有核验WGS84坐标进入GeoJSON，GCJ-02/BD-09不会被静默当WGS84或自动转换。随包天气点为粗背景查询点，匹配并不提升空间精度；正式站点/格点应在维护阶段登记坐标、依据并重新冻结。

`activities`记录event_id、case_id、site_id、event_type、start、end、activity、mosquito_exposure（yes/no/unknown）、evidence_ref，可加outdoor、protection。event_type分别为infectious_activity、source_investigation、unclassified_activity；第一种仍只是调查对象，不自动证明传染性。跨日班次按实际ISO起止记录。即便与典型窗口不重合，也输出outside_window_requires_review，不判无风险。

## 家庭 现场 处置与既往风险

`households`：household_id、member_count、age_groups、care_needs、symptom_notes、evidence_ref。只保存防控所需信息。家庭结构改变不直接改变传播档位；它影响防护与照护建议。

`observations`：observation_id、site_id、observed_at、kind、evidence_ref。environment可填standing_water和details。vector需metric、value、unit、method、effort。支持BI、MOI、double_net_adults或other；分别使用 `positive_containers_per_100_households`、`%`、`只/(顶·小时)`。无记录、实测0和未知分开。不同指标不互换；未经正确方法/单位支持的正值不自动成为可信媒介证据。首版资料超过7日提示复查，此值是工程时效提醒，不是生物学阈值。

`interventions`包含intervention_id、site_id、performed_at、action、owner_role、evidence_ref；措施完成不等于有效，不自动降低风险。

`prior_risks`包含risk_id、site_id、disease、risk_level、priority、status、evidence_ref。status为open/under_review/in_progress/closed；closed还需closure_review_ref。未关闭高风险在新输入不足时保留；已关闭记录不作为升级依据，仍需保留专业复核来源。系统不会自行生成关闭决定。

## 输出含义

`site_assessments`为场所与病种整体建议；`risk_register`另含活动时段记录。活动行的site_risk_level是整体背景，不能把它当该时段已证实风险。同一病例可在多行出现，统计必须去重case_id，不能计台账行数。规范候选、系统风险、工作优先级和置信度是独立字段，`official_response_level=null`。
