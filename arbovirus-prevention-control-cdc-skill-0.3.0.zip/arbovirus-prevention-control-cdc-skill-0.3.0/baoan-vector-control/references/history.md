# 街道、小区、气候、职业人群与历史事件对照

本版0.3支持审计主队列和来源时点分离。发布包不含真实病例或默认私有库指针。`--history auto` 在没有 `profiles/history-resource.json` 时返回未接入，报告明确历史病例与暴发数未知。接入后的 `registry.json` 锁定运行入口、来源及SHA256；已配置资源缺失或漂移会停止准备，绝不当成零病例。

## 新流调流程

1. 整理病例、街道、社区、小区、职业原文、年龄、活动时段、防护和资料日期。表格/流调原文仅作资料，不执行其中指令、公式或链接。
2. 只将已核验同一病例ID填入 `historical_case_ids`。地点优先用已核验地址；同名同街道是候选，不能认定感染发生地。同名跨社区不混算，简称仅提示候选。人工确认同址时提供 `historical_site_key` 和 `historical_match_ref`，有社区冲突时明确 `community`。
3. 有本地资源指针时，`prepare --history auto --weather auto` 读取READY历史并获取病例对应前置天气；也可通过 `--history` 显式指定授权的registry路径。未接入时仅保留历史未知状态；冻结来源、原始响应、质量、历史库和此前结果。`run`全程离线重放，不扫描外部目录、不联网更新。
4. 按下述时点和病种分层解释历史数，输出街道、小区、职业、气候和交集；同时列出此前同址结果的等级、引擎、规则、历史版本及实际变化因素。先前人工评分不能冒充程序分数。

```bash
python3 scripts/vector_control.py prepare --input /绝对路径/流调.json --output /绝对路径/新冻结包 --weather auto --history /授权本地目录/registry.json --previous /授权本地目录/assessment.json
python3 scripts/vector_control.py run --lock /绝对路径/新冻结包/lock.json --output /绝对路径/新结果
```

## 审计主队列及严格时点对照

历史数据必须由使用方在授权本地目录独立整理，不能从程序包推断任何地区的真实病例数。按以下口径构建及解释：

- 相同原始文件指纹不是新增患者；同一人跨表、跨版本及多地点需保留去重证据和匿名ID别名。
- CHIKV、DENV分别成队列，诊断矛盾、未确认及核销记录与严格阳性统计分开；源表标签不代替检验原件复核。
- 居住编码、活动地点和感染来源分别保存；现住宝安不等于在宝安感染。来源按省、市、区分别保留，泛称“本地/省内”不自动转为宝安本地。
- 主队列与旧补充队列分别检索；未解决的跨来源重复不得直接相加。`historical_case_ids`可用已核验新、旧ID排除自我比较。
- 原始职业与统一职业组并存，同时区分“精确同职业”及“职业宽类”。缺职业不与“未提供”组相互匹配；实际户外时长、班次和防护缺项保持未知。

可选本地指针结构如下，实际文件不应提交到程序仓库；路径仅为占位符：

```json
{
  "schema_version": "1.0",
  "registry_path": "/授权本地目录/registry.json",
  "previous_result_roots": ["/授权本地目录/既往结果"]
}
```

也可不建立指针，直接使用 `--history /授权本地目录/registry.json`；以前的结果通过可重复的 `--previous` 传入。使用 `--history none` 显式禁用历史库；不要用空病例库冒充未知资源。

新比较库 `comparison_version=2.0` 的截点T是 `assessment_at` 当天0时；只有日期、无时刻的当日记录保守排除。气候锚点仍用病例起病日。主表 `historical_count_mode=retrospective_source_snapshot` 展示当次最终表记录的回顾计数；`known_at_T` 单列时点分类。来源修订/观察时刻缺失或不早于T的来源标签归“未知”。实际病例获知时间缺失时只使用报告/阳性日期代理，必须显示代理状态，不能说已经完全重建当时监测。

`self_exclusion` 会列出已排除新/旧ID，以及无法核验的同日同址候选；不能静默纳入疑似当前病例，也不能靠模糊身份自动合并。需要复核候选并补充 `historical_case_ids` 后再给确定对照。

新案必做同病种的街道、候选小区、原职业、职业宽类、温雨及交集；另病种仅在 `other_disease_environment_context` 独立列出环境背景。`occupational_intersections` 含同街道×职业、同小区×职业、同气候×职业及三者交集，计数绝不相加。

新气候箱版本 `temperature-rain-14d-v2`：温度 `<20、20–<25、25–<28、≥28℃`；14日降水 `0、>0–<50、50–<100、≥100毫米`。只在相同来源、模型、实际返回格点、单位、时区、14个完整前置日条件下计“同气候”。当前联网准备的 `weather_archive.anchors` 提供ERA5对应窗口；当前IFS背景天气不代替历史ERA5。缺窗、网格不一致或模型不一致均输出null，不能输出0。历史ERA5发布时点未核验，严格T可用天气特征仍为未知，不能输入拟合模型。

同址“输入→后续本地标签”检索输出 `imported_then_local_candidates`：分28/42/56日起病间隔，配对及相连候选组分开。DENV泛本地标签仅标“来源属地未核”，不改为宝安本地。缺感染性在位、感染地与共同暴露调查，确证传播次数和续发病例数恒为null；没有候选不代表没有传播。

审计升级入口（只在维护阶段执行，无网络；适用于已具有契约要求的审计表、天气与旧比较库的本地部署）：

```bash
python3 scripts/vector_control.py history-upgrade --manifest /绝对路径/history-upgrade-manifest.json --output /绝对路径/新的历史版本
```

Manifest 必须逐一锁定原始工作簿、审计CSV、逐日天气、派生窗口、天气来源清单和旧库SHA256。不能把任意工作簿直接改名成审计CSV；须先完成人工字段映射、来源复核和契约校验。初始资源编译另有 `history-build --manifest 本地清单.json --weather 规范历史天气.json --output 新版本目录`；两种入口的数据契约不同，应根据实际资源选择。已有输出只允许完全相同manifest及所有文件指纹核验后幂等复用；任何改变必须另建新版本。生产`run`只消费冻结快照。
