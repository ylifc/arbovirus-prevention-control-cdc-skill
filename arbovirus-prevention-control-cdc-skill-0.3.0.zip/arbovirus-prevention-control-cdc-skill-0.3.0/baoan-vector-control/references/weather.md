# 气象数据契约、来源与限制

本模块只负责天气证据。温度或降雨均不是蚊密度，不据此单独确认传播链、感染概率、政府应急响应级别或风险终止。当前实现：获授权导出的本地规范 JSON/CSV 导入，以及 Open-Meteo 模型备用接口。**深圳官方自动接口尚未接通；没有 API 账号时始终报告 `official: not_connected`。**

## Python 接口

Python 3.11 及以上，仅使用标准库，无安装动作：

```python
from vector_control.weather import fetch_weather, load_weather, validate_snapshot
snapshot = fetch_weather(points, "2026-10-03T12:00:00+08:00", timeout=15, retries=1)
snapshot = load_weather("weather.json", points, "2026-10-03T12:00:00+08:00")
snapshot = validate_snapshot(snapshot, "2026-10-03T12:00:00+08:00", points)
```

`points` 来自已冻结的公开气象点配置，每条必须有 `point_id, latitude, longitude, source_ref`；坐标为 WGS84。调用只把经纬度与天气参数发送到固定 Open-Meteo 域名，不发送 point_id、source_ref 或额外病例字段。公开气象点不应由患者地址临时生成；个人地址解析和点位映射在本地完成。

`as_of` 必须是带时区的 ISO 8601 时间。以下结构省略了长数组：

```json
{
  "schema_version": "1.0",
  "as_of": "2026-10-03T12:00:00+08:00",
  "timezone": "Asia/Shanghai",
  "historical_window": {"start": "2026-09-19T00:00:00+08:00", "end_exclusive": "2026-10-03T00:00:00+08:00", "days": 14},
  "provider_status": {"official": "not_connected", "open_meteo": "model_fallback_only"},
  "points": {
    "public-grid-01": {
      "metadata": {
        "provider": "open-meteo", "source_type": "model", "model": "ecmwf_ifs025",
        "source_ref": "https://api.open-meteo.com/v1/forecast",
        "spatial_resolution": "0.25 degrees (~25 km); hourly interpolation of native 3/6-hour model data",
        "retrieved_at": "2026-10-03T12:00:01+08:00", "published_at": null,
        "raw_response": "...original JSON text...", "raw_sha256": "...SHA256..."
      },
      "hourly": [{"valid_time": "2026-10-03T00:00:00+08:00", "temperature_c": 28,
        "relative_humidity_pct": 70, "precipitation_mm": 0, "wind_speed_ms": 2,
        "wind_direction_deg": 90, "precipitation_interval_start": "2026-10-02T23:00:00+08:00",
        "precipitation_interval_end": "2026-10-03T00:00:00+08:00"}],
      "current": null,
      "quality": {"expected_hours": 336, "complete_14_days": false,
        "variable_coverage": {}, "missing_hours": {}, "longest_missing_run_hours": {},
        "current_stale": true, "current_age_hours": null, "current_variable_coverage": {},
        "source_is_observation": false, "issues": []},
      "daily": [],
      "features": {"rainfall_1d_mm": null, "rainfall_3d_mm": null,
        "rainfall_7d_mm": null, "rainfall_14d_mm": null,
        "dry_days_14": 0, "dry_spell_at_least_14_days": null, "dry_spell_is_lower_bound": true}
    }
  },
  "errors": []
}
```

上述数值仅为结构示例。实际 `daily` 始终列出 14 个完整自然日；当天截至 `as_of` 的小时数据单独保留在 `hourly`，不计入完整日特征。

## 获取与时空语义

- 当前运行使用 `https://api.open-meteo.com/v1/forecast`，固定 `models=ecmwf_ifs025`。过去日期改用 `https://historical-forecast-api.open-meteo.com/v1/forecast`，不请求也不采纳真实今天的 current。没有自动改用另一模型的暗中兜底。
- 请求 `temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,wind_direction_10m`，显式指定北京时间、摄氏度、毫米、米/秒，并检查响应单位和 UTC 偏移。返回格点坐标单列保存，不等同于请求位置。
- ECMWF IFS 0.25° 是约 25 km 模型格点；原生 3/6 小时数据由服务提供方插为逐小时。`current` 也属于模型估计；深圳的 15 分钟 current 不能称作站点实测。接口没有给出模型发布时间，因此 `published_at=null`；服务端计算耗时不是发布时间。
- 每条降雨表示 `(precipitation_interval_start, precipitation_interval_end]` 内一小时总量。北京时间当天 00:00 的降水属于前一天 23:00–24:00。因此温湿风完整窗口需要起日 00:00 至末日 23:00 共 336 点，而降水需要起日 01:00 至次日 00:00 共 336 个区间；不能直接对同一时间标签数组按日期粗分后求雨量。
- 所有规范化数值的有效时间不晚于 `as_of`；原始响应原文仍完整保留作为审计证据，因此可能含后来被过滤的未来时间。过去回查数据可能发生事后修订；`retrieved_after_as_of_not_prospective` / `published_after_as_of_not_prospective` 表明不能把这次回查当作当时已知的前瞻证据。
- SHA256 校验只证明保存的原文未变化，不证明来源声明真实，也不代替外层冻结锁对整个规范快照的完整性保护。重放使用冻结快照文件，`load_weather` 和 `validate_snapshot` 不访问网络。`validate_snapshot` 重算日值和特征，不信任输入里的派生结果。

## 本地官方数据导入

支持规范 JSON，即上面的 `points -> point_id -> metadata/hourly/current`。JSON 内 `source_type` 允许 `observation`、`interpolated_observation`、`model`、`reanalysis`、`unknown`；地方 1 km 自动站插值数据应填 `interpolated_observation`。本工具不猜测原始官方字段含义，不将任意第三方 JSON 当作官方数据；需先依据导出字段手册映射到本契约。字段名中的单位不可变，提供不同 `metadata.units` 会被拒绝。

CSV 使用 UTF-8（可带 BOM），一行一个点的一个小时，最少表头：

```csv
point_id,valid_time,source_type,source_ref,provider,station_id,spatial_resolution,retrieved_at,published_at,temperature_c,relative_humidity_pct,precipitation_mm,wind_speed_ms,wind_direction_deg,precipitation_interval_start,precipitation_interval_end
```

`point_id,valid_time,source_type,source_ref` 必填；其余变量缺失保持未知。时间必须带时区。若源数据明确为前一小时累计，可以用 `precipitation_semantics=preceding_hour` 代替降水起止字段；24 小时滚动累计不可套用该声明。附加 `record_kind=current` 可导入一条当前记录，它不参与历史日累计。同一点不得混入冲突来源；不同来源应建独立气象点后由上游明确选取。导入文件原文及散列存放 `import_provenance`，规范 JSON 里的来源声明需要业务人员核实。

## 缺失与失败处理

- 不用零替代缺测；非有限数、负降水/风速、越界湿度/风向置空并记问题。小时重复但一致则去重；冲突则该时次全部变量置空，不能任选一条。
- 气象日累计/均值仅在其全部 24 个小时完整时生成。另有 `precipitation_known_sum_mm` 明确表示已知部分总和，不能当完整日雨量。
- `dry_days_14` 是窗口末尾连续、完整、雨量恰为 0 的天数。`dry_spell_at_least_14_days` 仅完整 14 日无雨才为 true；发现雨则 false；缺测且未发现雨则 null。连续达到 14 天时实际长度可能更长，标记下界。此判断只是降水记录，不是防控解除条件。
- 分变量报告覆盖率、缺小时数、最长连续缺口。当前记录超过 2 小时或缺失时 `current_stale=true`，2 小时为本版本工程新鲜度约定，不是医学阈值；变量齐全程度另列。
- API 网络失败返回 `fetch_failed`、`failed/partial` 状态及缺测矩阵；不会声称抓全，也不安装软件、切换账号或虚构官方连接。默认每次每点至多请求 2 次，重试上限可配至 3；单响应最多 8 MiB。

## 经核查的来源

核查日期：2026-10-03。

- [深圳气象局：1 km 格点编号和位置](https://weather.sz.gov.cn/gkmlpt/content/12/12737/post_12737911.html)：位置映射需要格点信息表，不能宣称小区楼栋实测。
- [深圳气象局：IDW 插值方法](https://weather.sz.gov.cn/gkmlpt/content/11/11668/post_11668623.html)：官方格点实况来自自动站插值。
- [深圳自动站查询](https://weather.sz.gov.cn/qixiangfuwu/qixiangjiance/zidongzhanchaxun/index.html)：可筛选宝安、温雨湿风，网页说明历史最近一年；不据此保证 API 可完整导出。
- [深圳开放平台 API 指南](https://opendata.sz.gov.cn/downloadFiles/open-file/Api%E6%8E%A5%E5%8F%A3%E8%B0%83%E7%94%A8%E6%93%8D%E4%BD%9C%E6%8C%87%E5%8D%97.pdf)：旧版 appKey 获取说明，现行账号与授权需现场联调。
- [Open-Meteo Forecast API](https://open-meteo.com/en/docs)、[ECMWF 模型说明](https://open-meteo.com/en/docs/ecmwf-api)、[Historical Forecast API](https://open-meteo.com/en/docs/historical-forecast-api)：当前和历史模型资料的接口、单位与时段定义。
- [Open-Meteo Historical Weather API](https://open-meteo.com/en/docs/historical-weather-api)：ERA5/ERA5-Land 约有 5 天延迟，因此本模块未用它伪装截止昨天的完整观测。
- [Open-Meteo 条款](https://open-meteo.com/en/terms)：免费端点仅限非商业用途并受限流，需 CC BY 4.0 署名；没有持续供数保证，日志可能保留坐标。实际部署前按用途复核服务许可。


## v0.3：按流调日期自动准备 84 日气象与缓存

`prepare --weather auto` 使用以下接口（只允许在准备/维护阶段调用）：

```python
from vector_control.weather import prepare_weather
snapshot = prepare_weather(
    points, assessment_at="2026-10-14T12:00:00+08:00",
    anchors=["2025-10-10", "2025-10-11"],
    cache_root="/persistent/weather-cache/v3",
    archive_manifest="/existing/weather/manifest.json",
)
```

- `points` 仍是公开背景坐标白名单。发送到网络的只有公开坐标、日期、单位、模型和气象变量；不发送病人、小区地址、职业或病例标识。
- 如配置了本地 ERA5 档案，首先验证 `manifest.json` 和涉及年份原始 JSON 的 SHA256，完全只读复用。追加缓存使用内容寻址文件，绝不覆盖已有文件；散列或坐标发生漂移则停止，不自动重下替换。随后仅请求尚缺的连续日期区间，每次最多 366 天。
- 新的 `weather_archive` 与原有 `points` 分开：`points` 保留 IFS 的当前/前 14 日背景；`weather_archive` 固定 `models=era5`，分别为判定日和每个起病锚点保存前 84 个自然日，以及 7、14、28、56、84 日汇总。起病当天、判定当天及未来天气不进入该历史窗口。前 56 日供主滞后分析，84 日用于敏感性分析；这些窗口不代表医学阈值。
- `weather_archive.anchors["YYYY-MM-DD"].points[point_id].features["14"]` 提供 `temperature_mean_c, precipitation_sum_mm, humidity_mean_pct, complete, missing_days`。`metadata` 保存 `provider, model, source_type, grid_latitude, grid_longitude, timezone, units`。历史匹配应使用这个 ERA5 窗口，并要求两边模型、格点、单位和窗口一致；IFS 不能填补 ERA5 的空缺。
- 日温度/降水沿用供应商声明的北京时间日值，湿度由 24 个完整小时计算。校验每个自然日恰好 24 个唯一小时，检查所有返回变量长度、单位和数值范围。某日不完整、重复或数值冲突时，该日保持缺失，任何包含该日的完整窗口不生成数值。跨来源的重复完整日若数值或实际格点冲突，也置缺失并记录 `source_revision_conflict`。
- 同一窗口实际 ERA5 格点变化时，窗口不可作同气候比较。两个公开查询坐标只是背景代表点，返回的实际格点可能偏离宝安区，不能写成小区实测或逐街道站点天气。
- ERA5 通常有约 5 天发布延迟。判定日前的最近几天可能为空；程序仍抓取并报告缺口，不用 IFS 冒充完整 ERA5，不将空值变为零雨量。实时防控可以参阅独立 IFS 背景，但同气候统计标明无法完成。
- 归档内嵌所有使用到的原始响应、SHA256、请求 URL、实际格点和获取时间，因此冻结包可独立复算。发布时间通常未知，事后下载的历史天气只能作回顾性分析，不能伪称判定当时已可获得。
- `validate_snapshot` 会离线校验归档原文并重算窗口；`run` 只读取冻结快照，绝不联网。缓存只用于准备，不是生产重放依赖。API 默认超时 15 秒、至多 2 次尝试、每份原始响应 8 MiB 上限；失败逐点/逐日期记录为 `archive_fetch_failed`。

2026-10-14 再次核查 [Open-Meteo Historical Weather API](https://open-meteo.com/en/docs/historical-weather-api)：固定 ERA5 用于保持多年来源一致，ERA5 标注 0.25°、约 5 日延迟。自动获取的是公开再分析/模型资料；深圳官方授权站点接口仍未接通。
