# Local evidence extraction

`vector_control.intake.extract_local(path)` reads one explicitly supplied local
regular file and returns a JSON-serializable evidence object. Python 3.11 or later
and its standard library are sufficient. The function performs no network
requests, file writes, subprocess calls, formula evaluation, or epidemiological
inference. A document containing instructions is treated as inert source text.

## Interface

```python
from vector_control.intake import IntakeError, extract_local

try:
    evidence = extract_local("/absolute/path/interview.docx")
except IntakeError as error:
    print(error.code, str(error))
```

Success has `status: "extracted"`, `format`, `source`, `content`, and `warnings`.
`source` contains the resolved local `path`, SHA-256 `sha256`, and byte `size` of
the exact bytes parsed. Text sources also record `encoding`. `extracted` means
the container was read; it does not validate clinical facts, current infection,
case deduplication, source instructions, completeness, or risk.

Every content item carries a `source_ref`; its path is relative to the source
file identified by the enclosing `source` object:

| Format | Content and locator |
| --- | --- |
| `.txt`, `.md` | `kind: line`, exact line `text`, one-based `line` |
| `.csv` | `kind: table_row`, string `cells`, one-based logical `row`, physical `line` and `line_end`; quoted multiline cells retain newlines |
| `.json` | `kind: json`, parsed `data`, root `json_path: "$"`; no implicit schema or case interpretation |
| `.docx` | Body paragraphs and table rows in document order; paragraphs have `text` and global paragraph index; rows have `table`, `row`, and cells with `column`, `column_span`, `vertical_merge`, `text`, recursively ordered `content`, and a structural `path` |
| `.xlsx` | A `kind: sheet` marker precedes each worksheet's `table_row` items; each cell retains column, A1 `cell`, raw value, type, parsed value, and applicable style/formula/merge metadata; row references name the sheet and one-based row |

CSV cells are strings; Office table cells are objects. Sparse XLSX cells remain
sparse: a missing physical cell is not an observed zero or a carried-forward
value. Row-level `merged_ranges` identifies vertical continuation even when the
blank sequence-number cell is absent from XML. All explicitly stored rows are
retained, including empty rows, hidden sheets, and rows whose first cell is
blank. Merged values are never filled into subsequent records automatically.

## Interpretation boundaries

- UTF-8 and UTF-8 BOM are preferred. BOM-marked UTF-16 is accepted. GB18030 is a
  fallback with a warning and recorded encoding; no lossy replacement occurs.
- CSV delimiter detection is limited to comma, semicolon, tab, and pipe. If
  detection fails, the reader uses comma and records that decision. It does not
  guess headers, case columns, or whether an apparent sequence number is valid.
- JSON duplicate object keys and non-finite or overflowing floating-point
  values are rejected rather than silently discarding or changing evidence.
- DOCX reads main-body paragraphs, tables, and content controls in source order.
  Nested tables remain in cell content. Headers, footers, comments, images,
  embedded files, and alternate document parts are not evidence extracted by
  this version. Unsupported body blocks are reported in warnings. Deleted run
  text and field instructions are not interpreted as current body prose.
- XLSX resolves shared and inline strings and supports common Excel date/time
  number formats, both 1900 and 1904 date systems. The original numeric serial
  is always retained. Excel's fictional 1900-02-29 and out-of-range dates remain
  numeric with a warning. Elapsed-time formats remain `duration_serial` values.
  Numeric values do not preserve all Excel display formatting: number formats
  that display leading zeros remain numeric evidence with their format code.
- Formulas are copied with cached results where available. Cached results can
  be stale; missing cached results stay unknown. No formula or external link is
  evaluated. External workbook relationships are ignored with a warning.
- Date-format recognition is deliberately basic. Layout, rich formatting,
  charts, pictures, comments, and formula recalculation are outside this reader.
- Downstream exports must handle spreadsheet formula-injection escaping at the
  export boundary. This reader preserves the original evidence unchanged.

## Limits and local errors

Defaults are 20 MiB per input file; at most 2,048 ZIP members; 20 MiB per
uncompressed member; 100 MiB total uncompressed; a compression-ratio ceiling of
300 for members over 1 MiB. The reader limits content items, worksheet rows/cells,
merge-processing work, and DOCX nesting. It rejects duplicate/unsafe archive
paths, symbolic-link members, encrypted archives, DTD/entity declarations,
malformed structures, and invalid or inconsistent cell references. Archive
members are read in memory and are never extracted to disk.

`IntakeError.code` includes `missing_local_source`, `invalid_local_source`,
`unreadable_local_source`, `unsupported_format`, `file_limit`, `archive_limit`,
`content_limit`, `unsafe_archive`, `unsafe_xml`, `invalid_archive`, `invalid_xml`,
`invalid_encoding`, `invalid_json`, `invalid_document`, and
`missing_document_part`. Missing local files remain local-input errors; the
reader never switches to remote acquisition.

## Focused verification

Run `python -m unittest discover -s baoan-vector-control/tests -p test_intake.py`.
Tests use temporary synthetic files rather than actual patient data. They
exercise source order and locators, merged blank sequence numbers, dates and
formulas, encoding, instruction text, missing inputs, and resource limits.
