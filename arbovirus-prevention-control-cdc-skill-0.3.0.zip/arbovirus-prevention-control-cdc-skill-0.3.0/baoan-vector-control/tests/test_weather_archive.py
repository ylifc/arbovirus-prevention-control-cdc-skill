"""84-day fixed-model archive, cache integrity, and no-leakage regressions."""
import copy
import hashlib
import json
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from vector_control import weather as w, weather_archive as a

POINTS = [{"point_id": "public-point", "latitude": 22.6, "longitude": 113.9, "source_ref": "public-background"}]
AS_OF = "2025-10-11T12:00:00+08:00"


def payload(start="2025-07-19", days=84):
    ds = [(date.fromisoformat(start) + timedelta(days=i)).isoformat() for i in range(days)]
    hourly = {"time": [day + f"T{h:02d}:00" for day in ds for h in range(24)]}
    for k, value in zip(a.HOURLY, (27, 70, 1, 2)):
        hourly[k] = [value] * (days * 24)
    daily = {"time": ds}
    for k, value in zip(a.DAILY, (27, 25, 29, 24, 24, 3)):
        daily[k] = [value] * days
    return {"latitude": 22.5, "longitude": 114.0, "utc_offset_seconds": 28800,
            "hourly_units": dict(zip(a.HOURLY, ("°C", "%", "mm", "m/s"))),
            "daily_units": dict(zip(a.DAILY, ("°C", "°C", "°C", "mm", "mm", "m/s"))),
            "hourly": hourly, "daily": daily}


def source(data=None):
    return a._source(json.dumps(data or payload()), POINTS[0], retrieved_at=AS_OF, request_url=a.ENDPOINT,
                     key="fixture", origin="fixture")


def archive(data=None):
    return {"schema_version": "1.0", "kind": "era5_anchor_archive", "model": "era5", "sources": [source(data)],
            "anchors": {AS_OF[:10]: {}}}


class ArchiveTests(unittest.TestCase):
    def window(self, data=None):
        return a.validate_archive(archive(data), POINTS, AS_OF)["anchors"][AS_OF[:10]]["points"]["public-point"]

    def test_exact_84_days_excludes_anchor_and_aggregates(self):
        p = self.window()
        self.assertEqual(len(p["daily"]), 84)
        self.assertEqual(p["daily"][0]["date"], "2025-07-19")
        self.assertEqual(p["daily"][-1]["date"], "2025-10-10")
        for n in (7, 14, 28, 56, 84):
            f = p["features"][str(n)]
            self.assertTrue(f["complete"])
            self.assertEqual(f["precipitation_sum_mm"], 24 * n)
            self.assertEqual(f["temperature_mean_c"], 27)
        self.assertEqual(p["metadata"]["grid_latitude"], 22.5)

    def test_missing_hour_is_not_zero(self):
        data = payload()
        data["hourly"]["precipitation"][-1] = None
        p = self.window(data)
        self.assertFalse(p["features"]["7"]["complete"])
        self.assertIsNone(p["features"]["7"]["precipitation_sum_mm"])
        self.assertEqual(p["features"]["7"]["missing_days"], ["2025-10-10"])

    def test_today_partial_and_future_daily_are_not_in_history(self):
        data = payload(days=85)
        data["daily"]["precipitation_sum"][-1] = 999
        data["hourly"]["temperature_2m"][-1] = None
        p = self.window(data)
        self.assertEqual(p["features"]["14"]["precipitation_sum_mm"], 336)
        self.assertTrue(p["quality"]["complete_84_days"])

    def test_duplicate_hours_or_daily_reject_day(self):
        for kind in ("hourly", "daily"):
            data = payload()
            for values in data[kind].values():
                values.append(values[-1])
            self.assertFalse(self.window(data)["features"]["14"]["complete"])

    def test_bad_units_and_raw_hash_fail(self):
        data = payload()
        data["daily_units"]["precipitation_sum"] = "inch"
        with self.assertRaisesRegex(ValueError, "unit mismatch"):
            self.window(data)
        obj = archive()
        obj["sources"][0]["raw_sha256"] = "wrong"
        with self.assertRaisesRegex(ValueError, "SHA256"):
            a.validate_archive(obj, POINTS, AS_OF)

    def test_replay_recomputes_features_and_is_offline(self):
        obj = a.validate_archive(archive(), POINTS, AS_OF)
        obj["anchors"][AS_OF[:10]]["points"]["public-point"]["features"]["14"]["temperature_mean_c"] = 999
        with patch.object(w, "_request", side_effect=AssertionError("network forbidden")):
            rebuilt = a.validate_archive(obj, POINTS, AS_OF)
        self.assertEqual(rebuilt["anchors"][AS_OF[:10]]["points"]["public-point"]["features"]["14"]["temperature_mean_c"], 27)

    def test_revision_conflict_is_missing(self):
        obj = archive()
        changed = payload()
        changed["daily"]["temperature_2m_mean"][-1] = 28
        obj["sources"].append(dict(source(changed), key="revision"))
        p = a.validate_archive(obj, POINTS, AS_OF)["anchors"][AS_OF[:10]]["points"]["public-point"]
        self.assertIn("source_revision_conflict", p["daily"][-1]["issues"])
        self.assertIsNone(p["features"]["14"]["temperature_mean_c"])

    def test_different_returned_grid_is_not_silently_merged(self):
        obj = archive()
        changed = payload()
        changed["latitude"] = 22.75
        obj["sources"].append(dict(source(changed), key="other-grid"))
        p = a.validate_archive(obj, POINTS, AS_OF)["anchors"][AS_OF[:10]]["points"]["public-point"]
        self.assertFalse(p["features"]["14"]["complete"])
        self.assertIsNone(p["features"]["14"]["precipitation_sum_mm"])

    def test_network_cache_reused_without_retrieval(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(w, "_now", return_value=w._dt("2026-10-14T12:00:00+08:00")):
            with patch.object(w, "_request", return_value=json.dumps(payload())) as request:
                first = a.prepare_archive(POINTS, AS_OF, cache_root=tmp)
                self.assertEqual(request.call_count, 1)
                self.assertIn("models=era5", request.call_args.args[0])
            with patch.object(w, "_request", side_effect=AssertionError("network forbidden")):
                second = a.prepare_archive(POINTS, AS_OF, cache_root=tmp)
            self.assertEqual(first["anchors"], second["anchors"])
            cache = next(Path(tmp).glob("era5-*.json"))
            record = json.loads(cache.read_text())
            record["source"]["raw_sha256"] = "drift"
            cache.write_text(json.dumps(record))
            with patch.object(w, "_request", side_effect=AssertionError("network forbidden")), self.assertRaisesRegex(ValueError, "SHA256"):
                a.prepare_archive(POINTS, AS_OF, cache_root=tmp)

    def test_network_failure_keeps_all_84_missing(self):
        with patch.object(w, "_request", side_effect=RuntimeError("offline")):
            out = a.prepare_archive(POINTS, AS_OF)
        self.assertEqual(out["provider_status"], "failed_or_missing")
        p = out["anchors"][AS_OF[:10]]["points"]["public-point"]
        self.assertEqual(len(p["features"]["84"]["missing_days"]), 84)
        self.assertIsNone(p["features"]["14"]["precipitation_sum_mm"])

    def test_anchor_future_refused_before_network(self):
        with patch.object(w, "_request", side_effect=AssertionError("network forbidden")), self.assertRaisesRegex(ValueError, "anchor future"):
            a.prepare_archive(POINTS, AS_OF, ["2025-10-12"])

    def test_public_query_contains_no_private_point_fields(self):
        private = [dict(POINTS[0], patient_name="SECRET_NAME", address="SECRET_HOME")]
        with patch.object(w, "_request", return_value=json.dumps(payload())) as request:
            a.prepare_archive(private, AS_OF)
        self.assertNotIn("SECRET", request.call_args.args[0])

    def test_request_timeout_and_retry_are_bounded(self):
        with patch.object(w, "urlopen", side_effect=TimeoutError("offline")) as request:
            with self.assertRaises(RuntimeError):
                w._request(a.ENDPOINT, timeout=2, retries=1)
        self.assertEqual(request.call_count, 2)
        self.assertEqual(request.call_args.kwargs["timeout"], 2)

    def test_oversize_response_is_rejected(self):
        class Response:
            def __enter__(self):
                return self
            def __exit__(self, *_):
                pass
            def read(self, n):
                self.requested_size = n
                return b"x" * n
        response = Response()
        with patch.object(w, "urlopen", return_value=response), self.assertRaisesRegex(ValueError, "size limit"):
            w._request(a.ENDPOINT, timeout=2, retries=1)
        self.assertEqual(response.requested_size, w.MAX_BYTES + 1)

    def test_local_manifest_raw_reused_read_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            raw = json.dumps(payload()).encode()
            (root / "raw.json").write_bytes(raw)
            manifest = {"model": "era5", "source_type": "reanalysis", "endpoint": a.ENDPOINT, "shards": [
                {"point_id": "public-point", "parameters": {"latitude": 22.6, "longitude": 113.9, "models": "era5", "timezone": "Asia/Shanghai",
                 "start_date": "2025-07-19", "end_date": "2025-10-10"}, "raw_file": "raw.json", "sha256": hashlib.sha256(raw).hexdigest(), "retrieved_at": AS_OF}]}
            path = root / "manifest.json"
            path.write_text(json.dumps(manifest))
            before = {p.name: p.read_bytes() for p in root.iterdir()}
            with patch.object(w, "_request", side_effect=AssertionError("network forbidden")):
                out = a.prepare_archive(POINTS, AS_OF, archive_manifest=path)
            self.assertEqual(out["provider_status"], "complete_reanalysis")
            self.assertEqual(before, {p.name: p.read_bytes() for p in root.iterdir()})


if __name__ == "__main__":
    unittest.main()
