import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from vector_control.common import ValidationError
from vector_control.validation import validate_input
from vector_control.engine import assess, activity_window, _relation


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((ROOT / "assets/example_input.json").read_text())
        self.profile = json.loads((ROOT / "profiles/baoan.json").read_text())
        self.rules = json.loads((ROOT / "rules/cn-vector-2026.json").read_text())

    def run_data(self, data=None):
        data, warnings = validate_input(data or self.data, self.profile, self.rules)
        return assess(data, self.profile, self.rules, {"points": {}, "errors": []}, warnings)

    def site(self, result, sid="DEMO-A", disease="DENV"):
        return next(r for r in result["site_assessments"] if r["site_id"] == sid and r["disease"] == disease)

    def test_cluster_and_no_weather_does_not_downgrade(self):
        row = self.site(self.run_data())
        self.assertEqual((row["risk_level"], row["priority"], row["site_local_count"]), ("很高", "P0", 3))
        self.assertIsNone(row["official_response_level"])

    def test_duplicate_same_patient_once(self):
        self.data["cases"].append(copy.deepcopy(self.data["cases"][0]))
        result = self.run_data()
        self.assertEqual(self.site(result)["site_local_count"], 3)
        self.assertTrue(result["input_warnings"])

    def test_conflicting_duplicate_rejected(self):
        row = copy.deepcopy(self.data["cases"][0]); row["origin"] = "imported"
        self.data["cases"].append(row)
        with self.assertRaises(ValidationError): self.run_data()

    def test_imported_not_counted(self):
        self.data["cases"][0]["origin"] = "imported"
        row = self.site(self.run_data())
        self.assertEqual(row["site_local_count"], 2)
        self.assertNotEqual(row["priority"], "P0")

    def test_missing_confirmation_not_counted(self):
        del self.data["cases"][0]["confirmation_ref"]
        self.assertEqual(self.site(self.run_data())["site_local_count"], 2)

    def test_missing_origin_evidence_not_counted(self):
        del self.data["cases"][0]["origin_ref"]
        self.assertEqual(self.site(self.run_data())["site_local_count"], 2)

    def test_disease_windows_differ(self):
        for case in self.data["cases"][:3]: case["report_date"] = "2026-09-20"
        self.assertEqual(self.site(self.run_data())["site_local_count"], 3)
        for case in self.data["cases"][:3]: case["disease"] = "CHIKV"
        self.assertEqual(self.site(self.run_data(), disease="CHIKV")["site_local_count"], 0)

    def test_boundary_of_14_calendar_days(self):
        self.data["cases"][0]["report_date"] = "2026-09-19"
        self.assertEqual(self.site(self.run_data())["site_local_count"], 2)

    def test_ambiguous_site_not_cluster(self):
        self.data["sites"][0]["location_status"] = "ambiguous"
        self.assertEqual(self.site(self.run_data())["site_local_count"], 0)

    def test_occupation_and_household_do_not_change_risk(self):
        baseline = self.run_data()
        self.data["cases"][0]["occupation"] = "退休人员"
        self.data["households"][0]["member_count"] = 100
        changed = self.run_data()
        self.assertEqual([(r["risk_level"], r["priority"]) for r in baseline["site_assessments"]], [(r["risk_level"], r["priority"]) for r in changed["site_assessments"]])

    def test_unknown_case_time_still_p1(self):
        case = self.data["cases"][3]
        case["onset_date"] = case["report_date"] = None
        row = self.site(self.run_data(), "DEMO-B", "CHIKV")
        self.assertEqual((row["risk_level"], row["priority"]), ("待评估", "P1"))

    def test_cross_midnight_is_preserved(self):
        row = next(r for r in self.run_data()["risk_register"] if r["risk_id"].endswith("E03"))
        self.assertIn("2026-10-02", row["end"])

    def test_source_investigation_never_implies_infectious_activity(self):
        event = self.data["activities"][1]
        event.update(mosquito_exposure="yes", start="2026-09-29T09:00:00+08:00", end="2026-09-29T10:00:00+08:00")
        result = self.run_data()
        row = next(r for r in result["risk_register"] if r["risk_id"].endswith("E02"))
        self.assertEqual(row["risk_level"], "待评估")

    def test_half_open_window_does_not_overlap_left_edge(self):
        case = copy.deepcopy(self.data["cases"][0]); case["onset_date"] = "2026-10-01"
        window = activity_window(case, self.rules["diseases"]["DENV"])
        event = {"start": "2026-09-29T23:00:00+08:00", "end": "2026-09-30T00:00:00+08:00"}
        self.assertEqual(_relation(event, window), "outside_window_requires_review")

    def test_zero_duration_rejected(self):
        self.data["activities"][0]["end"] = self.data["activities"][0]["start"]
        with self.assertRaises(ValidationError): self.run_data()

    def test_recent_report_old_activity_not_current_high(self):
        self.data["cases"] = [self.data["cases"][0]]
        self.data["cases"][0].update(onset_date="2026-06-01", report_date="2026-10-03")
        self.data["observations"] = []
        self.data["activities"] = [self.data["activities"][0]]
        self.data["activities"][0].update(start="2026-06-01T06:00:00+08:00", end="2026-06-01T07:00:00+08:00")
        self.assertEqual(self.site(self.run_data())["risk_level"], "待评估")

    def test_unknown_zero_metric_not_low(self):
        self.data["cases"] = []; self.data["activities"] = []
        self.data["sites"][0]["surveillance"] = {"adequate": True, "reviewer_ref": "synthetic:review", "assessed_at": "2026-10-02T12:00:00+08:00"}
        self.data["observations"] = [{"observation_id": "x", "site_id": "DEMO-A", "observed_at": "2026-10-02T12:00:00+08:00", "kind": "vector", "metric": "other", "value": 0, "method": "arbitrary", "unit": "unrelated", "evidence_ref": "synthetic:x"}]
        self.assertNotEqual(self.site(self.run_data())["risk_level"], "低")

    def test_prior_high_not_lost_on_missing_data(self):
        self.data["cases"] = []; self.data["activities"] = []; self.data["observations"] = []
        self.data["prior_risks"] = [{"risk_id": "prior-1", "site_id": "DEMO-A", "disease": "DENV", "risk_level": "高", "priority": "P1", "status": "open", "evidence_ref": "synthetic:prior"}]
        row = self.site(self.run_data())
        self.assertEqual((row["risk_level"], row["priority"]), ("高", "P1"))

    def test_future_information_rejected(self):
        self.data["cases"][0]["known_at"] = "2026-10-03T13:00:00+08:00"
        with self.assertRaises(ValidationError): self.run_data()

    def test_unsupported_region_and_disease_stop(self):
        self.data["cases"][0]["disease"] = "WNV"
        with self.assertRaises(ValidationError): self.run_data()

    def test_policy_outside_validated_date_stops(self):
        self.data["assessment_at"] = "2027-02-01T12:00:00+08:00"
        with self.assertRaises(ValidationError): self.run_data()

    def test_street_unique_people_and_affected_other_site(self):
        self.data["activities"] = []; self.data["observations"] = []
        base = self.data["cases"][0]
        self.data["cases"] = []
        for i in range(10):
            c = copy.deepcopy(base); c["case_id"] = f"N{i}"
            c["site_links"] = [{"site_id": "DEMO-A", "role": "residence", "aggregation_eligible": True, "evidence_ref": "synthetic:x"}]
            self.data["cases"].append(c)
        self.data["sites"][1]["street"] = "新安"
        result = self.run_data()
        self.assertEqual(self.site(result, "DEMO-A")["street_local_count"], 10)
        self.assertEqual(self.site(result, "DEMO-B")["priority"], "P0")
        self.assertIn("不表示本场所已证实传播", "".join(self.site(result, "DEMO-B")["reasons"]))


if __name__ == "__main__": unittest.main()
