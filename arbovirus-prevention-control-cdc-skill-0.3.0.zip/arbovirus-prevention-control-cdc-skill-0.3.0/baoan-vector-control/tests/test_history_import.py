"""Synthetic evidence and duplicate tests; no private inputs are test fixtures."""
from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from vector_control.history_import import (build_registry, classify_origin, extract_sites,
    occupation_group, parse_date, _row_record, _merge, normalize_site_name, site_key)
from vector_control.common import file_hash, ValidationError


class HistoricalImportTests(unittest.TestCase):
    def setUp(self):
        self.salt = b"synthetic-test-key-only-1234567890"
        self.spec = {"sheet":"synthetic", "disease":"CHIKV", "header_row":1,
            "columns":{"name":1,"sex":2,"age":3,"onset":4,"residence":5,"street":6,"origin":7,"occupation":8},
            "final_report_origin":True}
        self.row = {1:"合成人",2:"女",3:30,4:"2025-10-10",5:"西乡街道试验社区示例花园8栋801房",6:"西乡",7:"真正本地病例",8:"销售"}

    def parsed(self, cells=None, row=2):
        return _row_record(cells or self.row,self.spec,"source1",row,2025,self.salt)[0]

    def test_dates_no_clock_default_or_ambiguous_range(self):
        self.assertEqual(parse_date("10月10日发病"),(None,"year_missing"))
        self.assertEqual(parse_date("10月10日",2025),("2025-10-10","year_from_manifest"))
        self.assertEqual(parse_date("2025-10-10"),("2025-10-10","explicit_date"))
        self.assertEqual(parse_date(45940),("2025-10-10","excel_serial"))
        self.assertEqual(parse_date("10月10日至12日",2025)[0],None)
        self.assertEqual(parse_date("10月10日-12日",2025)[0],None)
        self.assertEqual(parse_date("10月10、11日",2025)[0],None)
        self.assertEqual(parse_date("10月10日左右",2025)[0],None)
        self.assertEqual(parse_date("无症状感染者",2025)[0],None)
        self.assertEqual(parse_date("2月30日",2025)[1],"invalid_date")

    def test_baoan_origin_distinct_from_provincial_label(self):
        self.assertEqual(classify_origin("真正本地病例",final_report=True)[0],"local")
        self.assertEqual(classify_origin("本地关联外地病例",final_report=True)[0],"unknown")
        self.assertEqual(classify_origin("本地病例",final_report=True)[0],"unknown")
        self.assertEqual(classify_origin("广东省本地病例（初步判断为南山区输入病例）")[0],"imported")
        self.assertEqual(classify_origin("深圳市本地病例（初步判断为宝安区本地病例）")[0],"local")
        self.assertEqual(classify_origin("宝安区本地病例，不排除南山区感染")[0],"unknown")

    def test_private_identifiers_removed_and_outbreak_unknown(self):
        record,key,_ = self.parsed()
        encoded = json.dumps(record,ensure_ascii=False)
        self.assertNotIn("合成人",encoded)
        self.assertNotIn("801",encoded)
        self.assertNotIn("8栋",encoded)
        self.assertIsNone(record["confirmed_outbreak_ids"])
        self.assertEqual(record["sites"][0]["name"],"示例花园")
        self.assertEqual(record["sites"][0]["key"],"西乡::示例花园")
        self.assertEqual(record["sites"][0]["match_status"],"candidate_extracted")

    def test_occupation_is_not_exposure_risk(self):
        self.assertEqual(occupation_group("建筑工人"),"建筑装修及安装")
        self.assertEqual(occupation_group("室内办公室文员"),"办公研发及管理")
        self.assertEqual(occupation_group("工人"),"生产制造维修")

    def test_no_name_only_or_different_event_merge(self):
        first,key,_ = self.parsed()
        other = dict(self.row, **{})
        other[4] = "2025-11-10"
        second,key2,_ = self.parsed(other,3)
        self.assertNotEqual(key,key2)
        self.assertNotEqual(first["id"],second["id"])
        other[3] = None
        third,key3,_ = self.parsed(other,3)
        fourth,key4,_ = self.parsed(other,4)
        self.assertNotEqual(key3,key4)
        self.assertIn("unmerged",third["deduplication"]["method"])

    def test_missing_identity_keeps_case_but_does_not_merge(self):
        spec = dict(self.spec,columns=dict(self.spec["columns"],basic=9))
        cells = dict(self.row)
        cells[1] = None
        cells[9] = "信息未完整登记"
        parsed, skipped = _row_record(cells,spec,"s",2,2025,self.salt)
        self.assertIsNone(skipped)
        self.assertIn("unmerged",parsed[0]["deduplication"]["method"])

    def test_source_conflict_and_admin_duplicate_are_not_summed(self):
        first,key,_ = self.parsed()
        changed = dict(self.row)
        changed[7] = "输入病例"
        second,key2,_ = self.parsed(changed,3)
        merged = _merge(first,second,True)
        self.assertEqual(key,key2)
        self.assertEqual(merged["origin"],"conflict")
        self.assertEqual(merged["deduplication"]["merged_records"],2)
        self.assertEqual(len(merged["source_refs"]),2)

    def test_foreign_residence_does_not_inherit_activity_street(self):
        sites = extract_sites("南山区南头街道示例花园8栋801房","西乡街道试验工业区2栋","西乡","试验","activity")
        self.assertFalse(any(s["role"] == "residence" for s in sites))
        self.assertTrue(any(s["role"] == "work" for s in sites))

    def test_no_fuzzy_place_aliasing(self):
        self.assertNotEqual(normalize_site_name("桃园居"),normalize_site_name("桃源居"))
        self.assertNotEqual(site_key("西乡","示例花园"),site_key("新安","示例花园"))
        self.assertIsNone(site_key(None,"示例花园"))

    def test_named_estate_suffixes_and_administrative_prefixes(self):
        examples = [
            ("深圳市宝安区海乐社区海乐华府2栋201", "新安", "区海乐", "海乐", "海乐华府"),
            ("广东省深圳市宝安区新安街道海华社区示例公馆8栋801", "新安", "区海华", "海华", "示例公馆"),
            ("西乡街道桃源居8区201房", "西乡", "桃源", "桃源", "桃源居"),
            ("福海街道桥头社区桥头鸿德园8栋801", "福海", "桥头", "桥头", "桥头鸿德园"),
            ("福海街道桥头社区鸿德园8栋801", "福海", "桥头", "桥头", "鸿德园"),
        ]
        for address, street, community, expected_community, expected_name in examples:
            with self.subTest(name=expected_name):
                result = extract_sites(address, None, street, community)
                self.assertEqual(result[0]["name"], expected_name)
                self.assertEqual(result[0]["community"], expected_community)
                self.assertEqual(result[0]["match_status"], "candidate_extracted")
        self.assertIsNone(extract_sites("新安街道示例园8号",None,"新安","新安湖")[0]["name"])
        self.assertEqual(extract_sites("新安街道示例园8号",None,"新安","新安湖")[0]["community"],"新安湖")

    def test_source_manifest_is_required_and_drift_fails(self):
        with self.assertRaises(ValidationError): build_registry({},self.salt)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/"source.xlsx"
            path.write_bytes(b"synthetic")
            source={"source_id":"s","path":str(path),"sha256":"wrong","sheets":[self.spec]}
            with self.assertRaises(ValidationError): build_registry({"sources":[source]},self.salt)

    def test_build_deduplicates_and_retains_explicit_provenance(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/"source.xlsx"
            path.write_bytes(b"synthetic")
            source={"source_id":"s","path":str(path),"sha256":file_hash(path),"year":2025,"year_basis":"Synthetic fixture explicit year", "sheets":[self.spec]}
            content=[{"kind":"table_row","source_ref":{"sheet":"synthetic","row":n},"cells":[{"column":c,"value":v} for c,v in self.row.items()]} for n in (2,3)]
            with patch("vector_control.history_import.extract_local",return_value={"content":content}):
                result=build_registry({"sources":[source]},self.salt)
            self.assertEqual(result["quality"]["raw_case_records"],2)
            self.assertEqual(result["quality"]["deduplicated_cases"],1)
            self.assertEqual(result["cases"][0]["source_refs"][1]["row"],3)
            self.assertEqual(result["quality"]["confirmed_outbreak_data"],"not_provided")


if __name__ == "__main__": unittest.main()
