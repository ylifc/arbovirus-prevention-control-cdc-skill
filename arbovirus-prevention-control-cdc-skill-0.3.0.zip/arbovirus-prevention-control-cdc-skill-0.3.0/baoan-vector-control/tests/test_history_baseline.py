"""Descriptive climate frequencies do not turn missingness into controls."""
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from vector_control.history_baseline import climate_baseline
from vector_control.history_weather import DAILY_UNITS


def fixture():
    start, end = date(2025, 1, 1), date(2025, 2, 28)
    return {
        "schema_version": "1.0", "kind": "historical_daily_weather", "timezone": "Asia/Shanghai",
        "start_date": start.isoformat(), "end_date": end.isoformat(),
        "points": {"public": {"metadata": {"source_type": "reanalysis", "model": "era5",
            "source_ref": "https://archive-api.open-meteo.com/v1/archive", "units": dict(DAILY_UNITS)},
            "daily": [{"date": (start + timedelta(days=i)).isoformat(),
                       "temperature_mean_c": 26, "precipitation_sum_mm": 0}
                      for i in range((end - start).days + 1)]}}, "errors": [],
    }


class HistoryBaselineTests(unittest.TestCase):
    def test_inclusive_anchor_bounds_and_all_bins(self):
        result = climate_baseline(fixture(), "2025-01-15", "2025-02-28", "public")
        self.assertEqual(result["anchor_days_total"], 45)
        self.assertEqual(result["complete_anchor_days"], 45)
        self.assertEqual(result["incomplete_anchor_days"], 0)
        self.assertEqual(len(result["bins"]), 30)
        self.assertEqual(result["bins"]["25to28__zero"]["anchor_days"], 45)
        self.assertEqual(result["bins"]["25to28__zero"]["fraction_of_complete_days"], 1)
        self.assertEqual(sum(b["anchor_days"] for b in result["bins"].values()), 45)
        self.assertIn("不是人群暴露分母或发病率", result["interpretation"])

    def test_one_missing_weather_day_invalidates_only_next_14_anchors(self):
        weather = fixture()
        weather["points"]["public"]["daily"][19]["precipitation_sum_mm"] = None
        result = climate_baseline(weather, "2025-01-15", "2025-02-28", "public")
        self.assertEqual(result["incomplete_anchor_days"], 14)
        self.assertEqual(result["complete_anchor_days"], 31)
        self.assertEqual(result["incomplete_anchor_dates"][0], "2025-01-21")
        self.assertEqual(result["incomplete_anchor_dates"][-1], "2025-02-03")
        self.assertNotIn("2025-01-20", result["incomplete_anchor_dates"])
        self.assertEqual(sum(b["anchor_days"] for b in result["bins"].values()), 31)

    def test_missing_preperiod_not_silently_counted_as_dry(self):
        result = climate_baseline(fixture(), "2025-01-01", "2025-01-14", "public")
        self.assertEqual(result["complete_anchor_days"], 0)
        self.assertEqual(result["incomplete_anchor_days"], 14)
        self.assertTrue(all(b["anchor_days"] == 0 for b in result["bins"].values()))
        self.assertTrue(all(b["fraction_of_complete_days"] is None for b in result["bins"].values()))

    def test_changed_weather_appears_only_after_anchor_day(self):
        weather = fixture()
        weather["points"]["public"]["daily"][14]["precipitation_sum_mm"] = 50
        same_day = climate_baseline(weather, "2025-01-15", "2025-01-15", "public")
        next_day = climate_baseline(weather, "2025-01-16", "2025-01-16", "public")
        self.assertEqual(same_day["bins"]["25to28__zero"]["anchor_days"], 1)
        self.assertEqual(next_day["bins"]["25to28__50to100"]["anchor_days"], 1)

    def test_unknown_provenance_never_produces_baseline_denominator(self):
        weather = fixture()
        weather["points"]["public"]["metadata"]["source_type"] = "unknown"
        result = climate_baseline(weather, "2025-01-15", "2025-02-28", "public")
        self.assertEqual(result["complete_anchor_days"], 0)

    def test_reversed_range_unknown_point_and_raw_integrity_fail_closed(self):
        with self.assertRaises(ValueError):
            climate_baseline(fixture(), "2025-02-01", "2025-01-01", "public")
        with self.assertRaises(ValueError):
            climate_baseline(fixture(), "2025-01-01", "2025-02-01", "missing")
        weather = fixture()
        weather["points"]["public"]["metadata"]["raw_response"] = "tampered"
        with self.assertRaises(ValueError):
            climate_baseline(weather, "2025-01-15", "2025-02-28", "public")


if __name__ == "__main__":
    unittest.main()
