import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from vector_control import workflow
from vector_control.common import ValidationError, read_json, write_json, file_hash


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)
        self.data = read_json(ROOT / "assets/example_input.json")
        self.input = self.path / "input.json"
        write_json(self.input, self.data)

    def tearDown(self): self.tmp.cleanup()

    def prepare(self): return workflow.prepare(self.input, self.path / "bundle", "none", history_source="none", previous_paths=[])

    def test_replay_deterministic_and_no_network(self):
        result = self.prepare()
        with patch("urllib.request.urlopen", side_effect=AssertionError("network forbidden")):
            a = workflow.replay(result["lock"], self.path / "a")
            b = workflow.replay(result["lock"], self.path / "b")
        self.assertEqual(a["run_fingerprint"], b["run_fingerprint"])
        for name in ["assessment.json", "risk_register.csv", "report.html"]:
            self.assertEqual((self.path / "a" / name).read_bytes(), (self.path / "b" / name).read_bytes())

    def test_tampered_input_stops(self):
        result = self.prepare()
        (self.path / "bundle/inputs/normalized.json").write_text("{}")
        with self.assertRaisesRegex(ValidationError, "漂移"):
            workflow.replay(result["lock"], self.path / "out")

    def test_tampered_lock_stops(self):
        result = self.prepare()
        (self.path / "bundle/lock.json").write_text("{}")
        with self.assertRaisesRegex(ValidationError, "指纹"):
            workflow.replay(result["lock"], self.path / "out")

    def test_code_drift_stops(self):
        result = self.prepare()
        with patch.object(workflow, "code_files", return_value=[]):
            with self.assertRaisesRegex(ValidationError, "代码漂移"):
                workflow.replay(result["lock"], self.path / "out")

    def test_missing_local_input_never_fetches(self):
        with patch("vector_control.weather.prepare_weather", side_effect=AssertionError("no fetch")):
            with self.assertRaises(ValidationError): workflow.prepare(self.path / "missing.json", self.path / "bundle")

    def test_missing_local_weather_never_falls_back(self):
        with patch("vector_control.weather.prepare_weather", side_effect=AssertionError("no fallback")):
            with self.assertRaises((ValueError, OSError)): workflow.prepare(self.input, self.path / "bundle", str(self.path / "missing-weather.json"))
        self.assertFalse((self.path / "bundle").exists())

    def test_production_cannot_prepare(self):
        with self.assertRaisesRegex(ValidationError, "生产"):
            workflow.prepare(self.input, self.path / "bundle", phase="PRODUCTION")

    def test_existing_output_never_overwritten(self):
        self.prepare()
        with self.assertRaisesRegex(ValidationError, "已存在"): self.prepare()

    def test_source_snapshots_captured_before_fetch(self):
        source = self.path / "source.txt"; source.write_text("version one")
        self.data["source_documents"] = [{"path": str(source)}]; write_json(self.input, self.data)
        def fetch(points, as_of, *args, **kwargs):
            source.write_text("version two")
            return {"schema_version": "1.0", "as_of": as_of, "points": {}, "errors": []}
        with patch("vector_control.weather.prepare_weather", side_effect=fetch):
            result = workflow.prepare(self.input, self.path / "bundle", "auto", history_source="none", previous_paths=[])
        manifest = read_json(self.path / "bundle/input_manifest.json")
        row = manifest["source_records"][1]
        self.assertEqual(row["sha256"], row["snapshot_sha256"])
        self.assertEqual((self.path / "bundle" / row["snapshot"]).read_text(), "version one")
        workflow.replay(result["lock"], self.path / "out")

    def test_html_and_csv_are_escaped(self):
        self.data["sites"][0]["name"] = '=HYPERLINK("x")<script>alert(1)</script>'
        write_json(self.input, self.data)
        result = self.prepare()
        workflow.replay(result["lock"], self.path / "out")
        html = (self.path / "out/report.html").read_text()
        self.assertNotIn("<script>", html)
        self.assertIn("&lt;script&gt;", html)
        self.assertIn("'=HYPERLINK", (self.path / "out/risk_register.csv").read_text(encoding="utf-8-sig"))


if __name__ == "__main__": unittest.main()
