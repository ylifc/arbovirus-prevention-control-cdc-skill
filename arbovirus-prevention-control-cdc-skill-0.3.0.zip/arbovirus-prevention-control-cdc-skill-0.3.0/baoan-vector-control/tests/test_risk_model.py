import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from vector_control.common import ValidationError
from vector_control.validation import validate_input
from vector_control.engine import assess
from vector_control.episodes import presence_evidence, reviewed_origin, summarize_episode
from vector_control.risk_model import score_from_probability, assess_risk_models


class RiskModelTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((ROOT / 'assets/example_input.json').read_text())
        self.profile = json.loads((ROOT / 'profiles/baoan.json').read_text())
        self.rules = json.loads((ROOT / 'rules/cn-vector-2026.json').read_text())

    def run_assessment(self):
        data, warnings = validate_input(self.data, self.profile, self.rules)
        result = assess(data, self.profile, self.rules, {'points': {}}, warnings)
        return data, result

    def first_row(self):
        data, assessment = self.run_assessment()
        return data, next(r for r in assessment['site_assessments'] if r['site_id'] == 'DEMO-A' and r['disease'] == 'DENV')

    def test_probability_bins_and_invalid_values(self):
        self.assertEqual([score_from_probability(p) for p in (0, .0999, .1, .5, .9, 1)], [1, 1, 2, 6, 10, 10])
        for p in (True, -1, 1.01, float('nan'), float('inf'), None):
            with self.assertRaises(ValueError):
                score_from_probability(p)

    def test_case_only_dataset_does_not_create_probability(self):
        data, result = self.run_assessment()
        values = assess_risk_models(data, result, {}, {}, self.rules)['rows']
        self.assertTrue(all(r['score_1_to_10'] is None and r['probability'] is None for r in values))
        self.assertTrue(any(r['action_priority'] == 'P0' for r in values))

    def test_broader_local_is_not_baoan_local(self):
        case = self.data['cases'][0]
        case.update(origin_scope='guangdong', origin_known_at=case['known_at'])
        self.assertEqual(reviewed_origin(case, self.data['assessment_at']), 'unknown')
        _, row = self.first_row()
        self.assertEqual(row['site_local_count'], 2)

    def test_future_origin_revision_rejected(self):
        self.data['cases'][0]['origins'] = {'baoan': {'classification': 'local', 'reviewed': True, 'evidence_ref': 'test', 'known_at': '2026-10-04T00:00:00+08:00'}}
        with self.assertRaises(ValidationError): self.run_assessment()

    def test_diagnostic_conflict_does_not_count_positive(self):
        self.data['cases'][0]['diagnostic_conflict'] = True
        _, row = self.first_row()
        self.assertEqual(row['site_local_count'], 2)
        ev = presence_evidence(self.data, 'DEMO-A', 'DENV', self.rules)
        self.assertIsNone(ev['possible_infectious_presence_person_hours'])

    def test_overlapping_presence_not_double_counted(self):
        event = copy.deepcopy(self.data['activities'][0]); event['event_id'] = 'duplicate-interview'
        self.data['activities'].append(event)
        ev = presence_evidence(self.data, 'DEMO-A', 'DENV', self.rules)
        self.assertEqual(ev['possible_infectious_presence_person_hours'], 1.5)
        self.assertEqual(ev['by_protection_person_hours']['unknown'], 1.5)
        self.assertIsNone(ev['by_protection_person_hours']['unprotected'])

    def test_imported_presence_is_not_a_negative_outcome(self):
        self.data['cases'] = self.data['cases'][:1]
        self.data['activities'] = self.data['activities'][:1]
        case = self.data['cases'][0]
        case.update(origin='imported', origin_scope='baoan', origin_known_at=case['known_at'])
        data, row = self.first_row()
        episode = summarize_episode(data, row, self.rules)
        self.assertEqual(episode['branch'], 'imported')
        self.assertIsNone(episode['outcome'])
        self.assertEqual(episode['followup_status'], 'not_adjudicated')

    def test_unknown_sources_not_mixed_with_invented_probability(self):
        for c in self.data['cases']:
            c.pop('origin_scope', None); c.pop('origin_known_at', None)
        data, row = self.first_row()
        episode = summarize_episode(data, row, self.rules)
        self.assertEqual(episode['source_scenarios'], ['imported', 'local'])
        self.assertIsNone(episode['confirmed_transmission_chains'])

    def test_local_with_imported_keeps_imported_pressure(self):
        for c in self.data['cases'][:3]:
            c.update(origin_scope='baoan', origin_known_at='2026-10-02T00:00:00+08:00')
        self.data['cases'][0]['origin'] = 'imported'
        data, row = self.first_row()
        episode = summarize_episode(data, row, self.rules)
        self.assertEqual(episode['branch'], 'local')
        self.assertEqual(episode['imported_presence_case_ids'], ['C01'])

    def test_new_origin_contract_drives_rules_without_old_local_field(self):
        for c in self.data['cases'][:3]:
            c['origin'] = 'unknown'; c.pop('origin_ref', None)
            c['origins'] = {'baoan': {'classification': 'local', 'reviewed': True, 'known_at': '2026-10-02T00:00:00+08:00', 'evidence_ref': 'review'}}
        _, row = self.first_row()
        self.assertEqual((row['site_local_count'], row['priority']), (3, 'P0'))

    def test_future_activity_or_observation_knowledge_rejected(self):
        for collection in ('activities', 'observations'):
            with self.subTest(collection=collection):
                self.setUp()
                self.data[collection][0]['known_at'] = '2026-10-04T00:00:00+08:00'
                with self.assertRaises(ValidationError): self.run_assessment()

    def test_person_id_unions_overlapping_record_versions(self):
        c = self.data['cases'][0]; c['person_id'] = 'same-person'
        duplicate = copy.deepcopy(c); duplicate['case_id'] = 'revision'
        self.data['cases'].append(duplicate)
        event = copy.deepcopy(self.data['activities'][0]); event.update(case_id='revision', event_id='revision-event')
        self.data['activities'].append(event)
        self.assertEqual(presence_evidence(self.data, 'DEMO-A', 'DENV', self.rules)['possible_infectious_presence_person_hours'], 1.5)

    def test_unresolved_place_does_not_have_determined_branch(self):
        for c in self.data['cases'][:3]:
            c.update(origin_scope='baoan', origin_known_at='2026-10-02T00:00:00+08:00')
        self.data['sites'][0]['location_status'] = 'ambiguous'
        data, row = self.first_row()
        self.assertEqual(summarize_episode(data, row, self.rules)['branch'], 'unknown_or_conflict')

    def test_same_event_multiple_versions_rejected(self):
        for c in self.data['cases'][:2]: c['case_event_id'] = 'same-event'
        with self.assertRaises(ValidationError): self.run_assessment()

    def test_unscoped_source_does_not_count_as_baoan_local(self):
        for c in self.data['cases']: c.pop('origin_scope', None)
        _, row = self.first_row()
        self.assertEqual((row['site_local_count'], row['priority']), (0, 'P1'))

    def test_previous_comparison_includes_new_model_fields(self):
        from vector_control.history import compare_previous
        data, result = self.run_assessment()
        result['risk_model_assessment'] = assess_risk_models(data, result, {}, {}, self.rules)
        old = copy.deepcopy(result)
        next(r for r in old['risk_model_assessment']['rows'] if r['site_id'] == 'DEMO-A' and r['disease'] == 'DENV')['branch'] = 'imported'
        compared = compare_previous(result, [old])
        row = next(r for r in compared['rows'] if r['site_id'] == 'DEMO-A' and r['disease'] == 'DENV')
        self.assertEqual(row['changed_factors']['model_branch'], {'previous': 'imported', 'current': 'local'})


if __name__ == '__main__': unittest.main()
