"""Historical climate windows, completeness, and acquisition boundaries."""
import copy
import json
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs, urlparse
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from vector_control import history_weather as hw

POINTS = [{"point_id": "background", "latitude": 22.6, "longitude": 113.9, "source_ref": "public engineering background point"}]


def fixture():
    return {
        "schema_version": "1.0", "kind": "historical_daily_weather", "timezone": "Asia/Shanghai",
        "start_date": "2025-01-01", "end_date": "2025-01-15",
        "points": {"background": {"metadata": {"source_type": "reanalysis", "model": "era5",
                     "source_ref": hw.ENDPOINT, "units": dict(hw.DAILY_UNITS), "latitude": 22.6, "longitude": 113.9},
                     "daily": [{"date": f"2025-01-{day:02d}", "temperature_mean_c": 25, "precipitation_sum_mm": 1} for day in range(1, 16)]}},
        "errors": [],
    }


class HistoryWeatherTests(unittest.TestCase):
    def test_anchor_day_excluded_and_year_boundary_complete(self):
        snap = fixture()
        snap["points"]["background"]["daily"][-1].update(temperature_mean_c=60, precipitation_sum_mm=999)
        result = hw.window_features(hw.validate_history_weather(snap, POINTS), "background", "2025-01-15")
        self.assertEqual(result["window_start"], "2025-01-01")
        self.assertEqual(result["window_end_exclusive"], "2025-01-15")
        self.assertEqual(result["temperature_mean_14d_c"], 25)
        self.assertEqual(result["rainfall_14d_mm"], 14)
        self.assertTrue(result["complete"])
        early = hw.window_features(snap, "background", "2025-01-01")
        self.assertEqual(early["window_start"], "2024-12-18")
        self.assertFalse(early["complete"])
        self.assertEqual(len(early["missing_rainfall_days"]), 14)

    def test_missing_is_not_zero_and_partial_sum_unavailable(self):
        snap = fixture()
        snap["points"]["background"]["daily"][3]["precipitation_sum_mm"] = None
        result = hw.window_features(hw.validate_history_weather(snap), "background", "2025-01-15")
        self.assertFalse(result["complete"])
        self.assertIsNone(result["rainfall_14d_mm"])
        self.assertEqual(result["missing_rainfall_days"], ["2025-01-04"])
        self.assertEqual(result["temperature_mean_14d_c"], 25)

    def test_true_zero_is_complete_and_distinct_from_missing(self):
        snap = fixture()
        for row in snap["points"]["background"]["daily"]:
            row["precipitation_sum_mm"] = 0
        result = hw.window_features(hw.validate_history_weather(snap), "background", "2025-01-15")
        self.assertTrue(result["complete"])
        self.assertEqual(result["rainfall_14d_mm"], 0)

    def test_duplicate_conflict_missing_identical_not_double_counted(self):
        snap = fixture()
        daily = snap["points"]["background"]["daily"]
        daily.append(dict(daily[0]))
        normalized = hw.validate_history_weather(snap)
        self.assertEqual(len(normalized["points"]["background"]["daily"]), 15)
        daily.append(dict(daily[1], precipitation_sum_mm=50))
        normalized = hw.validate_history_weather(snap)
        self.assertIn("duplicate_date_conflict", normalized["points"]["background"]["quality"]["issues"])
        self.assertFalse(hw.window_features(normalized, "background", "2025-01-15")["complete"])

    def test_raw_hash_units_source_and_point_contracts(self):
        for field, value in (("raw_response", "{}"), ("units", {"temperature_mean_c": "F"}), ("source_type", "observation"), ("latitude", 0)):
            snap = fixture()
            snap["points"]["background"]["metadata"][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                hw.validate_history_weather(snap, POINTS)

    def test_unknown_provenance_cannot_produce_comparable_window(self):
        snap = fixture()
        snap["points"]["background"]["metadata"].update(source_type="unknown")
        normalized = hw.validate_history_weather(snap)
        self.assertFalse(normalized["points"]["background"]["quality"]["provenance_usable"])
        result = hw.window_features(normalized, "background", "2025-01-15")
        self.assertFalse(result["complete"])
        self.assertIsNone(result["rainfall_14d_mm"])

    def test_bad_numbers_missing_and_wrong_dates_filtered(self):
        snap = fixture()
        daily = snap["points"]["background"]["daily"]
        daily[0].update(temperature_mean_c=float("nan"), precipitation_sum_mm=-1)
        daily.append({"date": "2026-01-01", "temperature_mean_c": 20, "precipitation_sum_mm": 2})
        daily.append({"date": "bad"})
        normalized = hw.validate_history_weather(snap)
        self.assertEqual(len(normalized["points"]["background"]["daily"]), 15)
        self.assertFalse(hw.window_features(normalized, "background", "2025-01-15")["complete"])
        json.dumps(normalized, allow_nan=False)

    def test_bin_boundaries_and_missing_do_not_become_high_risk(self):
        self.assertEqual(hw.climate_bin(25, 1)["key"], "25to28__1to10")
        self.assertEqual(hw.climate_bin(28, 10)["key"], "28to32__10to50")
        self.assertEqual(hw.climate_bin(32, 100)["key"], "ge32__ge100")
        self.assertEqual(hw.climate_bin(19.9, 0)["key"], "lt20__zero")
        self.assertIsNone(hw.climate_bin(25, None))
        self.assertIsNone(hw.climate_bin(float("nan"), 0))
        self.assertIn("非高低风险阈值", hw.climate_bin(25, 1)["interpretation"])

    def test_acquisition_sends_only_public_coordinates_and_fixed_variables(self):
        payload = {"utc_offset_seconds": 28800, "latitude": 22.6, "longitude": 113.9,
                   "daily_units": {"temperature_2m_mean": "°C", "precipitation_sum": "mm"},
                   "daily": {"time": ["2025-01-01"], "temperature_2m_mean": [20], "precipitation_sum": [0]}}
        points = copy.deepcopy(POINTS)
        points[0]["patient_name"] = "private name must not be sent"
        with patch.object(hw, "_request", return_value=json.dumps(payload)) as request:
            result = hw.build_history_weather("2025-01-01", "2025-01-01", points)
        params = parse_qs(urlparse(request.call_args.args[0]).query)
        self.assertEqual(params["models"], ["era5"])
        self.assertEqual(params["daily"], ["temperature_2m_mean,precipitation_sum"])
        self.assertNotIn("patient_name", str(result))
        self.assertNotIn("patient", request.call_args.args[0])
        self.assertTrue(result["points"]["background"]["quality"]["complete"])
        self.assertEqual(result["points"]["background"]["metadata"]["source_type"], "reanalysis")

    def test_failure_returns_missing_point_and_error(self):
        with patch.object(hw, "_request", side_effect=RuntimeError("unavailable")):
            result = hw.build_history_weather("2025-01-01", "2025-01-15", POINTS)
        self.assertEqual(len(result["errors"]), 1)
        self.assertFalse(hw.window_features(result, "background", "2025-01-15")["complete"])

    def test_future_range_refused_and_no_arbitrary_lag(self):
        with patch.object(hw, "_now", return_value=datetime(2025, 1, 15, tzinfo=ZoneInfo("Asia/Shanghai"))), self.assertRaises(ValueError):
            hw.build_history_weather("2025-01-01", "2025-01-15", POINTS)
        with self.assertRaises(ValueError):
            hw.window_features(fixture(), "background", "2025-01-15", days=7)


if __name__ == "__main__":
    unittest.main()
