import copy
import sys
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from vector_control.common import digest, file_hash, write_json, ValidationError
from vector_control.history import compare_history, _eligible_at_T, imported_local_candidates
from vector_control.history_upgrade import climate_bin_v2, BIN_VERSION, build_audited_history, _verified_inputs, _scope


class AuditedHistoryTests(unittest.TestCase):
    def setUp(self):
        self.meta = {'provider': 'open-meteo', 'model': 'era5', 'source_type': 'reanalysis',
            'grid_latitude': 22.5, 'grid_longitude': 114.0, 'timezone': 'Asia/Shanghai',
            'units': {'temperature_mean_c': '°C', 'precipitation_sum_mm': 'mm', 'humidity_mean_pct': '%'}}
        records = []
        for i, (disease, origin, occupation, place, r) in enumerate([
            ('CHIKV','local','工人','甲花园',40), ('CHIKV','imported','工人','甲花园',40),
            ('CHIKV','unknown','电工','甲花园',40), ('CHIKV','local','工人','乙花园',40),
            ('CHIKV','local','工人','甲花园',150), ('DENV','local','工人','甲花园',40)]):
            records.append({'id': str(i), 'aliases': ['old'+str(i)], 'disease': disease, 'status': 'recorded',
                'onset_date': '2025-09-01', 'report_date': '2025-09-02', 'origin': origin,
                'origin_known_at': None, 'origin_revision_known_at': None, 'record_observed_at': '2026-10-13',
                'occupation_raw': occupation, 'occupation_group': '生产制造维修', 'population_group':'18–59岁',
                'source_refs': [], 'sites': [{'name':place,'street':'西乡','community':'甲','role':'residence','comparison_key':'西乡|'+place}],
                'climate_by_point': {'baoan_south_background': {'complete':True,'bin':climate_bin_v2(27,r),'provenance':copy.deepcopy(self.meta)}}})
        self.history = {'schema_version':'1.0','kind':'baoan_history_comparison','comparison_version':'2.0','cases':records,
            'weather_metadata': {'baoan_south_background':copy.deepcopy(self.meta)},'supplemental_cases':[]}
        self.data = {'assessment_at':'2025-10-12T12:00:00+08:00',
            'cases':[{'case_id':'NEW','disease':'CHIKV','onset_date':'2025-10-10','occupation':'工人','site_links':[{'site_id':'S'}]}],
            'sites':[{'site_id':'S','name':'甲花园','street':'西乡','community':'甲'}],'activities':[]}
        self.weather = {'weather_archive':{'anchors':{'2025-10-10':{'points':{'baoan_south_background':{
            'metadata':copy.deepcopy(self.meta),'features':{'14':{'complete':True,'days':14,'window_start':'2025-09-26',
             'window_end_exclusive':'2025-10-10','temperature_mean_c':27,'precipitation_sum_mm':40}}}}}}}}
        self.rehash()

    def rehash(self):
        self.history['fingerprint'] = digest({k:v for k,v in self.history.items() if k != 'fingerprint'})

    def row(self):
        return compare_history(self.data, self.weather, self.history)['site_comparisons'][0]

    def test_cross_process_hash_seed_determinism(self):
        import os
        import subprocess
        for cid in ('CASE-B', 'CASE-C', 'CASE-D'):
            c = copy.deepcopy(self.data['cases'][0]); c['case_id'] = cid
            self.data['cases'].append(c)
        payload = json.dumps([self.data, self.weather, self.history])
        script = "import sys,json;sys.path.insert(0,sys.argv[1]);from vector_control.history import compare_history;from vector_control.common import digest;print(digest(compare_history(*json.load(sys.stdin))))"
        outputs = []
        for seed in ('11', '29'):
            process = subprocess.run([sys.executable, '-c', script, str(ROOT / 'scripts')],
                                     input=payload, text=True, capture_output=True, check=True,
                                     timeout=15, env=dict(os.environ, PYTHONHASHSEED=seed))
            outputs.append(process.stdout)
        self.assertEqual(outputs[0], outputs[1])

    def test_disease_and_origin_separate_with_real_intersections(self):
        row = self.row()
        self.assertEqual(row['district_history']['registered_cases'],5)
        self.assertEqual(row['district_history']['local'],3)
        self.assertEqual(row['site_and_climate_history']['registered_cases'],3)
        exact = row['occupational_intersections'][0]['exact_occupation']
        self.assertEqual(exact['site_and_climate_history']['registered_cases'],2)
        self.assertEqual(exact['site_and_climate_history']['local'],1)
        self.assertEqual(exact['site_and_climate_history']['imported'],1)

    def test_final_label_not_leaked_into_T(self):
        row=self.row()
        self.assertEqual(row['district_history']['local'],3)
        self.assertEqual(row['known_at_T']['district_history']['local'],0)
        self.assertEqual(row['known_at_T']['district_history']['unknown'],5)
        self.assertEqual(row['known_at_T']['excluded']['origin_classification_not_known_at_T'],5)

    def test_classification_timestamp_restores_one_known_label(self):
        self.history['cases'][0]['origin_known_at']='2025-09-04'
        self.rehash()
        self.assertEqual(self.row()['known_at_T']['district_history']['local'],1)

    def test_old_alias_excludes_current(self):
        self.data['cases'][0]['historical_case_ids']=['old0']
        row=self.row()
        self.assertEqual(row['district_history']['registered_cases'],4)
        self.assertEqual(row['self_exclusion'][0]['excluded_historical_ids'],['0'])

    def test_diagnostic_conflict_excluded(self):
        self.history['cases'][0]['status']='diagnostic_conflict';self.rehash()
        self.assertEqual(self.row()['district_history']['registered_cases'],4)

    def test_grid_mismatch_null_not_zero(self):
        self.weather['weather_archive']['anchors']['2025-10-10']['points']['baoan_south_background']['metadata']['grid_latitude']=22.75
        row=self.row()
        self.assertIsNone(row['same_climate_history'])
        self.assertIsNone(row['occupational_intersections'][0]['exact_occupation']['site_and_climate_history'])
        self.assertIn('provenance_mismatch:grid_latitude',row['climate']['comparison_reasons'])

    def test_no_archive_is_unknown(self):
        self.weather={}
        self.assertIsNone(self.row()['same_climate_history'])

    def test_same_onset_place_possible_self_is_not_silent(self):
        self.data['cases'][0]['onset_date']='2025-09-01'
        row=self.row()
        self.assertTrue(row['self_exclusion'][0]['counts_may_include_current_case'])
        self.assertTrue(row['self_exclusion'][0]['possible_same_onset_place_ids'])

    def test_future_record_and_currentday_excluded(self):
        self.history['cases'][0]['report_date']='2025-10-12'
        self.history['cases'][1]['positive_date']='2025-10-13'
        self.rehash()
        self.assertEqual(self.row()['district_history']['registered_cases'],3)

    def test_case_known_missing_not_in_T_counts(self):
        self.history['cases'][0]['report_date']=None;self.rehash()
        row=self.row()
        self.assertEqual(row['district_history']['registered_cases'],5)
        self.assertEqual(row['known_at_T']['district_history']['registered_cases'],4)

    def test_supplements_never_added_to_primary(self):
        self.history['supplemental_cases']=[dict(self.history['cases'][0],id='SUPPLEMENT')];self.rehash()
        row=self.row()
        self.assertEqual(row['district_history']['registered_cases'],5)
        self.assertEqual(row['supplemental_history_not_additive']['district_history']['registered_cases'],1)

    def test_pair_counts_are_not_episode_counts(self):
        cases = copy.deepcopy(self.history['cases'][:4])
        for c in cases:
            c['sites'][0]['name']='甲花园';c['sites'][0]['comparison_key']='西乡|甲花园'
            c['origin']='local'
        cases[0]['origin']='imported'
        for i,c in enumerate(cases): c['onset_date']='2025-09-'+str(i+1).zfill(2)
        result=imported_local_candidates(cases,'CHIKV')
        self.assertEqual(len(result['candidate_pairs']),3)
        self.assertEqual(result['candidate_episode_groups']['28']['candidate_episode_group_count'],1)
        self.assertIsNone(result['confirmed_transmission_events'])
        self.assertIsNone(result['confirmed_secondary_cases'])

    def test_other_disease_context_does_not_join_CHIKV(self):
        row=self.row()
        self.assertEqual(row['district_history']['registered_cases'],5)
        self.assertEqual(row['other_disease_environment_context']['district_history']['registered_cases'],1)
        self.assertEqual(row['other_disease_environment_context']['disease'],'DENV')

    def test_historical_reanalysis_not_claimed_known_at_T(self):
        row=self.row()
        self.assertIsNotNone(row['same_climate_history'])
        self.assertIsNone(row['known_at_T']['same_climate_history'])
        self.assertIsNone(row['known_at_T']['occupational_intersections'][0]['exact_occupation']['climate_history'])

    def test_province_local_does_not_imply_baoan_local(self):
        self.assertEqual(_scope('DENV', {'origin_specificity':'guangdong', 'exact_scoped_origin':'unknown'}),
            {'province':'local_candidate', 'city':'unknown', 'baoan':'unknown'})

    def test_bins_are_descriptive_versioned_boundaries(self):
        self.assertEqual(climate_bin_v2(28,50)['key'],'≥28|50–<100')
        self.assertEqual(climate_bin_v2(25,0)['version'],BIN_VERSION)
        self.assertIsNone(climate_bin_v2(None,0))


class HistoryMaintenanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.addCleanup(self.temp.cleanup)
        inputs = {}
        for key in ['chikv','denv','weather_features','weather_manifest','weather_baseline','weather_update','legacy_history']:
            path=self.root/(key+'.data');path.write_text(key)
            inputs[key]={'path':str(path),'sha256':file_hash(path)}
        for key in ['chikv','denv']:
            original=self.root/(key+'.original');original.write_text('original '+key)
            inputs[key].update(original_path=str(original), original_sha256=file_hash(original))
        self.manifest={'kind':'baoan_audited_history_manifest','schema_version':'1.0','inputs':inputs}
        self.path=self.root/'manifest.json';write_json(self.path,self.manifest)
        self.output=self.root/'ready';self.output.mkdir()
        history={'schema_version':'1.0','kind':'baoan_history_comparison','cases':[]}
        history['fingerprint']=digest(history)
        write_json(self.output/'history.json',history)
        write_json(self.output/'registry.json',{'status':'READY','source_manifest_sha256':file_hash(self.path),
            'runtime_entry':'history.json','files':{'history.json':file_hash(self.output/'history.json')}})

    def test_identical_intake_verifies_and_reuses_ready_without_write(self):
        before={p.name:file_hash(p) for p in self.output.iterdir()}
        result=build_audited_history(self.path,self.output)
        self.assertEqual(result['operation'],'verified_idempotent_reuse')
        self.assertEqual(before,{p.name:file_hash(p) for p in self.output.iterdir()})

    def test_raw_original_hash_drift_stops_before_reuse(self):
        Path(self.manifest['inputs']['chikv']['original_path']).write_text('different')
        with self.assertRaises(ValidationError):build_audited_history(self.path,self.output)

    def test_derived_audit_hash_drift_stops(self):
        Path(self.manifest['inputs']['denv']['path']).write_text('different')
        with self.assertRaises(ValidationError):build_audited_history(self.path,self.output)

    def test_ready_artifact_drift_stops_without_rebuilding(self):
        (self.output/'history.json').write_text('{}')
        with self.assertRaises(ValidationError):build_audited_history(self.path,self.output)
        self.assertEqual((self.output/'history.json').read_text(),'{}')

    def test_changed_manifest_cannot_overwrite_ready(self):
        self.manifest['note']='different version';write_json(self.path,self.manifest)
        with self.assertRaises(ValidationError):build_audited_history(self.path,self.output)


if __name__ == '__main__':
    unittest.main()
