"""Weather boundary/quality regression tests (no network required)."""
import copy
import csv
import hashlib
import io
import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from vector_control import weather

POINTS = [{"point_id": "public-grid-01", "latitude": 22.6, "longitude": 113.9, "source_ref": "https://weather.sz.gov.cn/"}]
AS_OF = "2026-10-03T12:00:00+08:00"
PID = POINTS[0]["point_id"]


def fixture():
    cutoff, start, end = weather._window(AS_OF)
    rows = []
    for i in range(337):
        t = start + timedelta(hours=i)
        rows.append({"valid_time": t.isoformat(), "temperature_c": 28, "relative_humidity_pct": 70,
                     "precipitation_mm": 0, "wind_speed_ms": 2, "wind_direction_deg": 90,
                     "precipitation_interval_start": (t - timedelta(hours=1)).isoformat(),
                     "precipitation_interval_end": t.isoformat()})
    return {"schema_version": "1.0", "points": {PID: {"metadata": {"source_type": "observation", "source_ref": "authorized-export", "provider": "local-authorized", "retrieved_at": AS_OF, "published_at": AS_OF, "spatial_resolution": "station"}, "hourly": rows, "current": {"valid_time": AS_OF, "temperature_c": 29, "relative_humidity_pct": 71, "precipitation_mm": 0, "wind_speed_ms": 2, "wind_direction_deg": 90}}}}


class WeatherTests(unittest.TestCase):
    def normalized(self, snap=None):
        return weather.validate_snapshot(snap or fixture(), AS_OF, POINTS)["points"][PID]

    def test_complete_14_calendar_days(self):
        result = weather.validate_snapshot(fixture(), AS_OF, POINTS)
        p = result["points"][PID]
        self.assertTrue(p["quality"]["complete_14_days"])
        self.assertEqual([p["daily"][0]["date"], p["daily"][-1]["date"]], ["2026-09-19", "2026-10-02"])
        self.assertTrue(p["features"]["dry_spell_at_least_14_days"])
        self.assertEqual(p["features"]["dry_days_14"], 14)
        self.assertTrue(p["features"]["dry_spell_is_lower_bound"])

    def test_rainfall_midnight_end_belongs_to_previous_day(self):
        snap = fixture()
        rows = snap["points"][PID]["hourly"]
        rows[0]["precipitation_mm"] = 100  # Before the requested history.
        rows[-1]["precipitation_mm"] = 7  # Oct 2 23:00 .. Oct 3 00:00.
        rows[24]["precipitation_mm"] = 2
        p = self.normalized(snap)
        self.assertEqual(p["daily"][0]["precipitation_mm"], 2)
        self.assertEqual(p["daily"][-1]["precipitation_mm"], 7)
        self.assertEqual(p["features"]["rainfall_14d_mm"], 9)

    def test_timezone_utc_converts_before_daily_aggregation(self):
        snap = fixture()
        r = snap["points"][PID]["hourly"][-1]
        r.update(valid_time="2026-10-02T16:00:00Z", precipitation_interval_start="2026-10-02T15:00:00Z", precipitation_interval_end="2026-10-02T16:00:00Z", precipitation_mm=9)
        self.assertEqual(self.normalized(snap)["daily"][-1]["precipitation_mm"], 9)

    def test_missing_not_zero_or_dry_14(self):
        snap = fixture()
        snap["points"][PID]["hourly"][50]["precipitation_mm"] = None
        p = self.normalized(snap)
        self.assertIsNone(p["features"]["rainfall_14d_mm"])
        self.assertIsNone(p["features"]["dry_spell_at_least_14_days"])
        self.assertFalse(p["quality"]["complete_14_days"])
        self.assertEqual(p["quality"]["missing_hours"]["precipitation_mm"], 1)

    def test_missing_three_consecutive_hours(self):
        snap = fixture()
        del snap["points"][PID]["hourly"][10:13]
        self.assertEqual(self.normalized(snap)["quality"]["longest_missing_run_hours"]["temperature_c"], 3)

    def test_future_rows_and_current_filtered(self):
        snap = fixture()
        snap["points"][PID]["hourly"].append({"valid_time": "2026-10-04T00:00:00+08:00", "temperature_c": 99})
        snap["points"][PID]["current"]["valid_time"] = "2026-10-03T13:00:00+08:00"
        p = self.normalized(snap)
        self.assertIsNone(p["current"])
        self.assertEqual(len(p["hourly"]), 337)
        self.assertIn("future_time_filtered", p["quality"]["issues"])

    def test_stale_current_and_missing_variables(self):
        snap = fixture()
        snap["points"][PID]["current"] = {"valid_time": "2026-10-03T07:00:00+08:00", "temperature_c": 24}
        p = self.normalized(snap)
        self.assertTrue(p["quality"]["current_stale"])
        self.assertFalse(p["quality"]["current_variable_coverage"]["wind_speed_ms"])

    def test_duplicate_conflict_is_rejected_not_arbitrary(self):
        snap = fixture()
        conflict = dict(snap["points"][PID]["hourly"][20], temperature_c=999)
        snap["points"][PID]["hourly"].extend([conflict, conflict])
        p = self.normalized(snap)
        self.assertIsNone(p["hourly"][20]["temperature_c"])
        self.assertIn("duplicate_time_conflict", p["quality"]["issues"])
        self.assertFalse(p["quality"]["complete_14_days"])

    def test_nonfinite_and_bad_bounds(self):
        snap = fixture()
        snap["points"][PID]["hourly"][1].update(temperature_c=float("inf"), relative_humidity_pct=101, precipitation_mm=-1, wind_speed_ms=float("nan"), wind_direction_deg=361)
        p = self.normalized(snap)
        self.assertTrue(all(p["hourly"][1][key] is None for key in weather.VARIABLES))
        json.dumps(p, allow_nan=False)

    def test_precipitation_requires_interval(self):
        snap = fixture()
        r = snap["points"][PID]["hourly"][1]
        r.pop("precipitation_interval_start")
        r["precipitation_mm"] = 20
        p = self.normalized(snap)
        self.assertIsNone(p["hourly"][1]["precipitation_mm"])
        self.assertIn("unknown_or_invalid_precipitation_interval", p["quality"]["issues"])

    def test_raw_sha_mismatch_rejected(self):
        snap = fixture()
        snap["points"][PID]["metadata"].update(raw_response="{}", raw_sha256="wrong")
        with self.assertRaisesRegex(ValueError, "SHA256"):
            self.normalized(snap)

    def test_unknown_point_or_coordinate_change_rejected(self):
        snap = fixture()
        snap["points"]["unexpected"] = snap["points"][PID]
        with self.assertRaises(ValueError):
            self.normalized(snap)
        snap = fixture()
        snap["points"][PID]["metadata"]["latitude"] = 23
        with self.assertRaises(ValueError):
            self.normalized(snap)

    def test_timezone_and_duplicate_profile_validation(self):
        with self.assertRaises(ValueError):
            weather.validate_snapshot(fixture(), "2026-10-03T12:00:00", POINTS)
        with self.assertRaises(ValueError):
            weather.validate_snapshot(fixture(), AS_OF, POINTS * 2)

    def test_snapshot_replay_is_deterministic_offline(self):
        snap = weather.validate_snapshot(fixture(), AS_OF, POINTS)
        with patch.object(weather, "urlopen", side_effect=AssertionError("network forbidden")):
            replay = weather.validate_snapshot(snap, AS_OF, POINTS)
        self.assertEqual(snap, replay)

    def test_json_load_does_not_acquire_and_adds_file_provenance(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "weather.json"
            p.write_text(json.dumps(fixture()), encoding="utf-8")
            with patch.object(weather, "urlopen", side_effect=AssertionError("network forbidden")):
                snap = weather.load_weather(p, POINTS, AS_OF)
            self.assertIn("raw_sha256", snap["import_provenance"])
            self.assertEqual(snap["provider_status"]["official"], "not_connected")

    def test_csv_explicit_units_and_precipitation_semantics(self):
        fields = ["point_id", "valid_time", "source_type", "source_ref", "temperature_c", "precipitation_mm", "precipitation_semantics"]
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "weather.csv"
            with p.open("w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fields)
                writer.writeheader()
                writer.writerow(dict(point_id=PID, valid_time="2026-10-03T00:00:00+08:00", source_type="interpolated_observation", source_ref="authorized-export", temperature_c=28, precipitation_mm=2, precipitation_semantics="preceding_hour"))
            snap = weather.load_weather(p, POINTS, AS_OF)
            row = snap["points"][PID]["hourly"][0]
            self.assertEqual(row["precipitation_interval_start"], "2026-10-02T23:00:00+08:00")
            self.assertEqual(row["precipitation_mm"], 2)
            self.assertFalse(snap["points"][PID]["quality"]["source_is_observation"])

    def test_fetch_historical_drops_actual_current(self):
        payload = {"utc_offset_seconds": 28800, "hourly_units": {api: weather.UNITS[key] for key, api in weather.VARIABLES.items()}, "hourly": {"time": []}, "current": {"time": "2026-10-04T12:00", "temperature_2m": 30}}
        with patch.object(weather, "_now", return_value=weather._dt("2026-10-04T12:00:00+08:00")), patch.object(weather, "_request", return_value=json.dumps(payload)) as request:
            snap = weather.fetch_weather(POINTS, AS_OF)
        self.assertTrue(request.call_args.args[0].startswith("https://historical-forecast-api."))
        self.assertNotIn("&current=", request.call_args.args[0])
        self.assertIsNone(snap["points"][PID]["current"])
        self.assertEqual(snap["points"][PID]["metadata"]["source_type"], "model")
        self.assertIn("retrieved_after_as_of_not_prospective", snap["points"][PID]["quality"]["issues"])

    def test_fetch_failure_is_honest_and_missing(self):
        with patch.object(weather, "_now", return_value=weather._dt(AS_OF)), patch.object(weather, "_request", side_effect=RuntimeError("offline")):
            snap = weather.fetch_weather(POINTS, AS_OF)
        self.assertEqual(snap["provider_status"]["open_meteo"], "failed")
        self.assertEqual(snap["provider_status"]["official"], "not_connected")
        self.assertEqual(snap["points"][PID]["quality"]["missing_hours"]["precipitation_mm"], 336)
        self.assertIsNone(snap["points"][PID]["features"]["rainfall_14d_mm"])

    def test_fetch_future_as_of_no_network(self):
        with patch.object(weather, "_now", return_value=weather._dt("2026-09-03T12:00:00+08:00")), patch.object(weather, "_request", side_effect=AssertionError("network forbidden")):
            snap = weather.fetch_weather(POINTS, AS_OF)
        self.assertEqual(snap["errors"][0]["code"], "future_as_of")

    def test_open_meteo_cannot_be_relabelled_observation(self):
        snap = fixture()
        snap["points"][PID]["metadata"].update(provider="open-meteo", source_type="observation")
        with self.assertRaisesRegex(ValueError, "cannot be labeled observation"):
            self.normalized(snap)

    def test_normalized_unit_mismatch_is_rejected(self):
        snap = fixture()
        snap["points"][PID]["metadata"]["units"] = {"wind_speed_ms": "km/h"}
        with self.assertRaisesRegex(ValueError, "unit mismatch"):
            self.normalized(snap)

    def test_known_rain_excludes_fourteen_dry_days_even_with_gap(self):
        snap = fixture()
        snap["points"][PID]["hourly"][1]["precipitation_mm"] = 2
        snap["points"][PID]["hourly"][2]["precipitation_mm"] = None
        p = self.normalized(snap)
        self.assertIsNone(p["features"]["rainfall_14d_mm"])
        self.assertFalse(p["features"]["dry_spell_at_least_14_days"])

    def test_request_profile_whitelist_no_private_fields(self):
        payload = {"utc_offset_seconds": 28800, "hourly_units": {api: weather.UNITS[key] for key, api in weather.VARIABLES.items()}, "hourly": {"time": []}}
        private_points = [dict(POINTS[0], patient_name="TEST_SECRET", home_address="SECRET_HOME")]
        with patch.object(weather, "_now", return_value=weather._dt(AS_OF)), patch.object(weather, "_request", return_value=json.dumps(payload)) as request:
            weather.fetch_weather(private_points, AS_OF)
        self.assertNotIn("SECRET", request.call_args.args[0])


if __name__ == "__main__":
    unittest.main()
