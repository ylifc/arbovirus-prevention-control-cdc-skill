import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from vector_control.common import read_json, write_json, file_hash, ValidationError
from vector_control.history import compile_history
from vector_control.workflow import prepare, replay


class HistoryWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)
        self.input = self.path / 'input.json'
        write_json(self.input, read_json(ROOT / 'assets/example_input.json'))
        hist = compile_history({'schema_version': '1.0', 'kind': 'baoan_historical_case_registry', 'cases': []})
        write_json(self.path / 'history.json', hist)
        self.registry = self.path / 'registry.json'
        write_json(self.registry, {'status': 'READY', 'runtime_entry': 'history.json', 'files': {'history.json': file_hash(self.path / 'history.json')}})

    def tearDown(self):
        self.tmp.cleanup()

    def test_frozen_history_replay_does_not_read_live_registry(self):
        prepared = prepare(self.input, self.path / 'bundle', 'none', history_source=str(self.registry), previous_paths=[])
        (self.path / 'history.json').write_text('{}')
        with patch('urllib.request.urlopen', side_effect=AssertionError('network forbidden')):
            first = replay(prepared['lock'], self.path / 'out1')
            second = replay(prepared['lock'], self.path / 'out2')
        self.assertEqual(first['run_fingerprint'], second['run_fingerprint'])
        self.assertEqual((self.path / 'out1/historical_comparison.json').read_bytes(), (self.path / 'out2/historical_comparison.json').read_bytes())
        self.assertIn('历史对照', (self.path / 'out1/report.html').read_text())

    def test_history_drift_fails_before_network(self):
        (self.path / 'history.json').write_text('{}')
        with patch('vector_control.weather.prepare_weather', side_effect=AssertionError('must not fetch')):
            with self.assertRaisesRegex(ValidationError, '漂移'):
                prepare(self.input, self.path / 'bundle', 'auto', history_source=str(self.registry), previous_paths=[])

    def test_frozen_history_tamper_rejected(self):
        prepared = prepare(self.input, self.path / 'bundle', 'none', history_source=str(self.registry), previous_paths=[])
        (self.path / 'bundle/inputs/history.json').write_text('{}')
        with self.assertRaisesRegex(ValidationError, '漂移'):
            replay(prepared['lock'], self.path / 'out')


if __name__ == '__main__':
    unittest.main()
