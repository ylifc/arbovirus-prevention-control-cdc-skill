import copy
import sys
import unittest
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from vector_control.common import digest, ValidationError
from vector_control.history import (compile_history, compare_history, rolling_windows, _place_match,
                                    _eligible_cases, _current_climate, compare_previous, occupation_group)
from vector_control.history_weather import climate_bin


class HistoryTests(unittest.TestCase):
    def setUp(self):
        records = []
        for i, (place, rain, origin) in enumerate([('甲花园', 5, 'local'), ('甲花园', 5, 'imported'), ('乙花园', 5, 'local'), ('甲花园', 100, 'local')]):
            records.append({'id': str(i), 'disease': 'CHIKV', 'status': 'recorded', 'onset_date': '2025-10-01',
                'report_date': '2025-10-02', 'positive_date': '2025-10-02', 'origin': origin, 'age': 30,
                'occupation': '商业餐饮及门店服务', 'source_refs': [],
                'sites': [{'street': '西乡', 'community': '甲社区', 'name': place, 'role': 'residence'}]})
        self.history = compile_history({'schema_version': '1.0', 'kind': 'baoan_historical_case_registry', 'cases': records})
        for c, rain in zip(self.history['cases'], [5, 5, 5, 100]):
            c['climate_by_point'] = {'baoan_south_background': {'bin': climate_bin(26, rain)}}
        self.rehash()
        self.data = {'assessment_at': '2026-10-12T12:00:00+08:00',
            'cases': [{'case_id': 'NEW', 'disease': 'CHIKV', 'onset_date': '2026-10-12', 'occupation': '销售', 'age': 30,
                       'site_links': [{'site_id': 'S'}]}],
            'sites': [{'site_id': 'S', 'name': '甲花园', 'street': '西乡', 'community': '甲社区'}], 'activities': []}
        self.weather = {'points': {'baoan_south_background': {'metadata': {'model': 'test'}, 'daily': [
            {'date': (date(2026, 10, 12) - timedelta(days=i)).isoformat(), 'temperature_mean_c': 26, 'precipitation_mm': 5/14}
            for i in range(1, 15)]}}}

    def rehash(self):
        self.history['fingerprint'] = digest({k: v for k, v in self.history.items() if k != 'fingerprint'})

    def compare(self):
        return compare_history(self.data, self.weather, self.history)

    def test_site_climate_intersection_not_sum(self):
        row = self.compare()['site_comparisons'][0]
        self.assertEqual(row['site_history']['registered_cases'], 3)
        self.assertEqual(row['same_climate_history']['registered_cases'], 3)
        self.assertEqual(row['site_and_climate_history']['registered_cases'], 2)
        self.assertEqual(row['site_and_climate_history']['local'], 1)
        self.assertIsNone(row['site_history']['confirmed_outbreak_cases'])

    def test_duplicate_links_not_duplicate_cases(self):
        self.history['cases'][0]['sites'] *= 2
        self.rehash()
        self.assertEqual(self.compare()['site_comparisons'][0]['site_history']['registered_cases'], 3)

    def test_missing_weather_is_unknown_not_zero(self):
        self.weather['points']['baoan_south_background']['daily'].pop()
        row = self.compare()['site_comparisons'][0]
        self.assertIsNone(row['same_climate_history'])
        self.assertIsNone(row['site_and_climate_history'])

    def test_cutoff_excludes_future_positive_and_current_case(self):
        self.history['cases'][0]['positive_date'] = '2026-10-12'
        self.data['cases'][0]['historical_case_ids'] = ['1']
        self.rehash()
        self.assertEqual(self.compare()['site_comparisons'][0]['site_history']['registered_cases'], 1)

    def test_ambiguous_community_never_summed(self):
        self.history['cases'][0]['sites'][0]['community'] = '乙社区'
        self.data['sites'][0].pop('community')
        self.rehash()
        row = self.compare()['site_comparisons'][0]
        self.assertEqual(row['place_match']['status'], 'ambiguous_community')
        self.assertIsNone(row['site_history'])

    def test_explicit_community_filters_unknown_and_other(self):
        self.history['cases'][0]['sites'][0]['community'] = '乙社区'
        self.history['cases'][1]['sites'][0]['community'] = None
        self.rehash()
        self.assertEqual(self.compare()['site_comparisons'][0]['site_history']['registered_cases'], 1)

    def test_partial_place_name_only_candidate(self):
        self.data['sites'][0]['name'] = '甲花园宿舍'
        row = self.compare()['site_comparisons'][0]
        self.assertEqual(row['place_match']['status'], 'candidate_requires_review')
        self.assertIsNone(row['site_history'])

    def test_occupation_uses_same_mapping_for_new_and_history(self):
        p = self.compare()['person_comparisons'][0]
        self.assertEqual(p['occupation_history']['registered_cases'], 4)
        self.assertIn('不能按职业', p['exposure_hint'])

    def test_population_unknown_stays_unknown(self):
        self.data['cases'][0].pop('age')
        self.assertIsNone(self.compare()['person_comparisons'][0]['population_history'])

    def test_rolling_overlaps_not_called_outbreak_events(self):
        cases = copy.deepcopy(self.history['cases'])
        for c in cases: c['origin'] = 'local'
        w = rolling_windows(cases, 'CHIKV')
        self.assertEqual(w['unique_cases_in_windows'], 4)
        self.assertEqual(w['peak_count'], 4)
        self.assertNotIn('outbreak_events', w)

    def test_window_excludes_anchor_day(self):
        self.weather['points']['baoan_south_background']['daily'].append({'date': '2026-10-12', 'temperature_mean_c': 1, 'precipitation_mm': 999})
        c = _current_climate(self.weather, 'baoan_south_background', '2026-10-12')
        self.assertAlmostEqual(c['rainfall_14d_mm'], 5)

    def test_tampered_registry_rejected(self):
        self.history['cases'][0]['origin'] = 'imported'
        with self.assertRaises(ValidationError): self.compare()

    def test_previous_community_conflict_not_compared(self):
        row = {'site_id': 'S', 'site_name': '甲花园', 'street': '西乡', 'community': '甲', 'disease': 'CHIKV', 'risk_level': '高', 'priority': 'P1'}
        old = dict(row, community='乙')
        result = compare_previous({'assessment_at': '2026-10-12', 'site_assessments': [row]}, [{'assessment_at': '2026-10-11', 'site_assessments': [old]}])
        self.assertEqual(result['rows'], [])


if __name__ == '__main__':
    unittest.main()
