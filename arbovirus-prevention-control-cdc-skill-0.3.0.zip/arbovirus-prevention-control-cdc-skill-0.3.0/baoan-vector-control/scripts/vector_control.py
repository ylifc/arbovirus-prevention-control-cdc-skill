#!/usr/bin/env python3
"""Portable entrypoint; no package installation required."""
from vector_control.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
