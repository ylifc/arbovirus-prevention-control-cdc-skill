"""Auditable weather snapshots; standard library only, no implicit official access.

The normalized contract uses Celsius, mm per explicitly bounded hour, m/s,
percent and degrees. Current conditions from Open-Meteo are model estimates.
"""
from __future__ import annotations

import copy
import csv
import hashlib
import io
import json
import math
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Asia/Shanghai")
SCHEMA_VERSION = "1.0"
MODEL = "ecmwf_ifs025"
VARIABLES = {
    "temperature_c": "temperature_2m",
    "relative_humidity_pct": "relative_humidity_2m",
    "precipitation_mm": "precipitation",
    "wind_speed_ms": "wind_speed_10m",
    "wind_direction_deg": "wind_direction_10m",
}
UNITS = {"temperature_c": "°C", "relative_humidity_pct": "%", "precipitation_mm": "mm", "wind_speed_ms": "m/s", "wind_direction_deg": "°"}
SOURCE_TYPES = {"observation", "interpolated_observation", "model", "reanalysis", "unknown"}
MAX_BYTES = 8 * 1024 * 1024


def _now():
    return datetime.now(timezone.utc).astimezone(TZ)


def _dt(value, *, naive_ok=False):
    if not isinstance(value, str):
        raise ValueError("timestamp must be an ISO 8601 string")
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        if not naive_ok:
            raise ValueError("timestamp must include timezone offset")
        dt = dt.replace(tzinfo=TZ)
    return dt.astimezone(TZ)


def _iso(value):
    return value.isoformat(timespec="seconds")


def _window(as_of):
    cutoff = _dt(as_of)
    end = cutoff.replace(hour=0, minute=0, second=0, microsecond=0)
    return cutoff, end - timedelta(days=14), end


def _points(points):
    result = {}
    for p in points:
        pid = p.get("point_id")
        if not isinstance(pid, str) or not pid.strip() or pid in result:
            raise ValueError("point_id must be a unique nonempty string")
        lat, lon = p.get("latitude"), p.get("longitude")
        if isinstance(lat, bool) or isinstance(lon, bool):
            raise ValueError("coordinates must be finite WGS84 numbers")
        try:
            lat, lon = float(lat), float(lon)
        except (TypeError, ValueError) as exc:
            raise ValueError("coordinates must be finite WGS84 numbers") from exc
        if not math.isfinite(lat) or not math.isfinite(lon) or not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise ValueError("coordinates outside WGS84 bounds")
        if not isinstance(p.get("source_ref"), str) or not p["source_ref"].strip():
            raise ValueError("public point provenance source_ref is required")
        # Explicit whitelist: no arbitrary profile data reaches the weather API.
        result[pid] = {"point_id": pid, "latitude": lat, "longitude": lon, "source_ref": p["source_ref"]}
    return result


def _number(value, name, issues):
    if value is None or value == "":
        return None
    try:
        x = float(value)
        if isinstance(value, bool) or not math.isfinite(x):
            raise ValueError
        if (name in {"precipitation_mm", "wind_speed_ms"} and x < 0
                or name == "relative_humidity_pct" and not 0 <= x <= 100
                or name == "wind_direction_deg" and not 0 <= x <= 360):
            raise ValueError
        return x
    except (TypeError, ValueError):
        issues.add("invalid_numeric:" + name)
        return None


def _row(row, cutoff, issues, *, current=False):
    try:
        valid = _dt(row.get("valid_time"))
    except (ValueError, TypeError):
        issues.add("invalid_valid_time")
        return None
    if valid > cutoff:
        issues.add("future_time_filtered")
        return None
    if not current and (valid.minute or valid.second or valid.microsecond):
        issues.add("non_hourly_time_rejected")
        return None
    out = {"valid_time": _iso(valid)}
    for key in VARIABLES:
        out[key] = _number(row.get(key), key, issues)
    if current:
        # Current accumulation must not enter hourly/daily rainfall sums.
        out["precipitation_interval_seconds"] = row.get("precipitation_interval_seconds")
        return out
    try:
        start = _dt(row.get("precipitation_interval_start"))
        end = _dt(row.get("precipitation_interval_end"))
        if end != valid or end - start != timedelta(hours=1):
            raise ValueError
        out["precipitation_interval_start"], out["precipitation_interval_end"] = _iso(start), _iso(end)
    except (ValueError, TypeError):
        if out["precipitation_mm"] is not None:
            issues.add("unknown_or_invalid_precipitation_interval")
        out["precipitation_mm"] = None
        out["precipitation_interval_start"] = None
        out["precipitation_interval_end"] = None
    return out


def _gap(values):
    longest = run = 0
    for exists in values:
        run = 0 if exists else run + 1
        longest = max(run, longest)
    return longest


def _summarize(rows, start, end):
    by_time = {_dt(r["valid_time"]): r for r in rows}
    instant = [start + timedelta(hours=i) for i in range(336)]
    precip = [t + timedelta(hours=1) for t in instant]
    cover, missing, longest = {}, {}, {}
    for key in VARIABLES:
        slots = precip if key == "precipitation_mm" else instant
        flags = [by_time.get(t, {}).get(key) is not None for t in slots]
        cover[key] = round(sum(flags) / 336, 6)
        missing[key] = 336 - sum(flags)
        longest[key] = _gap(flags)
    daily = []
    for i in range(14):
        d = start + timedelta(days=i)
        trows = [by_time.get(d + timedelta(hours=h), {}) for h in range(24)]
        rains = [by_time.get(d + timedelta(hours=h + 1), {}).get("precipitation_mm") for h in range(24)]
        temps = [r.get("temperature_c") for r in trows]
        humidity = [r.get("relative_humidity_pct") for r in trows]
        day = {"date": d.date().isoformat(), "timezone": "Asia/Shanghai", "rainfall_hours_available": sum(x is not None for x in rains), "temperature_hours_available": sum(x is not None for x in temps)}
        day["precipitation_mm"] = round(sum(rains), 6) if all(x is not None for x in rains) else None
        day["precipitation_known_sum_mm"] = round(sum(x for x in rains if x is not None), 6) if any(x is not None for x in rains) else None
        for suffix, fn in (("min", min), ("max", max), ("mean", lambda xs: sum(xs) / len(xs))):
            day["temperature_" + suffix + "_c"] = round(fn(temps), 6) if all(x is not None for x in temps) else None
        day["relative_humidity_mean_pct"] = round(sum(humidity) / 24, 6) if all(x is not None for x in humidity) else None
        daily.append(day)
    features = {}
    for n in (1, 3, 7, 14):
        vals = [d["precipitation_mm"] for d in daily[-n:]]
        features[f"rainfall_{n}d_mm"] = round(sum(vals), 6) if all(v is not None for v in vals) else None
    dry = 0
    for d in reversed(daily):
        if d["precipitation_mm"] != 0:
            break
        dry += 1
    features["dry_days_14"] = dry
    features["dry_spell_at_least_14_days"] = (False if any(d["precipitation_known_sum_mm"] is not None and d["precipitation_known_sum_mm"] > 0 for d in daily) else True if dry == 14 else None)
    features["dry_spell_is_lower_bound"] = dry == 14 or any(d["precipitation_mm"] is None for d in daily)
    return daily, features, cover, missing, longest


def validate_snapshot(snapshot, as_of, points):
    """Normalize without network; recompute all derived fields, never fill gaps.

    Raises ValueError for identity/schema/raw-integrity failures. Data quality
    defects are retained as point quality issues and null values.
    """
    cutoff, start, end = _window(as_of)
    known = _points(points)
    if not isinstance(snapshot, dict) or not isinstance(snapshot.get("points"), dict):
        raise ValueError("weather snapshot requires a points object")
    if snapshot.get("schema_version", SCHEMA_VERSION) != SCHEMA_VERSION:
        raise ValueError("unsupported weather schema_version")
    unknown = set(snapshot["points"]) - set(known)
    if unknown:
        raise ValueError("weather contains points outside frozen profile: " + ", ".join(sorted(unknown)))
    out = copy.deepcopy(snapshot)
    out.update(schema_version=SCHEMA_VERSION, as_of=_iso(cutoff), timezone="Asia/Shanghai", historical_window={"start": _iso(start), "end_exclusive": _iso(end), "days": 14})
    out.setdefault("provider_status", {"official": "not_connected", "local_import": "provided"})
    out.setdefault("errors", [])
    for pid, point in known.items():
        p = out["points"].setdefault(pid, {"metadata": {}, "hourly": [], "current": None})
        if not isinstance(p, dict) or not isinstance(p.get("hourly", []), list):
            raise ValueError("weather point must contain an hourly list")
        meta = p.setdefault("metadata", {})
        if not isinstance(meta, dict):
            raise ValueError("weather metadata must be an object")
        for key, unit in meta.get("units", {}).items():
            if key in UNITS and unit != UNITS[key]:
                raise ValueError("normalized weather unit mismatch: " + key)
        for key in ("latitude", "longitude"):
            if key in meta and float(meta[key]) != point[key]:
                raise ValueError("point coordinates do not match frozen profile")
        meta.update({"point_id": pid, "latitude": point["latitude"], "longitude": point["longitude"], "point_source_ref": point["source_ref"], "units": dict(UNITS)})
        issues = set(p.get("quality", {}).get("issues", []))
        source_type = meta.get("source_type", "unknown")
        if source_type not in SOURCE_TYPES:
            raise ValueError("invalid weather source_type")
        if (meta.get("provider") == "open-meteo" or "open-meteo.com" in str(meta.get("source_ref", ""))) and source_type == "observation":
            raise ValueError("Open-Meteo model/reanalysis cannot be labeled observation")
        meta["source_type"] = source_type
        if source_type == "unknown":
            issues.add("unknown_source_type")
        for key in ("provider", "source_ref", "retrieved_at", "published_at", "spatial_resolution"):
            meta.setdefault(key, None)
        if not meta["source_ref"]:
            issues.add("missing_weather_source_ref")
        if meta.get("raw_response") is not None:
            raw = meta["raw_response"]
            if not isinstance(raw, str) or hashlib.sha256(raw.encode("utf-8")).hexdigest() != meta.get("raw_sha256"):
                raise ValueError("raw response SHA256 mismatch")
        if meta.get("retrieved_at"):
            try:
                if _dt(meta["retrieved_at"]) > cutoff:
                    issues.add("retrieved_after_as_of_not_prospective")
            except ValueError:
                issues.add("invalid_retrieved_at")
        if meta.get("published_at"):
            try:
                if _dt(meta["published_at"]) > cutoff:
                    issues.add("published_after_as_of_not_prospective")
            except ValueError:
                issues.add("invalid_published_at")
        else:
            issues.add("publication_time_unknown")
        by_time, conflicts = {}, set()
        for raw in p.get("hourly", []):
            if not isinstance(raw, dict):
                raise ValueError("hourly weather row must be an object")
            r = _row(raw, cutoff, issues)
            if r is None or _dt(r["valid_time"]) < start:
                continue
            t = r["valid_time"]
            if t in by_time:
                if by_time[t] != r:
                    issues.add("duplicate_time_conflict")
                    conflicts.add(t)
                else:
                    issues.add("duplicate_time_identical")
            else:
                by_time[t] = r
        for t in conflicts:
            # Reject the whole conflicted time, avoiding arbitrary selection.
            for key in VARIABLES:
                by_time[t][key] = None
        rows = [by_time[t] for t in sorted(by_time)]
        current = _row(p["current"], cutoff, issues, current=True) if p.get("current") else None
        if current and _dt(current["valid_time"]).date() != cutoff.date():
            issues.add("current_wrong_day_filtered")
            current = None
        age = (cutoff - _dt(current["valid_time"])).total_seconds() / 3600 if current else None
        stale = current is None or age > 2
        if stale:
            issues.add("current_missing_or_stale")
        daily, features, coverage, missing, gaps = _summarize(rows, start, end)
        complete = all(v == 0 for v in missing.values())
        if not complete:
            issues.add("incomplete_history")
        p.update(hourly=rows, current=current, daily=daily, features=features,
                 quality={"expected_hours": 336, "variable_coverage": coverage, "missing_hours": missing,
                          "longest_missing_run_hours": gaps, "complete_14_days": complete,
                          "current_stale": stale, "current_age_hours": age,
                          "current_variable_coverage": {k: bool(current and current.get(k) is not None) for k in VARIABLES},
                          "source_is_observation": source_type == "observation", "issues": sorted(issues)})
    if "weather_archive" in out:
        from .weather_archive import validate_archive
        out["weather_archive"] = validate_archive(out["weather_archive"], points, as_of)
    return out


def _api_rows(payload):
    hourly = payload.get("hourly", {})
    times = hourly.get("time", [])
    rows = []
    for i, t in enumerate(times):
        dt = _dt(t, naive_ok=True)
        r = {"valid_time": _iso(dt), "precipitation_interval_start": _iso(dt - timedelta(hours=1)), "precipitation_interval_end": _iso(dt)}
        for key, api_key in VARIABLES.items():
            values = hourly.get(api_key, [])
            r[key] = values[i] if i < len(values) else None
        rows.append(r)
    current = payload.get("current")
    if current and current.get("time"):
        current = {"valid_time": _iso(_dt(current["time"], naive_ok=True)), "precipitation_interval_seconds": current.get("interval"), **{key: current.get(api_key) for key, api_key in VARIABLES.items()}}
    else:
        current = None
    return rows, current


def _request(url, timeout, retries):
    last = None
    for _ in range(retries + 1):
        try:
            with urlopen(Request(url, headers={"User-Agent": "baoan-vector-control/1.0 weather-research"}), timeout=timeout) as response:
                raw = response.read(MAX_BYTES + 1)
            if len(raw) > MAX_BYTES:
                raise ValueError("weather response exceeds size limit")
            return raw.decode("utf-8")
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            last = exc
    raise RuntimeError("weather request failed: " + type(last).__name__) from last


def fetch_weather(points: list[dict], as_of: str, *, timeout=15, retries=1) -> dict:
    """Request only public profile coordinates from a fixed model fallback.

    Historical queries use archived forecasts. Neither provider is represented
    as observation, and retrospective retrieval is not a prospective backtest.
    """
    cutoff, start, _ = _window(as_of)
    known = _points(points)
    if not 0 < timeout <= 120 or not isinstance(retries, int) or not 0 <= retries <= 3:
        raise ValueError("timeout must be 0..120 seconds; retries 0..3")
    now = _now()
    snapshot = {"schema_version": SCHEMA_VERSION, "as_of": _iso(cutoff), "provider_status": {"official": "not_connected", "open_meteo": "pending"}, "points": {}, "errors": []}
    if cutoff > now + timedelta(minutes=5):
        snapshot["provider_status"]["open_meteo"] = "not_requested_future_as_of"
        snapshot["errors"].append({"code": "future_as_of", "message": "Refusing future history/current acquisition."})
        return validate_snapshot(snapshot, as_of, points)
    historical = cutoff.date() != now.date()
    endpoint = "https://historical-forecast-api.open-meteo.com/v1/forecast" if historical else "https://api.open-meteo.com/v1/forecast"
    for pid, point in known.items():
        params = {"latitude": point["latitude"], "longitude": point["longitude"], "hourly": ",".join(VARIABLES.values()), "start_date": start.date().isoformat(), "end_date": cutoff.date().isoformat(), "timezone": "Asia/Shanghai", "wind_speed_unit": "ms", "temperature_unit": "celsius", "precipitation_unit": "mm", "models": MODEL}
        if not historical:
            params["current"] = ",".join(VARIABLES.values())
        url = endpoint + "?" + urlencode(params)
        try:
            raw = _request(url, timeout, retries)
            payload = json.loads(raw)
            if not isinstance(payload, dict) or payload.get("error"):
                raise ValueError("provider returned error or unexpected schema")
            if payload.get("utc_offset_seconds") != 28800:
                raise ValueError("provider timezone does not match Asia/Shanghai")
            units = payload.get("hourly_units", {})
            for key, api_key in VARIABLES.items():
                if units.get(api_key) != UNITS[key]:
                    raise ValueError("provider missing/unexpected unit for " + api_key)
            rows, current = _api_rows(payload)
            snapshot["points"][pid] = {"metadata": {"provider": "open-meteo", "source_type": "model", "model": MODEL, "spatial_resolution": "0.25 degrees (~25 km); hourly interpolation of native 3/6-hour model data", "source_ref": endpoint, "request_url": url, "retrieved_at": _iso(_now()), "published_at": None, "raw_response": raw, "raw_sha256": hashlib.sha256(raw.encode("utf-8")).hexdigest(), "provider_grid_latitude": payload.get("latitude"), "provider_grid_longitude": payload.get("longitude"), "historical_forecast": historical, "attribution": "Weather data by Open-Meteo / ECMWF, CC BY 4.0; model estimate, not local observation"}, "hourly": rows, "current": None if historical else current}
        except (ValueError, TypeError, KeyError, RuntimeError) as exc:
            snapshot["errors"].append({"point_id": pid, "code": "fetch_failed", "message": str(exc)})
    snapshot["provider_status"]["open_meteo"] = "failed" if not snapshot["points"] else "partial" if snapshot["errors"] else "model_fallback_only"
    return validate_snapshot(snapshot, as_of, points)


def load_weather(path, points, as_of) -> dict:
    """Read normalized JSON or explicit-unit CSV; never acquire data online.

    CSV rows require point_id/valid_time and source_type/source_ref. Precipitation
    requires explicit start/end (or precipitation_semantics=preceding_hour).
    This imports declared provenance; it does not certify export authenticity.
    """
    path = Path(path)
    raw = path.read_bytes()
    if len(raw) > MAX_BYTES:
        raise ValueError("local weather exceeds size limit")
    text = raw.decode("utf-8-sig")
    if path.suffix.lower() == ".csv":
        snapshot = {"schema_version": SCHEMA_VERSION, "provider_status": {"official": "not_connected", "local_import": "provided_unverified_provenance"}, "points": {}, "errors": []}
        reader = csv.DictReader(io.StringIO(text))
        required = {"point_id", "valid_time", "source_type", "source_ref"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError("CSV missing required weather/provenance columns")
        for record in reader:
            pid = record["point_id"]
            meta = {key: record.get(key) or None for key in ("provider", "source_type", "source_ref", "station_id", "spatial_resolution", "retrieved_at", "published_at")}
            entry = snapshot["points"].setdefault(pid, {"metadata": meta, "hourly": [], "current": None})
            if entry["metadata"] != meta:
                raise ValueError("CSV point has conflicting provenance; import as separate points")
            row = {k: record.get(k) for k in ("valid_time", *VARIABLES, "precipitation_interval_start", "precipitation_interval_end")}
            if record.get("precipitation_semantics") == "preceding_hour":
                dt = _dt(record["valid_time"])
                row.update(precipitation_interval_start=_iso(dt - timedelta(hours=1)), precipitation_interval_end=_iso(dt))
            if record.get("record_kind") == "current":
                if entry["current"] is not None:
                    raise ValueError("CSV contains multiple current rows for one point")
                entry["current"] = row
            else:
                entry["hourly"].append(row)
    else:
        snapshot = json.loads(text)
    if "import_provenance" not in snapshot:
        snapshot["import_provenance"] = {"raw_response": text, "raw_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(), "kind": "local_file"}
    provenance = snapshot["import_provenance"]
    if hashlib.sha256(provenance["raw_response"].encode("utf-8")).hexdigest() != provenance["raw_sha256"]:
        raise ValueError("local import SHA256 mismatch")
    return validate_snapshot(snapshot, as_of, points)


def prepare_weather(points, assessment_at, anchors=(), cache_root=None, *, archive_manifest=None, timeout=15, retries=1):
    """Acquire audit-ready weather in preparation, never during frozen replay.

    The legacy ``points`` block contains recent IFS estimates. The separate
    ``weather_archive`` block holds 84 days of fixed ERA5 for each assessment
    or onset anchor, reused from a verified local archive before acquisition.
    Only public profile coordinates reach the provider; anchors are dates.
    """
    from .weather_archive import prepare_archive
    archive = prepare_archive(points, assessment_at, anchors, cache_root=cache_root,
                              archive_manifest=archive_manifest, timeout=timeout, retries=retries)
    snapshot = fetch_weather(points, assessment_at, timeout=timeout, retries=retries)
    snapshot["weather_archive"] = archive
    snapshot["provider_status"]["era5_archive"] = archive["provider_status"]
    snapshot["source_separation"] = "Recent IFS estimates and historical ERA5 reanalysis are separate; no cross-model gap filling."
    return snapshot
