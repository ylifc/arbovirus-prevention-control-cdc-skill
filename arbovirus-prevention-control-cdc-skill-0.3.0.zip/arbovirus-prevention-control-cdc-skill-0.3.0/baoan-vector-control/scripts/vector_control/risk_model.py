"""Versioned scientific scoring gate, separate from operational priority.

There are no fitted, calibrated parameters in the supplied case-only data.
Never derive probabilities from arbitrary weights or silently treat missing as 0.
"""
from __future__ import annotations

import math
from .episodes import summarize_episode

MODEL_VERSION = 'joint-risk-contract-0.3.0-unfitted'


def score_from_probability(probability):
    if isinstance(probability, bool) or not isinstance(probability, (float, int)) or not math.isfinite(probability) or not 0 <= probability <= 1:
        raise ValueError('calibrated probability must be finite and between 0 and 1')
    return min(10, 1 + math.floor(10 * probability))


def assess_risk_models(data, assessment, history_comparison, weather, rules):
    comparisons = {(r['site_id'], r['disease']): r for r in history_comparison.get('site_comparisons', [])}
    rows = []
    for row in assessment['site_assessments']:
        episode = summarize_episode(data, row, rules)
        comparison = comparisons.get((row['site_id'], row['disease']), {})
        reasons = ['尚无经核验引入事件队列及完整阴性随访，不能拟合续发概率。',
                   '病种与来源分支模型尚未完成时间/空间外部验证和概率校准。']
        if episode['branch'] == 'unknown_or_conflict':
            reasons.append('宝安来源或实际在位证据不足，分别呈现输入后续发与本地扩展情景。')
        if not comparison:
            reasons.append('该场所病种没有可用历史对照。')
        elif not comparison.get('climate', {}).get('complete'):
            reasons.append('同口径历史气候对照缺失或不完整。')
        rows.append({'site_id': row['site_id'], 'site_name': row['site_name'], 'disease': row['disease'],
                     'assessment_at': data['assessment_at'], 'horizon_days': 28,
                     'risk_target': '已知本地活动后的后续扩展' if episode['branch'] == 'local' else '输入在位后的新增本地病例' if episode['branch'] == 'imported' else '输入后续发／本地扩展两种待核情景',
                     'branch': episode['branch'], 'source_scenarios': episode['source_scenarios'],
                     'probability': None, 'uncertainty_interval': None, 'score_1_to_10': None,
                     'score_status': 'not_fitted_not_calibrated', 'model_version': MODEL_VERSION,
                     'score_mapping': 'min(10,1+floor(10*p_calibrated))', 'blocking_reasons': reasons,
                     'action_priority': row['priority'], 'evidence_rule_risk': row['risk_level'],
                     'historical_features': {k: v for k, v in comparison.items() if k.endswith('_history') or k in {'climate', 'place_match', 'cutoff_exclusive'}},
                     'episode_evidence': episode,
                     'prediction_time_policy': '本次仅更新证据与处置。未建立已验证首次/动态概率模型，不能把再次报告当独立训练事件。'})
    return {'model_status': 'not_fitted_not_calibrated', 'model_version': MODEL_VERSION,
            'cross_disease_pooling': False, 'rows': rows}
