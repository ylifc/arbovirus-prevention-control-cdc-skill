"""Capture new inputs once; production only replays validated frozen inputs."""
from __future__ import annotations

import os
import platform
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from .common import ValidationError, read_json, write_json, file_hash, digest
from .validation import validate_input
from .engine import assess
from .report import write_outputs

ROOT = Path(__file__).resolve().parents[2]


def code_files():
    return sorted((ROOT / "scripts").rglob("*.py"))


def _destination(path):
    path = Path(path).expanduser().absolute()
    if path.exists():
        raise ValidationError(f"输出已存在，为保护已有结果请使用新目录: {path}")
    if not path.parent.is_dir():
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _private_stage(destination):
    return Path(tempfile.mkdtemp(prefix=".vector-", dir=destination.parent))


def prepare(input_path, output_path, weather_source="auto", phase="PRETEST_REPAIR", history_source="auto", previous_paths=None, weather_cache=None):
    if phase not in {"BOOTSTRAP", "PRETEST_REPAIR"}:
        raise ValidationError("只能在BOOTSTRAP或PRETEST_REPAIR捕获新输入，生产阶段不可联网或修改资源")
    input_path = Path(input_path).expanduser().resolve()
    if not input_path.is_file(): raise ValidationError(f"本地输入不存在: {input_path}")
    input_hash = file_hash(input_path)
    data = read_json(input_path)  # Resolve local input before any remote request.
    if file_hash(input_path) != input_hash: raise ValidationError("读取时本地输入发生漂移")
    initial_resources = {name: file_hash(ROOT / name) for name in ("profiles/baoan.json", "rules/cn-vector-2026.json", "rules/risk-model-contract.json", "profiles/weather-resource.json")}
    initial_code = {str(p.relative_to(ROOT)): file_hash(p) for p in code_files()}
    profile = read_json(ROOT / "profiles/baoan.json")
    rules = read_json(ROOT / "rules/cn-vector-2026.json")
    data, warnings = validate_input(data, profile, rules)
    from .history import load_registered_history, collect_previous
    history, history_record = load_registered_history(ROOT, history_source)
    previous, previous_records = collect_previous(ROOT, data, previous_paths)
    sources = []
    for source in data["source_documents"]:
        if not isinstance(source, dict) or not source.get("path"):
            raise ValidationError("source_documents须为含本地path的对象")
        path = Path(source["path"]).expanduser()
        if not path.is_absolute(): path = input_path.parent / path
        path = path.resolve()
        if not path.is_file(): raise ValidationError(f"原始材料本地文件不存在: {path}")
        if path.stat().st_size > 20 * 1024 * 1024: raise ValidationError("单份原始材料超过20MiB限制")
        checksum = file_hash(path)
        if source.get("sha256") and checksum != source["sha256"]:
            raise ValidationError(f"原始材料指纹发生漂移: {path}")
        sources.append((path, checksum))
    target = _destination(output_path)
    stage = _private_stage(target)
    try:
        (stage / "inputs").mkdir()
        shutil.copyfile(input_path, stage / "inputs/input-source.json")
        if file_hash(stage / "inputs/input-source.json") != input_hash or file_hash(input_path) != input_hash:
            raise ValidationError("冻结前结构化本地输入发生漂移")
        write_json(stage / "inputs/normalized.json", data)
        write_json(stage / "inputs/profile.json", profile)
        write_json(stage / "inputs/rules.json", rules)
        write_json(stage / 'inputs/risk-model-contract.json', read_json(ROOT / 'rules/risk-model-contract.json'))
        if history is not None:
            write_json(stage / "inputs/history.json", history)
        write_json(stage / "inputs/previous-assessments.json", previous)
        source_records = [{"source_type": "local_normalized_input", "original_path": str(input_path), "sha256": input_hash, "snapshot": "inputs/input-source.json", "snapshot_sha256": file_hash(stage / "inputs/input-source.json"), "normalized_snapshot": "inputs/normalized.json"}]
        for index, (path, checksum) in enumerate(sources):
            name = f"inputs/source-{index:03d}{path.suffix.lower()}"
            shutil.copyfile(path, stage / name)
            if file_hash(stage / name) != checksum or file_hash(path) != checksum:
                raise ValidationError(f"冻结前原始资料发生漂移: {path}")
            source_records.append({"source_type": "local_source_document", "original_path": str(path), "sha256": checksum, "snapshot": name, "snapshot_sha256": file_hash(stage / name)})
        if history_record:
            source_records.append({**history_record, "source_type": "historical_registry", "snapshot": "inputs/history.json"})
        source_records.extend(previous_records)
        # All local inputs are captured before any network access. Connectors
        # receive only registered public weather points, never case/site data.
        from .weather import prepare_weather, load_weather, validate_snapshot
        points = profile["weather_points"]
        if weather_source == "auto":
            weather_config = read_json(ROOT / 'profiles/weather-resource.json')
            anchors = {c.get('onset_date') or (c.get('infectious_window') or {}).get('start', '')[:10] for c in data['cases']} - {None, ''}
            snapshot = prepare_weather(points, data['assessment_at'], sorted(anchors),
                                       cache_root=weather_cache or weather_config.get('cache_root'),
                                       archive_manifest=weather_config.get('archive_manifest'))
        elif weather_source == "none":
            snapshot = {"schema_version": "1.0", "as_of": data["assessment_at"], "provider_status": "not_requested", "points": {}, "errors": [{"reason": "明确离线运行；天气未知，不作低风险证据"}]}
        else:
            snapshot = load_weather(str(Path(weather_source).expanduser().resolve()), points, data["assessment_at"])
        if weather_source != "none": snapshot = validate_snapshot(snapshot, data["assessment_at"], points)
        for anchor, anchor_snapshot in snapshot.get('comparison_windows', {}).items():
            if anchor > data['assessment_at'][:10]:
                raise ValidationError('历史比较天气锚点晚于判定日期')
            snapshot['comparison_windows'][anchor] = validate_snapshot(anchor_snapshot, anchor + 'T00:00:00+08:00', points)
        write_json(stage / "inputs/weather.json", snapshot)
        if initial_code != {str(p.relative_to(ROOT)): file_hash(p) for p in code_files()} or any(file_hash(ROOT / n) != checksum for n, checksum in initial_resources.items()):
            raise ValidationError("准备期间代码或配置发生漂移，停止冻结")
        manifest = {"schema_version": "1.0", "input_source": "local", "assessment_at": data["assessment_at"], "source_records": source_records, "normalization_review": "需要使用者核验抽取事实；结构验证不等于临床证据核验", "warnings": warnings}
        write_json(stage / "input_manifest.json", manifest)
        frozen_files = sorted(p for p in stage.rglob("*") if p.is_file())
        lock = {"schema_version": "1.0", "lifecycle": "FROZEN", "engine_version": "0.3.0", "created_at": datetime.now(timezone.utc).isoformat(), "assessment_at": data["assessment_at"],
                "python": {"logical_tool": "python", "software_family": "Python", "package_name": "cpython", "executable_name": Path(sys.executable).name, "executable": str(Path(sys.executable).resolve()), "version": platform.python_version(), "environment_prefix": sys.prefix, "skill_id": "baoan-vector-control"},
                "files": {str(p.relative_to(stage)): file_hash(p) for p in frozen_files},
                "engine_files": initial_code,
                "resource_files": initial_resources,
                "network_during_replay": False, "scientific_model_status": "not_calibrated"}
        write_json(stage / "lock.json", lock)
        (stage / "lock.sha256").write_text(file_hash(stage / "lock.json") + "\n", encoding="ascii")
        registry = {"resources": [{"resource_type": "frozen_input_bundle", "status": "READY", "path": str(target), "lock_fingerprint": file_hash(stage / "lock.json"), "validation": "schema、时间、引用、输入指纹；不代表流调事实已审核"}, {"resource_type": "rule_config", "status": "READY", "id": rules["rule_set_id"], "version": rules["version"], "source_url": rules["source_url"], "runtime_entry": "inputs/rules.json", "fingerprint": file_hash(stage / "inputs/rules.json")}], "python": lock["python"]}
        write_json(stage / "registry.json", registry)
        (stage / "knowledge.jsonl").write_text(__import__("json").dumps({"event": "input_snapshot_validated", "phase": phase, "weather_status": snapshot.get("provider_status"), "warnings": warnings, "installations": []}, ensure_ascii=False) + "\n", encoding="utf-8")
        stage.rename(target)
    except BaseException:
        shutil.rmtree(stage)
        raise
    return {"bundle": str(target), "lock": str(target / "lock.json"), "weather_status": snapshot.get("provider_status"), "warnings": warnings}


def _safe_member(root, name):
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        raise ValidationError(f"锁内路径无效: {name}")
    return path


def replay(lock_path, output_path):
    lock_path = Path(lock_path).expanduser().resolve()
    if not lock_path.is_file(): raise ValidationError("冻结锁不存在")
    checksum = lock_path.with_name("lock.sha256")
    if not checksum.is_file() or checksum.read_text(encoding="ascii").strip() != file_hash(lock_path):
        raise ValidationError("冻结锁指纹校验失败")
    lock = read_json(lock_path)
    if lock.get("schema_version") != "1.0" or lock.get("lifecycle") != "FROZEN" or lock.get("network_during_replay") is not False:
        raise ValidationError("不是受支持的冻结生产锁")
    if lock.get("python", {}).get("version") != platform.python_version() or lock["python"].get("executable") != str(Path(sys.executable).resolve()):
        raise ValidationError("Python执行器或版本漂移；请在维护阶段重新验证冻结")
    root = lock_path.parent
    for name, expected in lock["files"].items():
        if file_hash(_safe_member(root, name)) != expected: raise ValidationError(f"冻结输入漂移: {name}")
    actual_code = {str(p.relative_to(ROOT)): file_hash(p) for p in code_files()}
    if actual_code != lock["engine_files"]: raise ValidationError("引擎代码漂移；禁止在生产期间修复或重规划")
    for name, expected in lock["resource_files"].items():
        if file_hash(_safe_member(ROOT, name)) != expected: raise ValidationError(f"持久资源漂移: {name}")
    data, profile, rules, weather = (read_json(root / f"inputs/{name}.json") for name in ("normalized", "profile", "rules", "weather"))
    data, warnings = validate_input(data, profile, rules)
    result = assess(data, profile, rules, weather, warnings)
    from .history import compare_history, compare_previous
    history = read_json(root / "inputs/history.json") if "inputs/history.json" in lock["files"] else None
    previous = read_json(root / "inputs/previous-assessments.json") if "inputs/previous-assessments.json" in lock["files"] else []
    result["historical_comparison"] = compare_history(data, weather, history)
    from .risk_model import assess_risk_models
    result['risk_model_assessment'] = assess_risk_models(data, result, result['historical_comparison'], weather, rules)
    result["engine_version"] = "0.3.0"
    result["previous_result_comparison"] = compare_previous(result, previous)
    result["run_fingerprint"] = digest({"engine_result": result, "history": history, "previous": previous})
    for row in result["risk_register"]:
        row["version"] = result["run_fingerprint"][:16]
    target = _destination(output_path)
    stage = _private_stage(target)
    try:
        write_outputs(stage, result, data, weather)
        write_json(stage / "provenance.json", {"lock_sha256": file_hash(lock_path), "input_manifest_sha256": lock["files"]["input_manifest.json"], "assessment_at": data["assessment_at"], "run_fingerprint": result["run_fingerprint"], "network_used": False, "official_response_issued": False})
        stage.rename(target)
    except BaseException:
        shutil.rmtree(stage)
        raise
    return {"output": str(target), "report": str(target / "report.html"), "site_assessments": len(result["site_assessments"]), "register_rows": len(result["risk_register"]), "run_fingerprint": result["run_fingerprint"]}


def analyze(input_path, output_path, weather_source='auto', history_source='auto', previous_paths=None, weather_cache=None):
    """Convenience entry: maintenance capture then strictly offline replay."""
    target = _destination(output_path)
    # prepare validates all local inputs before acquiring remote weather.
    prepared = prepare(input_path, target / 'bundle', weather_source,
                       history_source=history_source, previous_paths=previous_paths,
                       weather_cache=weather_cache)
    result = replay(prepared['lock'], target / 'result')
    return {**result, 'lock': prepared['lock'], 'weather_status': prepared['weather_status']}
