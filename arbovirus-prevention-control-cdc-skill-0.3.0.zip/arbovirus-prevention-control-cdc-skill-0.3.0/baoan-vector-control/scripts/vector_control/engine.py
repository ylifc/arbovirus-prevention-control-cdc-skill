"""Advisory rules. Outputs describe evidence, never an official declaration."""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, time
from .common import TZ, day, instant, digest

RANK = {"待评估": -1, "低": 0, "关注": 1, "高": 2, "很高": 3}


def _current_case(case, as_of, spec):
    # An old report is context, not proof of current transmission. Prior open
    # assessments are retained separately and never implicitly closed.
    anchor = case.get("report_date") or case.get("onset_date")
    return anchor is None or 0 <= (as_of.date() - day(anchor)).days < spec["cluster_no_new_days"]


def _eligible(case, site, as_of, spec):
    if case.get('diagnostic_conflict') or case.get('origin_conflict'):
        return False
    # Only an explicit, time-valid Baoan classification enters local counting.
    from .episodes import reviewed_origin
    origin_eligible = reviewed_origin(case, as_of.isoformat()) == 'local'
    if case.get("status") != "confirmed" or not case.get("confirmation_ref") or not origin_eligible:
        return False
    if not case.get("report_date") or not 0 <= (as_of.date() - day(case["report_date"])).days < spec["cluster_days"]:
        return False
    if site.get("location_status") != "verified":
        return False
    return any(link["site_id"] == site["site_id"] and link.get("aggregation_eligible") is True and link.get("evidence_ref") for link in case.get("site_links", []))


def activity_window(case, spec):
    if case.get("infectious_window"):
        window = case["infectious_window"]
        return {"start": instant(window["start"]).isoformat(), "end": instant(window["end"]).isoformat(), "status": window["status"], "basis": window["evidence_ref"]}
    if not case.get("onset_date"):
        return {"start": None, "end": None, "status": "unknown", "basis": "缺发病日期或经审核个体时间窗"}
    onset = day(case["onset_date"])
    start = datetime.combine(onset + timedelta(days=spec["typical_activity_start_offset_days"]), time.min, TZ)
    end = datetime.combine(onset + timedelta(days=spec["typical_activity_end_offset_days"] + 1), time.min, TZ)
    return {"start": start.isoformat(), "end": end.isoformat(), "status": "candidate", "basis": "2026国家方案第3页典型感染性时段线索，右端不含；不排除其他时段，不用于解除"}


def _relation(activity, window):
    if not activity.get("start") or not activity.get("end") or not window["start"]:
        return "unknown"
    if instant(activity["start"]) < instant(window["end"]) and instant(activity["end"]) > instant(window["start"]):
        return "overlap_reviewed" if window["status"] == "reviewed" else "overlap_candidate"
    return "outside_window_requires_review"


def _valid_vector(obs):
    if not obs.get("evidence_ref") or obs.get("value") is None or not obs.get("method") or not obs.get("unit"):
        return False
    expected = {"BI": "positive_containers_per_100_households", "MOI": "%", "double_net_adults": "只/(顶·小时)"}
    return obs.get("unit") == expected.get(obs.get("metric"))


def _credible_vector(obs):
    return _valid_vector(obs) and obs["value"] > 0


def _tasks(priority, household=False, occupation=False):
    tasks = [
        {"action": "核对病例状态、标准场所和实际停留时间，保留未决项", "owner_role": "疾控或公卫调查人员", "deadline": "立即转交专业复核" if priority == "P0" else "当日优先安排" if priority == "P1" else "由本地业务流程指定", "deadline_basis": "系统工作目标，非法定时限"},
        {"action": "查验积水容器、防蚊设施与媒介状况，采取适宜防叮咬措施", "owner_role": "社区、物业及专业病媒防制人员", "deadline": "按本地计划", "deadline_basis": "待业务确认"},
        {"action": "记录措施和同口径复查结果；仅由专业复核决定关闭", "owner_role": "处置责任单位和审核人员", "deadline": "实施后按适用规范复核", "deadline_basis": "规范及本地安排"},
    ]
    if household:
        tasks.append({"action": "核对同住者共同蚊暴露、症状和照护需求；有不适及时就医，同住不等于感染", "owner_role": "公卫随访人员", "deadline": "依需要安排", "deadline_basis": "个别化防护"})
    if occupation:
        tasks.append({"action": "核查实际岗位、班次、室内外停留和防蚊条件，不按职业标签定级", "owner_role": "单位联系人和调查人员", "deadline": "随现场调查", "deadline_basis": "系统调查建议"})
    return tasks


def assess(data, profile, rules, weather, input_warnings=()):
    as_of = instant(data["assessment_at"])
    sites = {s["site_id"]: s for s in data["sites"]}
    cases = {c["case_id"]: c for c in data["cases"]}
    households = {h["household_id"]: h for h in data["households"]}
    associations = defaultdict(set)
    for case in cases.values():
        for link in case.get("site_links", []):
            associations[link["site_id"]].add(case["case_id"])
    for event in data["activities"]:
        associations[event["site_id"]].add(event["case_id"])
    eligible = {}
    street_counts = defaultdict(set)
    for sid, site in sites.items():
        for disease, spec in rules["diseases"].items():
            members = {cid for cid in associations[sid] if cases[cid]["disease"] == disease and _eligible(cases[cid], site, as_of, spec)}
            eligible[(sid, disease)] = members
            if site.get("street"):
                street_counts[(site["street"], disease)].update(members)
    results, register = [], []
    run_key = digest({"input": data, "rules": rules, "profile": profile, "weather": weather})
    for sid, site in sorted(sites.items()):
        current_obs = []
        stale_obs = []
        for obs in data["observations"]:
            if obs["site_id"] != sid:
                continue
            limit = profile["quality"][f'{obs["kind"]}_max_age_days']
            (current_obs if (as_of - instant(obs["observed_at"])).total_seconds() <= limit * 86400 else stale_obs).append(obs)
        vector_signal = any(o["kind"] == "vector" and _credible_vector(o) for o in current_obs)
        environment_signal = any(o["kind"] == "environment" and o.get("standing_water") == "yes" and o.get("evidence_ref") for o in current_obs)
        weather_point = site.get("weather_point_id")
        w = weather.get("points", {}).get(weather_point, {})
        for disease, spec in sorted(rules["diseases"].items()):
            linked = sorted(cid for cid in associations[sid] if cases[cid]["disease"] == disease)
            active = [cid for cid in linked if _current_case(cases[cid], as_of, spec) and cases[cid]["status"] in {"confirmed", "suspected", "unknown"}]
            relevant_events = [e for e in data["activities"] if e["site_id"] == sid and cases[e["case_id"]]["disease"] == disease]
            missing, reasons, hits = [], [], []
            level, priority, category = "待评估", "P2", "not_determined"
            local_count = len(eligible[(sid, disease)])
            street_count = len(street_counts[(site.get("street"), disease)]) if site.get("street") else 0
            if site.get("location_status") != "verified":
                missing.append("地址尚未核验，不能划定精确区域或规范聚集场所")
            if not any(o["kind"] == "vector" and o.get("value") is not None and o.get("evidence_ref") for o in current_obs):
                missing.append("缺当前有证据引用的媒介监测，不能由天气推造蚊密度")
            if not w:
                missing.append("地点没有可用天气点数据")
            elif not w.get("quality", {}).get("complete_14_days"):
                missing.append("14日气象不完整，详见气象质量报告")
            if w and w.get("metadata", {}).get("source_type") not in {"observation", "interpolated_observation"}:
                missing.append("天气为模型或其他背景资料，非小区实测")
            if stale_obs:
                missing.append("部分现场资料超过工程时效提醒，需要复查")
            if vector_signal or environment_signal:
                level, priority = "关注", "P2"
                hits.append("SYS-ENV")
                reasons.append("当前现场证据提示积水或媒介存在；并未据此证明带毒或实际传播")
            if active:
                priority = "P1"
                hits.append("SYS-CASE")
                reasons.append("近期病例关联场所须优先核查，无论天气是否完整")
                recent_activity = lambda e: bool(e.get("end") and (as_of - instant(e["end"])).total_seconds() <= spec["cluster_no_new_days"] * 86400)
                credible_exposure = any(e["case_id"] in active and recent_activity(e) and e.get("event_type") != "source_investigation" and e.get("mosquito_exposure") == "yes" and e.get("evidence_ref") and _relation(e, activity_window(cases[e["case_id"]], spec)) in {"overlap_candidate", "overlap_reviewed"} for e in relevant_events)
                recent_onset_or_unknown = any(not cases[c].get("onset_date") or (as_of.date() - day(cases[c]["onset_date"])).days < spec["cluster_no_new_days"] for c in active)
                if (recent_onset_or_unknown and (vector_signal or environment_signal)) or credible_exposure:
                    level = "高"
                    reasons.append("病例关联同时有现场或活动暴露支持，建议高风险专业复核")
                else:
                    level = "待评估"
                    missing.append("病例关联已知，但当前暴露支持不足；待评估不代表停止处置")
                if local_count:
                    category = "local_cases_below_cluster_threshold"
                elif all(cases[c].get("origin") == "imported" for c in active):
                    category = "imported_case_association"
            if local_count >= spec["cluster_count"]:
                category, level, priority = "local_cluster_candidate", "很高", "P0"
                hits.append(f'CN2026-{disease}-CLUSTER')
                reasons.append(f'去重后同场所在{spec["cluster_days"]}个报告日期自然日内有{local_count}例有依据的本地确诊，满足规范计数候选条件')
            if street_count >= spec["outbreak_count"]:
                category, level, priority = "street_outbreak_candidate", "很高", "P0"
                hits.append(f'CN2026-{disease}-OUTBREAK')
                reasons.append(f'所在街道去重计数{street_count}满足局部暴发候选；不表示本场所已证实传播')
            if not active and not vector_signal and not environment_signal and category != "street_outbreak_candidate":
                surveillance = site.get("surveillance", {})
                qualified = surveillance.get("adequate") is True and surveillance.get("reviewer_ref") and surveillance.get("assessed_at") and 0 <= (as_of - instant(surveillance["assessed_at"])).total_seconds() <= 7 * 86400
                if qualified and not linked and any(o["kind"] == "vector" and _valid_vector(o) and o.get("value") == 0 for o in current_obs):
                    level, priority = "低", "P3"
                    reasons.append("业务审核确认监测覆盖合格，当前未发现病例关联或媒介异常；仅限本次覆盖范围")
                else:
                    hits.append("SYS-UNKNOWN")
                    missing.append("缺足以判断低风险的当前调查覆盖；历史记录不等于当前活跃")
            previous = [r for r in data["prior_risks"] if r["site_id"] == sid and r["disease"] == disease and r["status"] != "closed"]
            for prior in previous:
                if RANK[prior["risk_level"]] > RANK[level]:
                    level = prior["risk_level"]
                priority = min(priority, prior["priority"])
                hits.append("SYS-PRIOR")
                reasons.append(f'继承未关闭风险{prior["risk_id"]}，未获得允许降级的专业复核依据')
            family_ids = sorted({cases[c]["household_id"] for c in linked if cases[c].get("household_id")})
            care = sorted({str(v) for fid in family_ids for v in households[fid].get("care_needs", [])})
            has_occupation = any(cases[c].get("occupation") for c in linked)
            row = {
                "risk_id": f"{sid}-{disease}", "version": run_key[:16], "site_id": sid,
                "site_name": site["name"], "street": site.get("street"), "community": site.get("community"), "disease": disease,
                "assessment_at": as_of.isoformat(), "event_type": "site_assessment",
                "risk_level": level, "priority": priority, "official_event_candidate": category,
                "official_response_level": None, "official_status": "requires_professional_review",
                "confidence": "limited" if missing else "supported_for_review",
                "case_ids": linked, "current_case_ids": active, "eligible_local_case_ids": sorted(eligible[(sid, disease)]),
                "site_local_count": local_count, "street_local_count": street_count,
                "rule_ids": sorted(set(hits)), "rule_set_version": rules["version"],
                "reasons": reasons, "missing": sorted(set(missing)),
                "weather_point_id": weather_point, "weather_quality": w.get("quality", {}),
                "weather_features": w.get("features", {}), "weather_spatial_limit": profile["weather_spatial_limit"],
                "observations": current_obs, "older_observation_ids": [o["observation_id"] for o in stale_obs],
                "household_ids": family_ids, "care_needs": care,
                "occupational_facts": [{"case_id": cid, "occupation": cases[cid].get("occupation"), "work_pattern": cases[cid].get("work_pattern")} for cid in linked],
                "tasks": _tasks(priority, bool(family_ids), has_occupation),
                "interventions": [a for a in data["interventions"] if a["site_id"] == sid],
                "status": "under_review", "reviewer": None, "review_due_at": None,
                "closure": "不自动关闭；病例、媒介和适用规范条件须专业复核",
            }
            results.append(row)
            register.append(row)
            for event in sorted(relevant_events, key=lambda e: e["event_id"]):
                case = cases[event["case_id"]]
                window = activity_window(case, spec)
                relation = _relation(event, window)
                hourly = []
                if event.get("start") and event.get("end"):
                    hourly = [h for h in w.get("hourly", []) if instant(event["start"]) <= instant(h["valid_time"]) <= instant(event["end"])]
                record = {
                    "risk_id": f'{sid}-{disease}-{event["event_id"]}', "version": run_key[:16],
                    "site_id": sid, "site_name": site["name"], "street": site.get("street"),
                    "disease": disease, "event_type": event["event_type"],
                    "start": event.get("start"), "end": event.get("end"), "assessment_at": as_of.isoformat(),
                    "case_ids": [event["case_id"]], "risk_level": "待评估", "priority": "P1" if event["case_id"] in active else "P2",
                    "official_event_candidate": "not_applicable_to_individual_activity", "official_response_level": None,
                    "site_risk_level": level, "site_priority": priority, "window_relation": relation,
                    "activity_window": window, "confidence": "limited", "status": "under_review",
                    "activity_facts": event, "weather_at_activity": hourly,
                    "rule_ids": ["SYS-ACTIVITY-REVIEW"], "reasons": ["本条为具体时段核查线索，场所整体等级另列；不是已证实传播链"],
                    "missing": [] if hourly else ["缺本活动时段气象；当前14日数据可能不覆盖历史个案"],
                    "tasks": _tasks("P1" if event["case_id"] in active else "P2"),
                }
                if event["event_type"] != "source_investigation" and event.get("mosquito_exposure") == "yes" and event.get("evidence_ref") and relation in {"overlap_candidate", "overlap_reviewed"}:
                    record["risk_level"] = "高"
                    record["reasons"].append("活动时段与感染性线索窗口重合且报告蚊暴露，建议优先核查；未证明传播")
                register.append(record)
    return {"schema_version": "1.0", "engine_version": "0.3.0", "run_fingerprint": run_key,
            "assessment_at": as_of.isoformat(), "profile_id": profile["profile_id"],
            "advisory_only": True, "scientific_model_status": profile["scientific_model_status"],
            "input_warnings": list(input_warnings), "weather_provider_status": weather.get("provider_status"),
            "weather_errors": weather.get("errors", []), "site_assessments": results, "risk_register": register}
