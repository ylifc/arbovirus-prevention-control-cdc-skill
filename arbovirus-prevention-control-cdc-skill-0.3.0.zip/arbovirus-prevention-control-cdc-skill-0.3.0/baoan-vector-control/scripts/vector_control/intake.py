"""Read local source material as evidence, without interpreting or executing it.

Only the Python standard library is used.  No network requests, subprocesses,
spreadsheet calculations, address inference, or epidemiological inference occur.
"""

from __future__ import annotations

import csv
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import posixpath
import re
import stat
from typing import Any
from xml.etree import ElementTree as ET
from zipfile import BadZipFile, ZipFile


MAX_FILE_BYTES = 20 * 1024 * 1024
MAX_ZIP_MEMBERS = 2048
MAX_MEMBER_BYTES = 20 * 1024 * 1024
MAX_UNCOMPRESSED_BYTES = 100 * 1024 * 1024
MAX_COMPRESSION_RATIO = 300
MAX_CONTENT_ITEMS = 100_000
MAX_SHEET_ROWS = 20_000
MAX_SHEET_CELLS = 100_000
MAX_MERGE_RANGES = 2048
MAX_MERGE_ROW_CHECKS = 2_000_000

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PKG = "{http://schemas.openxmlformats.org/package/2006/relationships}"


class IntakeError(ValueError):
    """A local-input failure; ``code`` is suitable for a CLI or audit record."""

    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def _decode(raw: bytes, warnings: list[str]) -> tuple[str, str]:
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        try:
            return raw.decode("utf-16"), "utf-16"
        except UnicodeError as exc:
            raise IntakeError("invalid_encoding", "Invalid BOM-marked UTF-16 input") from exc
    try:
        return raw.decode("utf-8-sig"), "utf-8-sig" if raw.startswith(b"\xef\xbb\xbf") else "utf-8"
    except UnicodeDecodeError:
        try:
            decoded = raw.decode("gb18030")
        except UnicodeDecodeError as exc:
            raise IntakeError("invalid_encoding", "Input is not UTF-8, BOM-marked UTF-16, or GB18030") from exc
        warnings.append("UTF-8 decoding failed; decoded as GB18030. Verify the text against the original source.")
        return decoded, "gb18030"


def _xml(raw: bytes, part: str) -> ET.Element:
    # Also catches UTF-16/UTF-32 ASCII declarations, before XML parsing.
    declaration_scan = raw.replace(b"\x00", b"").upper()
    if b"<!DOCTYPE" in declaration_scan or b"<!ENTITY" in declaration_scan:
        raise IntakeError("unsafe_xml", f"DTD and entity declarations are not allowed: {part}")
    try:
        return ET.fromstring(raw)
    except (ET.ParseError, ValueError, RecursionError) as exc:
        raise IntakeError("invalid_xml", f"Invalid XML part: {part}") from exc


def _open_package(raw: bytes) -> ZipFile:
    try:
        package = ZipFile(io.BytesIO(raw))
        infos = package.infolist()
        if len(infos) > MAX_ZIP_MEMBERS:
            raise IntakeError("archive_limit", "Archive contains too many members")
        total = 0
        seen: set[str] = set()
        for info in infos:
            name = info.filename
            if name in seen:
                raise IntakeError("unsafe_archive", f"Duplicate archive member: {name}")
            seen.add(name)
            path = PurePosixPath(name)
            if path.is_absolute() or ".." in path.parts or "\\" in name or "\x00" in name:
                raise IntakeError("unsafe_archive", "Unsafe archive member path")
            if info.flag_bits & 1:
                raise IntakeError("unsafe_archive", "Encrypted document archives are not supported")
            if stat.S_ISLNK(info.external_attr >> 16):
                raise IntakeError("unsafe_archive", "Archive symbolic links are not supported")
            if info.file_size > MAX_MEMBER_BYTES:
                raise IntakeError("archive_limit", f"Archive member exceeds decompressed size limit: {name}")
            total += info.file_size
            if total > MAX_UNCOMPRESSED_BYTES:
                raise IntakeError("archive_limit", "Archive exceeds total decompressed size limit")
            if info.file_size > 1024 * 1024 and info.file_size / max(1, info.compress_size) > MAX_COMPRESSION_RATIO:
                raise IntakeError("archive_limit", f"Suspicious archive compression ratio: {name}")
        return package
    except IntakeError:
        if "package" in locals():
            package.close()
        raise
    except (BadZipFile, OSError, ValueError) as exc:
        raise IntakeError("invalid_archive", "Invalid Office document ZIP archive") from exc


def _part(package: ZipFile, name: str) -> ET.Element:
    try:
        with package.open(name) as member:
            raw = member.read(MAX_MEMBER_BYTES + 1)
        if len(raw) > MAX_MEMBER_BYTES:
            raise IntakeError("archive_limit", f"Decompressed member exceeds size limit: {name}")
    except KeyError as exc:
        raise IntakeError("missing_document_part", f"Missing document part: {name}") from exc
    return _xml(raw, name)


def _docx_text(paragraph: ET.Element) -> str:
    parts = []
    for node in paragraph.iter():
        if node.tag == W + "t":
            parts.append(node.text or "")
        elif node.tag == W + "tab":
            parts.append("\t")
        elif node.tag in (W + "br", W + "cr"):
            parts.append("\n")
    return "".join(parts)


def _docx(package: ZipFile, warnings: list[str]) -> list[dict[str, Any]]:
    body = _part(package, "word/document.xml").find(W + "body")
    if body is None:
        raise IntakeError("invalid_document", "DOCX has no document body")
    counters = {"paragraph": 0, "table": 0, "items": 0}

    def count_item() -> None:
        counters["items"] += 1
        if counters["items"] > MAX_CONTENT_ITEMS:
            raise IntakeError("content_limit", "DOCX exceeds content item limit")

    def blocks(container: ET.Element, path: str, depth: int = 0) -> list[dict[str, Any]]:
        if depth > 24:
            raise IntakeError("content_limit", "DOCX nested content is too deep")
        result = []
        for block in container:
            if block.tag == W + "p":
                counters["paragraph"] += 1
                count_item()
                result.append({"kind": "paragraph", "text": _docx_text(block), "source_ref": {
                    "part": "word/document.xml", "paragraph": counters["paragraph"],
                    "path": f"{path}/paragraph[{counters['paragraph']}]",
                }})
            elif block.tag == W + "tbl":
                counters["table"] += 1
                table = counters["table"]
                for row_num, row in enumerate(block.findall(W + "tr"), 1):
                    count_item()
                    row_path = f"{path}/table[{table}]/row[{row_num}]"
                    row_ref = {"part": "word/document.xml", "table": table, "row": row_num, "path": row_path}
                    cells = []
                    column = 1
                    before = row.find(f"{W}trPr/{W}gridBefore")
                    if before is not None:
                        column += _positive_int(before.get(W + "val", "0"), "DOCX gridBefore", allow_zero=True)
                    for cell in row.findall(W + "tc"):
                        count_item()
                        span_node = cell.find(f"{W}tcPr/{W}gridSpan")
                        span = _positive_int(span_node.get(W + "val", "1"), "DOCX cell span") if span_node is not None else 1
                        merge = cell.find(f"{W}tcPr/{W}vMerge")
                        merge_state = None if merge is None else ("start" if merge.get(W + "val") == "restart" else "continue")
                        cell_path = f"{row_path}/cell[{column}]"
                        child_blocks = blocks(cell, cell_path, depth + 1)
                        text = "\n".join(item.get("text", "\t".join(c["text"] for c in item.get("cells", []))) for item in child_blocks)
                        cells.append({"column": column, "text": text, "column_span": span,
                                      "vertical_merge": merge_state, "content": child_blocks,
                                      "source_ref": {**row_ref, "column": column, "path": cell_path}})
                        column += span
                    result.append({"kind": "table_row", "cells": cells, "source_ref": row_ref})
            elif block.tag not in (W + "sectPr", W + "tcPr"):
                # Content controls wrap ordinary paragraphs/tables; preserve order.
                if block.tag == W + "sdt":
                    inner = block.find(W + "sdtContent")
                    if inner is not None:
                        result.extend(blocks(inner, path + "/sdt", depth + 1))
                else:
                    label = block.tag.rsplit("}", 1)[-1]
                    warning = f"DOCX body/cell element {label!r} was not interpreted. Review the original if it contains relevant content."
                    if warning not in warnings:
                        warnings.append(warning)
        return result

    warnings.append("DOCX extraction covers the main document body and tables; headers, footers, comments, images, and embedded objects are not read.")
    return blocks(body, "body")


def _positive_int(value: str, label: str, *, allow_zero: bool = False) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise IntakeError("invalid_document", f"Invalid {label}") from exc
    if number < (0 if allow_zero else 1) or number > 1_048_576:
        raise IntakeError("invalid_document", f"Invalid {label}")
    return number


def _coordinate(reference: str) -> tuple[int, int]:
    match = re.fullmatch(r"\$?([A-Za-z]{1,3})\$?([1-9][0-9]{0,6})", reference)
    if not match:
        raise IntakeError("invalid_document", f"Invalid spreadsheet cell reference: {reference}")
    column = 0
    for letter in match[1].upper():
        column = column * 26 + ord(letter) - ord("A") + 1
    row = int(match[2])
    if column > 16_384 or row > 1_048_576:
        raise IntakeError("invalid_document", f"Spreadsheet cell reference is out of range: {reference}")
    return row, column


def _column_name(column: int) -> str:
    name = ""
    while column:
        column, remainder = divmod(column - 1, 26)
        name = chr(65 + remainder) + name
    return name


def _rich_text(element: ET.Element) -> str:
    # Phonetic annotations are not the cell's displayed text.
    return "".join((node.text or "") for child in element if child.tag != S + "rPh" for node in child.iter() if node.tag == S + "t")


def _date_kind(format_id: int, code: str) -> str | None:
    if format_id in {14, 15, 16, 17, 27, 28, 29, 30, 31, 34, 35, 36, 50, 51, 52, 53, 54, 55, 56, 57, 58}:
        return "date"
    if format_id == 22:
        return "datetime"
    if format_id in {18, 19, 20, 21, 32, 33, 45, 47}:
        return "time"
    if format_id == 46:
        return "duration"
    normalized = re.sub(r'"[^\"]*"|\\.|_.|\*.', "", code.lower())
    if re.search(r"\[[hms]+\]", normalized):
        return "duration"
    normalized = re.sub(r"\[[^\]]*\]", "", normalized).split(";")[0]
    has_date = bool(re.search(r"[yd]", normalized))
    has_time = bool(re.search(r"[hs]", normalized))
    if has_date:
        return "datetime" if has_time else "date"
    if has_time:
        return "time"
    return None


def _styles(package: ZipFile) -> list[tuple[int, str, str | None]]:
    if "xl/styles.xml" not in package.namelist():
        return [(0, "", None)]
    root = _part(package, "xl/styles.xml")
    custom = {int(item.get("numFmtId", "0")): item.get("formatCode", "") for item in root.findall(f"{S}numFmts/{S}numFmt")}
    result = []
    for item in root.findall(f"{S}cellXfs/{S}xf"):
        fmt = int(item.get("numFmtId", "0"))
        code = custom.get(fmt, "")
        result.append((fmt, code, _date_kind(fmt, code)))
    return result or [(0, "", None)]


def _serial_date(raw: str, kind: str, date1904: bool) -> str:
    serial = Decimal(raw)
    if not serial.is_finite() or serial < 0 or serial > 2_958_465:
        raise ValueError("Unsupported date serial")
    day = int(serial)
    if not date1904 and day == 60:
        raise ValueError("Excel's fictional 1900-02-29 cannot be represented as an actual date")
    epoch = datetime(1904, 1, 1) if date1904 else datetime(1899, 12, 31) if day < 60 else datetime(1899, 12, 30)
    value = epoch + timedelta(days=float(serial))
    if kind == "date":
        return value.date().isoformat()
    if kind == "time":
        return value.time().isoformat()
    return value.isoformat()


def _xlsx(package: ZipFile, warnings: list[str]) -> list[dict[str, Any]]:
    workbook = _part(package, "xl/workbook.xml")
    relationships = _part(package, "xl/_rels/workbook.xml.rels")
    targets = {}
    for relation in relationships.findall(PKG + "Relationship"):
        if relation.get("TargetMode") == "External":
            warnings.append("An external workbook relationship was ignored; no external resource was fetched.")
            continue
        target = relation.get("Target", "")
        part = posixpath.normpath(target.lstrip("/") if target.startswith("/") else posixpath.join("xl", target))
        if "\\" in part or part.startswith("../") or part == ".." or ":" in part:
            raise IntakeError("unsafe_archive", "Unsafe workbook relationship target")
        targets[relation.get("Id")] = part
    strings = []
    if "xl/sharedStrings.xml" in package.namelist():
        strings = [_rich_text(item) for item in _part(package, "xl/sharedStrings.xml").findall(S + "si")]
    styles = _styles(package)
    properties = workbook.find(S + "workbookPr")
    date1904 = properties is not None and properties.get("date1904", "false").lower() in {"1", "true"}
    result = []
    total_cells = 0
    for sheet in workbook.findall(f"{S}sheets/{S}sheet"):
        name = sheet.get("name", "")
        rel_id = sheet.get(R + "id")
        if rel_id not in targets:
            raise IntakeError("missing_document_part", f"Worksheet has no local relationship: {name}")
        part = targets[rel_id]
        root = _part(package, part)
        if root.tag != S + "worksheet":
            warnings.append(f"Non-worksheet sheet {name!r} was not interpreted.")
            continue
        merges = []
        for node in root.findall(f"{S}mergeCells/{S}mergeCell"):
            reference = node.get("ref", "")
            ends = reference.split(":")
            if len(ends) not in {1, 2}:
                raise IntakeError("invalid_document", "Invalid merged-cell range")
            first = _coordinate(ends[0])
            last = _coordinate(ends[-1])
            if first[0] > last[0] or first[1] > last[1]:
                raise IntakeError("invalid_document", "Reversed merged-cell range")
            merges.append({"range": reference, "anchor": ends[0], "start": first, "end": last})
        rows = root.findall(f"{S}sheetData/{S}row")
        if len(rows) > MAX_SHEET_ROWS or len(merges) > MAX_MERGE_RANGES or len(rows) * len(merges) > MAX_MERGE_ROW_CHECKS:
            raise IntakeError("content_limit", "Worksheet row or merge-processing limit exceeded")
        result.append({"kind": "sheet", "name": name, "state": sheet.get("state", "visible"),
                       "date_system": "1904" if date1904 else "1900", "merged_ranges": [m["range"] for m in merges],
                       "source_ref": {"sheet": name, "part": part}})
        previous_row = 0
        seen_rows = set()
        for row in rows:
            row_num = _positive_int(row.get("r", str(previous_row + 1)), "worksheet row")
            if row_num in seen_rows:
                raise IntakeError("invalid_document", f"Duplicate row in worksheet {name!r}")
            previous_row = row_num
            seen_rows.add(row_num)
            row_merges = [m for m in merges if m["start"][0] <= row_num <= m["end"][0]]
            cells = []
            previous_col = 0
            seen_cells = set()
            for node in row.findall(S + "c"):
                total_cells += 1
                if total_cells > MAX_SHEET_CELLS:
                    raise IntakeError("content_limit", "Workbook cell limit exceeded")
                reference = node.get("r", f"{_column_name(previous_col + 1)}{row_num}")
                cell_row, column = _coordinate(reference)
                if cell_row != row_num or column in seen_cells:
                    raise IntakeError("invalid_document", "Duplicate or inconsistent worksheet cell reference")
                seen_cells.add(column)
                previous_col = column
                ref = {"sheet": name, "part": part, "row": row_num, "column": column, "cell": reference}
                cell: dict[str, Any] = {"column": column, "source_ref": ref}
                value_node = node.find(S + "v")
                raw_value = value_node.text if value_node is not None and value_node.text is not None else ""
                cell["raw_value"] = raw_value
                value_type = node.get("t", "n")
                if value_type == "s":
                    index = int(raw_value)
                    if index < 0 or index >= len(strings):
                        raise IntakeError("invalid_document", "Shared-string reference is out of range")
                    cell.update(type="string", value=strings[index])
                elif value_type == "inlineStr":
                    inline = node.find(S + "is")
                    cell.update(type="string", value=_rich_text(inline) if inline is not None else "")
                elif value_type in {"str", "e", "d"}:
                    cell.update(type={"str": "string", "e": "error", "d": "date"}[value_type], value=raw_value)
                elif value_type == "b":
                    if raw_value not in {"0", "1"}:
                        raise IntakeError("invalid_document", "Invalid spreadsheet boolean")
                    cell.update(type="boolean", value=raw_value == "1")
                elif raw_value == "":
                    cell.update(type="blank", value=None)
                elif value_type == "n":
                    numeric = Decimal(raw_value)
                    if not numeric.is_finite() or len(numeric.as_tuple().digits) > 4096 or numeric.adjusted() > 308:
                        raise IntakeError("invalid_document", "Spreadsheet number exceeds supported finite range")
                    value = int(numeric) if numeric == numeric.to_integral_value() else float(numeric)
                    if isinstance(value, float) and not math.isfinite(value):
                        raise IntakeError("invalid_document", "Spreadsheet number exceeds supported range")
                    cell.update(type="number", value=value)
                    style_index = int(node.get("s", "0"))
                    if style_index < 0 or style_index >= len(styles):
                        raise IntakeError("invalid_document", "Spreadsheet style reference is out of range")
                    fmt, code, date_kind = styles[style_index]
                    cell.update(number_format_id=fmt, number_format=code)
                    if date_kind and date_kind != "duration":
                        try:
                            cell.update(type=date_kind, value=_serial_date(raw_value, date_kind, date1904))
                        except (ValueError, OverflowError, InvalidOperation) as exc:
                            warnings.append(f"{name}!{reference}: date formatting was not converted ({exc}); raw numeric value retained.")
                    elif date_kind == "duration":
                        cell["type"] = "duration_serial"
                else:
                    raise IntakeError("invalid_document", f"Unsupported worksheet cell type: {value_type}")
                formula = node.find(S + "f")
                if formula is not None:
                    cell["formula"] = formula.text or ""
                    cell["formula_attributes"] = dict(formula.attrib)
                    cell["cached_value_only"] = True
                    if value_node is None:
                        cell["value"] = None
                        cell["type"] = "blank"
                for merge in row_merges:
                    if merge["start"][1] <= column <= merge["end"][1]:
                        cell["merge_range"] = merge["range"]
                        cell["merge_anchor"] = merge["anchor"]
                        cell["merged_continuation"] = (cell_row, column) != merge["start"]
                cells.append(cell)
            result.append({"kind": "table_row", "cells": cells,
                           "merged_ranges": [{"range": m["range"], "anchor": m["anchor"],
                                              "continues_from_previous_row": row_num > m["start"][0]} for m in row_merges],
                           "source_ref": {"sheet": name, "part": part, "row": row_num}})
            if len(result) > MAX_CONTENT_ITEMS:
                raise IntakeError("content_limit", "Workbook content limit exceeded")
    warnings.append("Spreadsheet formula text and cached values are evidence only; formulas are never evaluated. Merged cells are not forward-filled, and rows with missing sequence numbers are retained.")
    return result


def extract_local(path: str | Path) -> dict[str, Any]:
    """Extract an explicitly provided local file, or raise :class:`IntakeError`.

    Supported extensions: .txt, .md, .csv, .json, .docx, .xlsx.  All source
    content, including apparent instructions, remains inert source evidence.
    """
    try:
        source = Path(path).expanduser().resolve(strict=True)
    except FileNotFoundError as exc:
        raise IntakeError("missing_local_source", f"Local input does not exist: {path}") from exc
    except (OSError, RuntimeError, TypeError, ValueError) as exc:
        raise IntakeError("invalid_local_source", "Invalid local input path") from exc
    if not source.is_file():
        raise IntakeError("invalid_local_source", "Local input must be a regular file")
    extension = source.suffix.lower()
    if extension not in {".txt", ".md", ".csv", ".json", ".docx", ".xlsx", '.xls'}:
        raise IntakeError("unsupported_format", f"Unsupported local input extension: {extension or '(none)'}")
    try:
        if source.stat().st_size > MAX_FILE_BYTES:
            raise IntakeError("file_limit", "Local input exceeds file size limit")
        with source.open("rb") as handle:
            if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
                raise IntakeError("invalid_local_source", "Local input must be a regular file")
            raw = handle.read(MAX_FILE_BYTES + 1)
        if len(raw) > MAX_FILE_BYTES:
            raise IntakeError("file_limit", "Local input exceeds file size limit")
    except OSError as exc:
        raise IntakeError("unreadable_local_source", "Cannot read local input") from exc
    warnings: list[str] = []
    if extension == '.xls':
        return _registered_xls(source, raw)
    result: dict[str, Any] = {
        "source": {"path": str(source), "sha256": hashlib.sha256(raw).hexdigest(), "size": len(raw)},
        "format": extension[1:], "content": [], "warnings": warnings, "status": "extracted",
    }
    try:
        if extension in {".docx", ".xlsx"}:
            with _open_package(raw) as package:
                result["content"] = _docx(package, warnings) if extension == ".docx" else _xlsx(package, warnings)
        else:
            decoded, encoding = _decode(raw, warnings)
            result["source"]["encoding"] = encoding
            if extension in {".txt", ".md"}:
                # Iterate rather than allocating millions of objects before checking.
                for number, line in enumerate(io.StringIO(decoded, newline=None), 1):
                    if number > MAX_CONTENT_ITEMS:
                        raise IntakeError("content_limit", "Local input exceeds line limit")
                    result["content"].append({"kind": "line", "text": line.removesuffix("\n"),
                                              "source_ref": {"line": number}})
            elif extension == ".json":
                def invalid_constant(value: str) -> None:
                    raise IntakeError("invalid_json", f"JSON non-finite constant is not allowed: {value}")

                def finite_float(value: str) -> float:
                    converted = float(value)
                    if not math.isfinite(converted):
                        raise IntakeError("invalid_json", "JSON number exceeds supported finite range")
                    return converted

                def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
                    obj = {}
                    for key, value in pairs:
                        if key in obj:
                            raise IntakeError("invalid_json", "JSON has duplicate object keys; cannot preserve an unambiguous object")
                        obj[key] = value
                    return obj

                data = json.loads(decoded, parse_constant=invalid_constant,
                                  parse_float=finite_float, object_pairs_hook=unique_object)
                result["content"] = [{"kind": "json", "data": data, "source_ref": {"json_path": "$"}}]
            elif extension == ".csv":
                try:
                    dialect = csv.Sniffer().sniff(decoded[:8192], delimiters=",;\t|")
                except csv.Error:
                    dialect = csv.excel
                    warnings.append("CSV delimiter could not be detected; comma delimiter used.")
                reader = csv.reader(io.StringIO(decoded, newline=""), dialect, strict=True)
                previous_line = 0
                for number, row in enumerate(reader, 1):
                    result["content"].append({"kind": "table_row", "cells": row,
                                              "source_ref": {"row": number, "line": previous_line + 1, "line_end": reader.line_num}})
                    previous_line = reader.line_num
                    if number > MAX_CONTENT_ITEMS:
                        raise IntakeError("content_limit", "CSV exceeds row limit")
            if len(result["content"]) > MAX_CONTENT_ITEMS:
                raise IntakeError("content_limit", "Local input exceeds content item limit")
        return result
    except IntakeError:
        raise
    except json.JSONDecodeError as exc:
        raise IntakeError("invalid_json", f"Invalid JSON at line {exc.lineno}, column {exc.colno}") from exc
    except (BadZipFile, RuntimeError, NotImplementedError, EOFError) as exc:
        raise IntakeError("invalid_archive", "Cannot read Office archive content") from exc
    except (csv.Error, ValueError, InvalidOperation, OverflowError, RecursionError) as exc:
        raise IntakeError("invalid_document", "Cannot parse local input structure") from exc


def _registered_xls(source, raw):
    """Read an already-reviewed BIFF conversion; never execute Office or macros.

    New BIFF sources require an explicit maintenance conversion registration.
    A missing local artifact never starts a download or an installation.
    """
    registry_path = Path(__file__).resolve().parents[2] / 'profiles/intake-resources.json'
    if not raw.startswith(bytes.fromhex('d0cf11e0a1b11ae1')):
        raise IntakeError('invalid_xls', 'Expected an OLE/BIFF XLS source')
    if not registry_path.is_file():
        raise IntakeError('xls_conversion_unregistered', 'XLS缺已核验本地转换登记；维护阶段登记转换，不自动安装或联网')
    registry = json.loads(registry_path.read_text(encoding='utf-8'))
    sha = hashlib.sha256(raw).hexdigest()
    matches = [r for r in registry.get('resources', []) if r.get('source_sha256') == sha and r.get('status') == 'READY']
    if len(matches) != 1:
        raise IntakeError('xls_conversion_unregistered', '该XLS缺唯一已核验转换；请在维护阶段登记源SHA和转换后XLSX的SHA')
    record = matches[0]
    converted = Path(record['runtime_entry']).expanduser().resolve()
    if converted.suffix.lower() != '.xlsx' or not converted.is_file():
        raise IntakeError('xls_conversion_missing', '已登记XLSX转换文件不存在')
    if converted.stat().st_size > MAX_FILE_BYTES or hashlib.sha256(converted.read_bytes()).hexdigest() != record['sha256']:
        raise IntakeError('xls_conversion_drift', '已登记XLSX转换指纹漂移')
    result = extract_local(converted)
    result['conversion_provenance'] = {'registry': str(registry_path), **record, 'converted_source': result['source']}
    result['source'] = {'path': str(source), 'sha256': sha, 'size': len(raw)}
    result['format'] = 'xls_registered_conversion'
    result['warnings'].append('读取维护阶段已核验的本地BIFF转换；原XLS未修改；源行定位应与原报卡复核。')
    return result
