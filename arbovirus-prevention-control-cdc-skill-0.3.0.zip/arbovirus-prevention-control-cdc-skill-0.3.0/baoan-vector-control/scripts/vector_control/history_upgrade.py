"""Offline, hash-locked maintenance of the audited v3 history resource.

Consumes the reviewed pseudonymous CSVs, not instructions/formulas in original
workbooks. Primary cohorts are deliberately not pooled with unresolved legacy
supplements. No patient information is sent to a network service.
"""
from __future__ import annotations

import copy
import csv
from collections import Counter
from pathlib import Path

from .common import ValidationError, digest, file_hash, read_json, write_json
from .history_import import occupation_group

BIN_VERSION = 'temperature-rain-14d-v2'


def climate_bin_v2(t, r):
    if t is None or r is None:
        return None
    tb = '<20' if t < 20 else '20–<25' if t < 25 else '25–<28' if t < 28 else '≥28'
    rb = '0' if r == 0 else '>0–<50' if r < 50 else '50–<100' if r < 100 else '≥100'
    return {'key': tb + '|' + rb, 'temperature': tb, 'rainfall': rb, 'version': BIN_VERSION, 'label': tb + '℃ / ' + rb + '毫米（14日累计）'}


def _true(value):
    return str(value).lower() == 'true'


def _rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def _scope(source, row):
    """Candidate geographical recoding; never substitute it for adjudication."""
    result = dict(province='unknown', city='unknown', baoan='unknown')
    if source == 'CHIKV':
        scope = row.get('origin_scope')
        value = row.get('origin_baoan_candidate')
        result['baoan'] = {'local_candidate': 'local_candidate', 'imported_candidate': 'imported_candidate'}.get(value, 'unknown')
        if scope == 'outside_guangdong':
            result.update(province='imported_candidate', city='imported_candidate')
        elif scope == 'other_guangdong_city':
            result.update(province='local_candidate', city='imported_candidate')
        elif scope == 'other_shenzhen_district':
            result.update(province='local_candidate', city='local_candidate')
        elif scope == 'baoan_source_reported':
            result.update(province='local_candidate', city='local_candidate')
    else:
        scope = row.get('origin_specificity')
        result['baoan'] = row.get('exact_scoped_origin', 'unknown')
        if result['baoan'] in {'local', 'imported'}:
            result['baoan'] += '_candidate'
        else:
            result['baoan'] = 'unknown'
        if scope in {'outside_country', 'outside_province'}:
            result.update(province='imported_candidate', city='imported_candidate')
        elif scope == 'other_guangdong_city':
            result.update(province='local_candidate', city='imported_candidate')
        elif scope == 'other_shenzhen_district':
            result.update(province='local_candidate', city='local_candidate')
        elif scope == 'guangdong':
            result['province'] = 'local_candidate'
    return result


def _case(row, disease, spec):
    chikv = disease == 'CHIKV'
    origin = ({'真正本地病例': 'local', '输入病例': 'imported'}.get(row['origin_label'], 'unknown') if chikv
              else row.get('exact_scoped_origin', 'unknown'))
    if origin not in {'local', 'imported', 'unknown', 'conflict'}:
        origin = 'unknown'
    street = row.get('street_raw') if chikv else row.get('street')
    community = row.get('community_raw') if chikv else row.get('community')
    name = row.get('site_candidate') if chikv else row.get('candidate_site')
    occ = row.get('occupation_raw') if chikv else row.get('occupation')
    status = 'diagnostic_conflict' if chikv and not _true(row['primary_positive_eligible']) else 'recorded'
    return {
        'id': row['case_id'], 'aliases': [row['old_case_id']] if chikv and row.get('old_case_id') else [],
        'disease': disease, 'status': status, 'primary_cohort': True,
        'case_definition': 'source_positive_nonconflicting_not_lab_readjudicated' if chikv else 'active_confirmed_report_card',
        'onset_date': row.get('onset_date') or None, 'report_date': row.get('report_date') or None,
        'positive_date': (row.get('positive_date') or None) if chikv else None,
        'diagnosis_date': row.get('diagnosis_date') or None,
        'origin': origin, 'origin_label': row.get('origin_label'),
        'origin_original_fields': {k: row.get(k) for k in (['origin_detail', 'origin_label2', 'origin_label'] if chikv else ['origin_label', 'origin_specificity', 'exact_scoped_origin', 'hypothesis_origin'])},
        'origin_revision_known_at': row.get('origin_revision_known_at') or None,
        'origin_known_at': None, 'record_observed_at': spec.get('observed_at'),
        'origin_scope': 'baoan_source_classification_not_readjudicated',
        'origin_geographic_candidates': _scope(disease, row), 'origin_adjudicated': False,
        'occupation': occ or '未提供', 'occupation_raw': occ or None,
        'occupation_group': row.get('occupation_group') or occupation_group(occ),
        'population_group': row.get('age_group') or '未知', 'exposure_profile': None,
        'complete_negative_followup': None,
        'sites': [{'street': street or None, 'community': community or None, 'name': name or None,
                   'role': 'residence', 'site_id': None, 'match_status': 'extracted_candidate',
                   'valid_from': None, 'valid_to': None, 'comparison_key': _site_key(street, name)}],
        'source_refs': [{'source_id': spec['source_id'], 'sheet': spec.get('sheet', 'audited_csv'), 'row': int(row['source_row']), 'file_sha256': spec['original_sha256']}],
        'climate_by_point': {},
    }


def _site_key(street, name):
    import re
    return str(street or '') + '|' + re.sub(r'[\s　，,。]', '', str(name or ''))


def _verified_inputs(manifest):
    if manifest.get('kind') != 'baoan_audited_history_manifest' or manifest.get('schema_version') != '1.0':
        raise ValidationError('不支持的审计历史manifest')
    specs = manifest.get('inputs', {})
    required = {'chikv', 'denv', 'weather_features', 'weather_manifest', 'weather_baseline', 'weather_update', 'legacy_history'}
    if not required <= set(specs):
        raise ValidationError('历史升级manifest缺必要本地输入')
    for key, spec in specs.items():
        for pathkey, hashkey in [('path', 'sha256'), ('original_path', 'original_sha256')]:
            if pathkey not in spec:
                continue
            path = Path(spec[pathkey]).expanduser().resolve()
            if not path.is_file() or file_hash(path) != spec.get(hashkey):
                raise ValidationError('本地输入缺失或SHA256漂移: ' + key + ':' + pathkey)
    if specs['chikv'].get('original_sha256') == specs['denv'].get('original_sha256'):
        raise ValidationError('不同疾病主队列不能使用相同源文件')
    return specs


def build_audited_history(manifest_path, output):
    """Create a new READY resource, or verify and reuse an identical invocation."""
    from .history import catalog, validate_history, STREET_POINTS
    manifest_path, output = Path(manifest_path).resolve(), Path(output).resolve()
    manifest = read_json(manifest_path)
    specs = _verified_inputs(manifest)
    manifest_sha = file_hash(manifest_path)
    if output.exists():
        registry_path = output / 'registry.json'
        if not registry_path.is_file():
            raise ValidationError('输出目录已存在，拒绝覆盖；选择新的维护版本')
        registry = read_json(registry_path)
        if registry.get('status') != 'READY' or registry.get('source_manifest_sha256') != manifest_sha:
            raise ValidationError('已有资源不同或不完整，拒绝覆盖')
        for name, sha in registry['files'].items():
            path = (output / name).resolve()
            if not path.is_relative_to(output) or not path.is_file() or file_hash(path) != sha:
                raise ValidationError('已有READY历史资源漂移: ' + name)
        validate_history(read_json(output / registry['runtime_entry']))
        return dict(registry, operation='verified_idempotent_reuse')
    chikv, denv = _rows(specs['chikv']['path']), _rows(specs['denv']['path'])
    cases = [_case(c, 'CHIKV', specs['chikv']) for c in chikv]
    denv_main = [c for c in denv if c['status'] == 'eligible_confirmed' and _true(c['baoan_residence_code'])]
    cases.extend(_case(c, 'DENV', specs['denv']) for c in denv_main)
    ids = [c['id'] for c in cases]
    if len(ids) != len(set(ids)):
        raise ValidationError('审计主队列病例ID重复，先修复上游审计')
    expected = manifest.get('expected_primary_counts')
    counts = dict(Counter(c['disease'] for c in cases if c['status'] == 'recorded'))
    if expected and expected != counts:
        raise ValidationError('主队列数量与审计manifest不符')
    legacy = validate_history(read_json(specs['legacy_history']['path']))
    aliases = {alias for c in cases for alias in c['aliases']}
    supplements = [copy.deepcopy(c) for c in legacy['cases'] if c['disease'] == 'DENV' or c['id'] not in aliases]
    for c in supplements:
        c['primary_cohort'] = False
        c['supplement_only_reason'] = 'legacy_denv_cross_source_overlap_unresolved' if c['disease'] == 'DENV' else 'legacy_chikv_outside_primary_audited_source'
    wm = read_json(specs['weather_manifest']['path'])
    weather_metadata = {}
    for shard in wm['shards']:
        pid, grid = shard['point_id'], shard['actual_grid']
        meta = {'provider': 'open-meteo', 'model': wm['model'], 'source_type': wm['source_type'],
                'grid_latitude': grid['latitude'], 'grid_longitude': grid['longitude'], 'timezone': grid['timezone'],
                'source_ref': wm['endpoint'], 'units': {'temperature_mean_c': '°C', 'precipitation_sum_mm': 'mm', 'humidity_mean_pct': '%'},
                'window_days': 14, 'excludes_anchor_date': True, 'published_at': None,
                'bin_version': BIN_VERSION, 'daily_semantics': 'provider_daily', 'retrospective_retrieval': True}
        if pid in weather_metadata and weather_metadata[pid] != meta:
            raise ValidationError('同背景点历史天气网格/模型发生变化，必须分层')
        weather_metadata[pid] = meta
        raw_path = Path(specs['weather_manifest']['path']).parent / shard['raw_file']
        if not raw_path.is_file() or file_hash(raw_path) != shard['sha256']:
            raise ValidationError('天气原始响应缺失或漂移: ' + shard['raw_file'])
    features = _rows(specs['weather_features']['path'])
    index = {(w['point_id'], w['anchor_date']): w for w in features}
    if len(index) != len(features):
        raise ValidationError('天气特征点日期重复')
    for c in cases:
        if not c['onset_date']:
            continue
        for pid, meta in weather_metadata.items():
            w = index.get((pid, c['onset_date']))
            complete = bool(w and _true(w['complete_14d']) and _true(w['excludes_anchor_date']))
            t = float(w['temperature_mean_c_14d']) if complete else None
            r = float(w['precipitation_sum_mm_14d']) if complete else None
            c['climate_by_point'][pid] = {'anchor_date': c['onset_date'], 'complete': complete,
                'temperature_mean_14d_c': t, 'rainfall_14d_mm': r,
                'humidity_mean_14d_pct': float(w['humidity_mean_pct_14d']) if complete and w.get('humidity_mean_pct_14d') else None,
                'bin': climate_bin_v2(t, r), 'provenance': meta}
    daily = {}
    for key in ['weather_baseline', 'weather_update']:
        for row in _rows(specs[key]['path']):
            pair = row['point_id'], row['date']
            if pair in daily:
                raise ValidationError('历史天气逐日重复')
            if not _true(row['complete']):
                raise ValidationError('完整逐日输入含未完成日')
            daily[pair] = row
    dates = sorted({d for _, d in daily})
    weather = {'schema_version': '1.0', 'kind': 'historical_daily_weather', 'timezone': 'Asia/Shanghai',
        'source_type': 'reanalysis', 'model': 'era5', 'start_date': dates[0], 'end_date': dates[-1], 'points': {}}
    for pid, meta in weather_metadata.items():
        rows = [r for (p, _), r in sorted(daily.items()) if p == pid]
        weather['points'][pid] = {'metadata': dict(meta, units={'temperature_mean_c': '°C', 'precipitation_sum_mm': 'mm'}),
            'daily': [{'date': r['date'], 'temperature_mean_c': float(r['temperature_2m_mean']),
                       'precipitation_sum_mm': float(r['precipitation_sum']),
                       'humidity_mean_pct': float(r['relative_humidity_2m_mean']),
                       'complete': True} for r in rows]}
    history = {'schema_version': '1.0', 'kind': 'baoan_history_comparison', 'comparison_version': '2.0',
        'resource_version': '0.3.0', 'cases': cases, 'supplemental_cases': supplements,
        'supplement_note': '未解决跨源重复与诊断差异，补充队列只作独立检索，不与主队列相加',
        'weather_metadata': weather_metadata, 'weather_point_assignment': STREET_POINTS,
        'weather_assignment_note': '公共ERA5背景格点；不是小区实测或感染地气候。', 'climate_calendar': {},
        'sources': [{'source_id': specs[k]['source_id'], 'path': specs[k]['original_path'], 'sha256': specs[k]['original_sha256']} for k in ['chikv', 'denv']],
        'quality': {'primary_counts': counts, 'diagnostic_conflicts': sum(c['status'] == 'diagnostic_conflict' for c in cases),
            'complete_negative_followup_count': 0, 'origin_revision_known_at_available': 0,
            'source_file_reimport_new_chikv_cases': 0 if specs['chikv']['original_sha256'] in {x.get('sha256') for x in legacy.get('sources', [])} else None,
            'supplemental_counts': dict(Counter(c['disease'] for c in supplements)),
            'denv_active_confirmed_all_residences': sum(c['status'] == 'eligible_confirmed' for c in denv),
            'denv_main_scope': 'baoan_current_residence_code', 'not_population_denominator': True},
        'coverage': {'onset_start': min(c['onset_date'] for c in cases if c['onset_date']),
                     'onset_end': max(c['onset_date'] for c in cases if c['onset_date']),
                     'weather_start': dates[0], 'weather_end': dates[-1]},
        'manifest': manifest}
    history['fingerprint'] = digest(history)
    validate_history(history)
    output.mkdir(parents=True)
    output.chmod(0o700)
    write_json(output / 'history.json', history)
    write_json(output / 'weather.json', weather)
    write_json(output / 'source-manifest.json', manifest)
    write_json(output / 'catalog.json', catalog(history))
    summary = '# 历史库0.3维护汇总\n\n'
    summary += f"主队列：CHIKV {counts.get('CHIKV', 0)}条源阳性登记（另{history['quality']['diagnostic_conflicts']}条诊断冲突排除）；DENV宝安居住主队列{counts.get('DENV', 0)}条已终审确诊报卡。病例定义不同，按病种分别检索。\n\n"
    summary += '同一11.17文件复核不是新增168病例。旧库未覆盖CHIKV及旧DENV作为独立补充，不能相加。来源最终标签回顾与T时点可知分类分开；来源修订时刻缺失不能默认为当时已知。\n\n'
    summary += '六年天气2020—2025及2026完整更新采用同源ERA5背景；同小区、原职业、职业组、街道与14日温雨交集分别输出。未提供分母、系统阴性随访或确认传播链，计数不是发生率。\n'
    (output / '历史汇总.md').write_text(summary, encoding='utf-8')
    registry = {'schema_version': '1.0', 'resource_type': 'baoan_historical_comparison', 'status': 'READY',
        'operation_scope': 'audited_history_resource_maintenance', 'runtime_entry': 'history.json',
        'source_manifest_sha256': manifest_sha, 'history_fingerprint': history['fingerprint'],
        'summary': history['quality'], 'files': {p.name: file_hash(p) for p in sorted(output.iterdir()) if p.is_file()}}
    write_json(output / 'registry.json', registry)
    return dict(registry, operation='created_new_resource')
