"""Local-only, identifier-minimizing imports of explicitly mapped historical workbooks.

Workbook cells remain inert evidence. No network I/O, formula execution, fuzzy person
matching, inferred outbreak membership, or automatic inference of an input source.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
import hashlib
import hmac
from pathlib import Path
import re

from .common import ValidationError, digest, file_hash
from .intake import extract_local

SCHEMA_VERSION = "1.0"
STREETS = ("新安", "西乡", "航城", "福永", "福海", "沙井", "新桥", "松岗", "燕罗", "石岩")
MISSING = {"", "/", "无", "未提及", "不详", "未知", "None"}


def _text(value):
    return "" if value is None else str(value).strip()


def parse_date(value, year=None):
    """Return (ISO day, evidence basis); never pick a date from ambiguous ranges."""
    text = _text(value)
    if not text or re.search(r"无症状|不详|不明|未知|疑似无|同.+病例|\+\s*\d", text):
        return None, "unavailable"
    if re.search(r"左右|大概|可能|不确定", text) or re.search(r"\d\s*(?:日)?\s*(?:至|到|—|～|~|或|、)\s*(?:\d{1,2}月)?\d", text):
        return None, "ambiguous_date_range"
    if re.search(r"月\d{1,2}日?\s*-\s*\d{1,2}(?:日|月)", text):
        return None, "ambiguous_date_range"
    if isinstance(value, (date, datetime)):
        return value.isoformat()[:10], "explicit_date"
    if re.fullmatch(r"\d{5}(?:\.\d+)?", text):
        serial = float(text)
        if 35000 <= serial <= 60000:
            return (datetime(1899, 12, 30) + timedelta(days=serial)).date().isoformat(), "excel_serial"
    explicit = re.search(r"(?<!\d)(20\d{2})[年/-](\d{1,2})[月/-](\d{1,2})(?:日|\b)", text)
    if explicit:
        try:
            return date(*map(int, explicit.groups())).isoformat(), "explicit_date"
        except ValueError:
            return None, "invalid_date"
    partial = re.search(r"(?<!\d)(\d{1,2})[月/-](\d{1,2})(?:日|\b)", text)
    if not partial or not year:
        return None, "year_missing" if partial else "unavailable"
    # A start/end range is not an exact onset day.
    if re.search(r"\d\s*(?:日)?\s*(?:至|到|—|～|~)\s*\d", text):
        return None, "ambiguous_date_range"
    try:
        return date(int(year), *map(int, partial.groups())).isoformat(), "year_from_manifest"
    except ValueError:
        return None, "invalid_date"


def occupation_group(value):
    """Group reported titles, without turning a title into an exposure assessment."""
    text = _text(value)
    rules = [
        ("建筑装修及安装", r"建筑|工地|木工|瓦工|装修|安装|水电工|电焊|轨道工|砌筑"),
        ("运输配送及流动服务", r"司机|配送|外卖|快递|搬货|搬家|摩的|流动摊"),
        ("保安保洁园林及巡查", r"保安|保洁|环卫|绿化|巡查|巡视|物业|泵站"),
        ("生产制造维修", r"工人|工厂|车间|制造|模具|打包|电镀|维修|加工|普工|生产|螺丝|五金"),
        ("商业餐饮及门店服务", r"销售|业务|店员|商[业贸]|经营|个体|餐饮|饮食|厨|服务|摊贩|理发|前台|中介|建材"),
        ("学生及托幼", r"学生|儿童|幼儿|研究生"),
        ("离退休", r"退休|离退"),
        ("家务待业及无固定职业", r"无业|待业|主妇|宝妈|无固定|自由职业|零工|散工|待入职|保姆"),
        ("医疗教育", r"医生|医师|教师|老师|医护"),
        ("农业", r"务农|农民"),
        ("办公研发及管理", r"公司|职员|职工|员工|办公|文员|研发|工程师|技术|程序|软件|开发|行政|会计|财税|运营|策划|干部|机关|老板|管理|游戏|拍客|摄影|设计|飞行员"),
    ]
    if text in MISSING:
        return "未提供"
    for label, pattern in rules:
        if re.search(pattern, text):
            return label
    return "其他或待核岗位"


def age_group(age):
    if age is None:
        return "年龄未知"
    if age < 5:
        return "0–4岁"
    if age < 18:
        return "5–17岁"
    if age < 60:
        return "18–59岁"
    return "60岁及以上"


def classify_origin(value, *, final_report=False):
    """Baoan acquisition classification, distinct from provincial/city reporting labels."""
    text = re.sub(r"\s+", "", _text(value))
    if final_report:
        return {
            "真正本地病例": ("local", "source_reported_baoan_local"),
            "本地关联外地病例": ("unknown", "external_associated"),
            "输入病例": ("imported", "source_reported_imported"),
            "本地病例": ("unknown", "local_scope_unspecified"),
        }.get(text, ("unknown", "unmapped_origin"))
    if not text or text == "/":
        return "unknown", "unavailable"
    ambiguous = bool(re.search(r"不排除|可能|疑似|存[在有].*感染|\?|？|或|高度怀疑|流调中", text))
    if ambiguous:
        return "unknown", "ambiguous_source_location"
    if re.search(r"初步判[断定]?为?宝安区?本地|宝安区?本地病例|宝安区?本地本例", text):
        return "local", "source_reported_baoan_local_provisional"
    if "输入" in text:
        return "imported", "source_reported_external_to_baoan"
    if "本地" in text:
        return "unknown", "local_scope_unspecified"
    return "unknown", "unmapped_origin"


def _identity(basic, name=None, sex=None, age=None):
    """Identity stays in memory, never emitted. Require name, sex and age for merging."""
    basic = _text(basic)
    name = _text(name)
    if not name:
        match = re.match(r"\s*([\u4e00-\u9fff·]{2,8})[，,、\s]", basic)
        name = match.group(1) if match else ""
    sex = _text(sex)
    if sex not in {"男", "女"}:
        match = re.search(r"(?:^|[，,、\s])([男女])(?:[，,、\s]|$)", basic)
        sex = match.group(1) if match else None
    try:
        numeric_age = float(age)
        numeric_age = int(numeric_age) if numeric_age.is_integer() else numeric_age
    except (TypeError, ValueError):
        match = re.search(r"(?<!\d)(\d{1,3}(?:\.\d+)?)\s*岁", basic)
        numeric_age = float(match.group(1)) if match else None
        if numeric_age is not None and numeric_age.is_integer():
            numeric_age = int(numeric_age)
    if numeric_age is not None and not 0 <= numeric_age <= 120:
        numeric_age = None
    return name, sex, numeric_age


def _streets(value):
    text = _text(value)
    return [street for street in STREETS if street in text]


def _coarse_name(text):
    """Keep only a named estate/village/park; street addresses and unit numbers are removed."""
    text = re.sub(r"\s+", "", _text(text))
    if not text or "同某" in text or "同上" in text or "不详" in text:
        return None
    text = re.sub(r"^(?:\d+[.、．])?(?:住家|住址|居住地|宝安现住址|宝安住址|现住址|宿舍|深圳住址)[：:]?", "", text)
    text = re.split(r"街道|社区", text)[-1]
    text = re.sub(r"^.*?宝安区", "", text)
    # Start after separators to avoid attaching narrative or names to a place label.
    for segment in re.split(r"[，,。；;：:（）()\n]", text):
        segment = re.sub(r"^(?:广东省)?(?:深圳市)?", "", segment)
        match = re.match(r"((?:[\u4e00-\u9fff]{2,22}?(?:花园|新村|小区|公寓|华庭|华府|公馆|名居|名苑|家园|雅苑|新苑|社区|产业园|工业园|工业区|购物中心|大厦|宿舍|村|苑|居))|(?:[\u4e00-\u9fff]{1,22}?德园))", segment)
        if not match:
            continue
        value = match.group(1)
        if any(v in value for v in ["患者", "病例", "居住", "工作单位", "现住", "户籍", "同住", "住家", "住址"]):
            continue
        if len(value) >= 3 and value not in {"工业区", "工业园", "购物中心"}:
            return value
    return None


def normalize_site_name(value):
    """Whitespace/punctuation normalization only; deliberately no semantic aliases."""
    return re.sub(r"[\s\u3000（）()，,。；;：:]", "", _text(value))


def site_key(street, name):
    if not street or not name:
        return None
    return f"{re.sub('街道$', '', _text(street))}::{normalize_site_name(name)}"


def _community_name(value):
    """Strip explicit administrative prefixes only; never apply place aliases."""
    text = re.sub(r"\s+", "", _text(value))
    text = re.split(r"广东省|深圳市|宝安区|街道", text)[-1]
    text = re.sub(r"社区$", "", text)
    # Address regexes can retain the final 区 from an administrative prefix.
    if text.startswith("区") and len(text) > 2:
        text = text[1:]
    for street in STREETS:
        if text.startswith(street) and len(text) - len(street) >= 2:
            text = text[len(street):]
            break
    return text if re.fullmatch(r"[\u4e00-\u9fff]{2,10}", text) else None


def extract_sites(residence, work, street, community, role="resident"):
    """Conservative candidates; no geocoding or unverified name aliases."""
    result = []
    known_streets = _streets(street)
    safe_community = _community_name(community)
    for raw, site_role in [(residence, "residence"), (work, "work")]:
        if _text(raw) in MISSING:
            continue
        segments = re.split(r"\n|[；;]|\d+[.、．](?=[\u4e00-\u9fff])", _text(raw))
        for segment in segments:
            if not segment.strip():
                continue
            explicit = re.search("(" + "|".join(STREETS) + ")街道", segment)
            if "街道" in segment and not explicit:
                continue
            # A non-Baoan residence must not inherit an activity/work street.
            foreign = re.search(r"(?:佛山|东莞|广州|中山|惠州|梅州|兴宁|南宁|桂平|平南|南山区|福田区|龙岗区|龙华区|光明区|坪山区|盐田区)", segment)
            if foreign and "宝安" not in segment:
                continue
            named = _coarse_name(segment)
            street_matches = [explicit.group(1)] if explicit else []
            inferred = False
            if not street_matches and site_role == "residence" and role == "resident":
                street_matches = known_streets
                inferred = True
            if not named and not street_matches:
                continue
            community_tail = re.split(r"广东省|深圳市|宝安区|街道", segment)[-1]
            comm = re.search(r"([\u4e00-\u9fff]{2,10})社区", community_tail)
            comm_value = _community_name(comm.group(1)) if comm else (safe_community if site_role == "residence" and role == "resident" else None)
            for street_name in street_matches or [None]:
                result.append({"street": street_name, "community": comm_value, "name": named,
                               "role": site_role, "match_status": "candidate_extracted" if named else "street_only",
                               "street_basis": "source_column" if inferred else "address_text"})
    if not result and known_streets:
        result.extend({"street": s, "community": safe_community, "name": None,
                       "role": "residence" if role == "resident" else "activity",
                       "match_status": "street_only", "street_basis": "source_column"} for s in known_streets)
    # Activity sheets contain involved streets, not necessarily residence streets.
    if role == "activity":
        for s in known_streets:
            if not any(x["street"] == s for x in result):
                result.append({"street": s, "community": safe_community, "name": None,
                               "role": "activity", "match_status": "street_only", "street_basis": "source_column"})
    return list({digest(site): site for site in result}.values())


def _mapped_value(cells, mapping, key):
    column = mapping.get(key)
    return cells.get(int(column)) if column is not None else None


def _row_record(cells, spec, source_id, row, year, salt):
    mapping = spec["columns"]
    get = lambda key: _mapped_value(cells, mapping, key)
    basic, name = _text(get("basic")), _text(get("name"))
    if not basic and not name:
        return None, "no_case_identity"
    # Trailing name-only tracking rows are incomplete records, not additional cases.
    if not any(_text(get(k)) not in MISSING for k in ("onset", "positive", "residence", "work", "origin", "street")):
        return None, "name_only_tracking_row"
    name, sex, age = _identity(basic, name, get("sex"), get("age"))
    onset, onset_basis = parse_date(get("onset"), year)
    reported, report_basis = parse_date(get("report"), year)
    positive, positive_basis = parse_date(get("positive"), year)
    origin, origin_category = classify_origin(get("origin"), final_report=spec.get("final_report_origin", False))
    raw_status = " ".join(_text(get(k)) for k in ["affiliation", "basic", "origin"])
    status = "excluded" if re.search(r"核销|复核阴性", raw_status) else ("unconfirmed" if spec.get("special") else "recorded")
    raw_occupation = _text(get("occupation"))
    if raw_occupation in MISSING and basic:
        match = re.search(r"\d+(?:\.\d+)?岁[，,、\s](.+)", basic)
        raw_occupation = match.group(1) if match else ""
    source_ref = {"source_id": source_id, "sheet": spec["sheet"], "row": row}
    role = spec.get("role", "resident")
    sites = extract_sites(get("residence"), get("work"), get("street"), get("community"), role)
    for site in sites:
        site["source_refs"] = [source_ref]
        site["key"] = site_key(site["street"], site["name"])
    # The identity key never leaves memory. A name alone is never sufficient.
    identity_key = (name, sex, age, spec["disease"])
    eligible_merge = bool(name) and sex is not None and age is not None and onset is not None
    event_key = (*identity_key, onset) if eligible_merge else (source_id, spec["sheet"], row)
    anonymous = hmac.new(salt, repr(event_key).encode(), hashlib.sha256).hexdigest()[:24]
    record = {
        "id": "H-" + anonymous, "disease": spec["disease"], "onset_date": onset,
        "report_date": reported, "positive_date": positive,
        "date_basis": {"onset": onset_basis, "report": report_basis, "positive": positive_basis},
        "origin": origin, "origin_scope": "Baoan", "origin_evidence_category": origin_category,
        "origin_conflict": False, "origin_history": [{"origin": origin, "category": origin_category, "source_ref": source_ref}],
        "record_role": role, "record_roles": [role], "status": status,
        "occupation": occupation_group(raw_occupation), "age": age, "age_group": age_group(age), "sex": sex,
        "sites": sites, "source_refs": [source_ref], "confirmed_outbreak_ids": None,
        "deduplication": {"method": "name_sex_age_disease_exact_onset" if eligible_merge else "unmerged_insufficient_identity_or_date", "merged_records": 1},
    }
    return (record, event_key, spec.get("priority", 0)), None


def _merge(existing, record, preferred):
    first, second = (record, existing) if preferred else (existing, record)
    output = dict(first)
    output["source_refs"] = existing["source_refs"] + record["source_refs"]
    output["origin_history"] = existing["origin_history"] + record["origin_history"]
    origins = {x["origin"] for x in output["origin_history"] if x["origin"] != "unknown"}
    output["origin_conflict"] = len(origins) > 1
    if output["origin_conflict"]:
        output["origin"] = "conflict"
        output["origin_evidence_category"] = "discordant_source_classifications"
    output["record_roles"] = sorted(set(existing["record_roles"] + record["record_roles"]))
    if "resident" in output["record_roles"]:
        output["record_role"] = "resident"
    output["deduplication"] = {"method": "name_sex_age_disease_exact_onset", "merged_records": len(output["source_refs"])}
    sites = {}
    for site in existing["sites"] + record["sites"]:
        key = (site["street"], site["community"], site["name"], site["role"])
        if key in sites:
            sites[key]["source_refs"] += site["source_refs"]
        else:
            sites[key] = dict(site)
            sites[key]["source_refs"] = list(site["source_refs"])
    output["sites"] = list(sites.values())
    for key in ["report_date", "positive_date"]:
        if output[key] is None:
            output[key] = second[key]
    return output


def build_registry(manifest, salt):
    """Build an anonymous registry from a persisted, explicit local input manifest.

    Manifest sources require path, source_id, expected sha256, and explicitly mapped
    sheets. `year` is only a documented default for partial dates, never inferred
    from wall-clock time or a workbook filename. Salt is private, >=16 random bytes.
    """
    if not isinstance(salt, bytes) or len(salt) < 16:
        raise ValidationError("历史导入需要至少16字节私有HMAC盐值")
    if not isinstance(manifest, dict) or not manifest.get("sources"):
        raise ValidationError("历史导入需先持久化显式本地输入manifest")
    sources, records, priorities = [], {}, {}
    possible_duplicates = defaultdict(set)
    quality = {"sheets": [], "excluded_rows": Counter(), "warnings": [], "raw_case_records": 0}
    seen_source_ids = set()
    for source in manifest["sources"]:
        source_id, path = source.get("source_id"), Path(source.get("path", ""))
        if not source_id or source_id in seen_source_ids:
            raise ValidationError("历史来源source_id必须唯一")
        seen_source_ids.add(source_id)
        if not path.is_file():
            raise ValidationError("历史本地输入文件不存在")
        current_hash = file_hash(path)
        if current_hash != source.get("sha256"):
            raise ValidationError("历史本地输入文件指纹与manifest不符")
        year = source.get("year")
        if year is not None and (not isinstance(year, int) or not 1900 <= year <= 2100 or not source.get("year_basis")):
            raise ValidationError("部分日期的来源年份需要显式年份及year_basis")
        extracted = extract_local(path)
        by_sheet = defaultdict(list)
        for item in extracted["content"]:
            if item["kind"] == "table_row":
                by_sheet[item["source_ref"]["sheet"]].append(item)
        specs = source.get("sheets", [])
        if not specs or len({s["sheet"] for s in specs}) != len(specs):
            raise ValidationError("历史来源必须包含唯一的显式sheet映射")
        for spec in specs:
            if spec["sheet"] not in by_sheet or spec.get("disease") not in {"CHIKV", "DENV"}:
                raise ValidationError("历史sheet不存在或病种未明确")
            stats = {"source_id": source_id, "sheet": spec["sheet"], "included_records": 0, "excluded_rows": Counter()}
            for item in by_sheet[spec["sheet"]]:
                row = item["source_ref"]["row"]
                if row <= spec["header_row"]:
                    continue
                cells = {cell["column"]: cell.get("value") for cell in item["cells"]}
                if not any(_text(v) for v in cells.values()):
                    continue
                parsed, skip = _row_record(cells, spec, source_id, row, year, salt)
                if skip:
                    stats["excluded_rows"][skip] += 1
                    quality["excluded_rows"][skip] += 1
                    continue
                record, event_key, priority = parsed
                if spec.get("duplicate_view_only") and event_key not in records:
                    stats["excluded_rows"]["unresolved_administrative_copy"] += 1
                    quality["excluded_rows"]["unresolved_administrative_copy"] += 1
                    continue
                stats["included_records"] += 1
                quality["raw_case_records"] += 1
                # Diagnostic only: never merge these weaker same-name candidates.
                identity_name = _identity(_mapped_value(cells, spec["columns"], "basic"), _mapped_value(cells, spec["columns"], "name"))[0]
                if identity_name:
                    possible_duplicates[(identity_name, spec["disease"])].add(record["id"])
                if event_key in records:
                    records[event_key] = _merge(records[event_key], record, priority > priorities[event_key])
                    priorities[event_key] = max(priority, priorities[event_key])
                else:
                    records[event_key] = record
                    priorities[event_key] = priority
            stats["excluded_rows"] = dict(stats["excluded_rows"])
            quality["sheets"].append(stats)
        sources.append({"source_id": source_id, "filename": path.name, "sha256": current_hash,
                        "year": year, "year_basis": source.get("year_basis"),
                        "sheet_names": [s["sheet"] for s in specs],
                        "unmapped_sheets": sorted(set(by_sheet) - {s["sheet"] for s in specs})})
    cases = sorted(records.values(), key=lambda r: (r["onset_date"] or "9999", r["id"]))
    quality["excluded_rows"] = dict(quality["excluded_rows"])
    quality["deduplicated_cases"] = len(cases)
    quality["merged_duplicate_records"] = quality["raw_case_records"] - len(cases)
    quality["by_disease_status"] = dict(Counter(f'{r["disease"]}:{r["status"]}' for r in cases))
    quality["by_origin"] = dict(Counter(r["origin"] for r in cases))
    quality["missing_onset"] = sum(r["onset_date"] is None for r in cases)
    quality["year_imputed_onset"] = sum(r["date_basis"]["onset"] == "year_from_manifest" for r in cases)
    quality["conflicting_origins"] = sum(r["origin_conflict"] for r in cases)
    quality["possible_same_name_duplicate_groups_unmerged"] = sum(len(ids) > 1 for ids in possible_duplicates.values())
    quality["possible_same_name_records_unmerged"] = sum(len(ids) for ids in possible_duplicates.values() if len(ids) > 1)
    quality["confirmed_outbreak_data"] = "not_provided"
    quality["warnings"] = [
        "病例记录不是暴发事件；未提供官方暴发编号或事件成员，相关数量必须显示未知。",
        "街道小区统计为已提供历史记录的病例关联，不是发病率或当前风险概率；居住地不等于感染地。",
        "只以姓名、性别、年龄、病种及完全相同的发病日合并，未达条件的重复可能仍存在。",
        "小区名称为保守文本抽取候选，未完成地图或标准地址库核实；不做模糊小区合并。",
        "职业为粗分类，不代表户外暴露或个人易感性；核销和未确认病例须单列并排除主病例计数。",
    ]
    dates = [r["onset_date"] for r in cases if r["onset_date"]]
    return {"schema_version": SCHEMA_VERSION, "kind": "baoan_historical_case_registry",
            "manifest": {"sha256": digest(manifest), "source_count": len(sources), "date_policy": "explicit_date_or_documented_source_year", "privacy": "HMAC identifiers; no names, phone numbers, identity documents or residential units"},
            "sources": sources, "quality": quality,
            "coverage": {"onset_start": min(dates) if dates else None, "onset_end": max(dates) if dates else None},
            "cases": cases}


def baoan_source_manifest(paths):
    """Explicit adapters for the two user-provided workbook structures, not discovery."""
    if len(paths) != 2:
        raise ValidationError("此适配器要求按顺序显式提供两份历史工作簿")
    common = {"affiliation": 2, "origin": 3, "street": 4, "occupation": 5, "basic": 6,
              "residence": 7, "work": 9, "positive": 10, "onset": 11}
    chikv = {"affiliation": 2, "origin": 3, "street": 4, "community": 5, "occupation": 6,
             "basic": 7, "residence": 8, "work": 10, "positive": 11, "onset": 12, "report": 17}
    specs = [
        {"sheet": "基孔肯雅热", "header_row": 2, "disease": "CHIKV", "role": "resident", "columns": chikv},
        {"sheet": "工作地或活动涉-基孔", "header_row": 2, "disease": "CHIKV", "role": "activity", "columns": {k:v for k,v in chikv.items() if k != "report"}},
        {"sheet": "登革热", "header_row": 2, "disease": "DENV", "role": "resident", "columns": common},
        {"sheet": "仅活动涉-登革热", "header_row": 1, "disease": "DENV", "role": "activity", "columns": {"affiliation":2, "origin":3, "basic":4, "positive":5, "onset":6, "work":7}},
        {"sheet": "特殊基孔", "header_row": 2, "disease": "CHIKV", "role": "special", "special": True, "columns": common},
        {"sheet": "南山区未报卡", "header_row": 2, "disease": "DENV", "role": "activity", "special": True, "columns": common},
        {"sheet": "行政版登革热 ", "header_row": 2, "disease": "DENV", "role": "resident", "columns": common, "priority": -1, "duplicate_view_only": True},
    ]
    first = {"sheet":"表格视图", "header_row":1, "disease":"CHIKV", "role":"resident", "priority":10, "final_report_origin":True,
             "columns":{"report":2,"name":3,"origin":6,"street":7,"community":8,"residence":9,"work":10,"sex":11,"age":12,"occupation":13,"onset":14,"positive":15}}
    return {"schema_version":"1.0", "sources":[
        {"source_id":"case_view", "path":str(Path(paths[0]).resolve()), "sha256":file_hash(paths[0]), "year":2025,
         "year_basis":"Source contains explicit 2025 onset, report and positive dates; partial dates use this documented source year.", "sheets":[first]},
        {"source_id":"case_details", "path":str(Path(paths[1]).resolve()), "sha256":file_hash(paths[1]), "year":2025,
         "year_basis":"Explicit 2025 report dates and Excel serial dates establish this source chronology; yearless onset dates are marked year_from_manifest.", "sheets":specs},
    ]}
