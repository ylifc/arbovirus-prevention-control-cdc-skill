"""Traceable historical comparisons; no case-count to probability conversion."""
from __future__ import annotations

import copy
import re
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path

from .common import ValidationError, day, digest, file_hash, read_json, write_json
from .history_weather import climate_bin, validate_history_weather, window_features
from .history_import import occupation_group as import_occupation_group
from .history_baseline import climate_baseline

STREET_POINTS = {s: ('baoan_south_background' if s in {'新安', '西乡', '航城'} else 'baoan_north_background')
                 for s in ['新安', '西乡', '航城', '福永', '福海', '沙井', '新桥', '松岗', '燕罗', '石岩']}


def site_key(street, name):
    """Only normalize whitespace/punctuation, never fuzzy-merge two places."""
    return str(street or '') + '|' + re.sub(r'[\s　，,。]', '', str(name or ''))


def _community(value):
    return re.sub(r'社区$', '', str(value or '').strip())


def _anchor(case, assessment_at):
    return case.get('onset_date') or (case.get('infectious_window') or {}).get('start', '')[:10] or assessment_at[:10]


def age_group(age):
    if not isinstance(age, (int, float)) or isinstance(age, bool) or not 0 <= age <= 120:
        return '未知'
    return '0–4岁' if age < 5 else '5–17岁' if age < 18 else '18–59岁' if age < 60 else '60岁及以上'


def occupation_group(value):
    labels = {'建筑装修及安装', '运输配送及流动服务', '保安保洁园林及巡查', '生产制造维修',
              '商业餐饮及门店服务', '学生及托幼', '离退休', '家务待业及无固定职业',
              '医疗教育', '农业', '办公研发及管理', '未提供', '其他或待核岗位'}
    return value if value in labels else import_occupation_group(value)


def _count(cases):
    unique = {c['id']: c for c in cases}
    origin = Counter(c.get('origin', 'unknown') for c in unique.values())
    dates = sorted(c.get('onset_date') or c.get('report_date') or c.get('positive_date') for c in unique.values() if c.get('onset_date') or c.get('report_date') or c.get('positive_date'))
    return {'registered_cases': len(unique), 'local': origin['local'], 'imported': origin['imported'],
            'unknown': origin['unknown'], 'origin_conflict': origin['conflict'],
            'unknown_or_conflict': sum(n for k, n in origin.items() if k not in {'local', 'imported'}),
            'first_date': dates[0] if dates else None, 'last_date': dates[-1] if dates else None,
            'by_year': dict(sorted(Counter((c.get('onset_date') or c.get('report_date') or c.get('positive_date') or '未知')[:4] for c in unique.values()).items())),
            'known_only_by_onset_cases': sum(not c.get('report_date') and not c.get('positive_date') for c in unique.values()),
            'source_refs': sorted({f"{r['source_id']}:{r['sheet']}!row{r['row']}" for c in unique.values() for r in c.get('source_refs', [])})}


def rolling_windows(cases, disease, threshold=3):
    """Report-day windows are descriptive; incomplete diagnosis/origin is not repaired."""
    span = 12 if disease == 'CHIKV' else 14
    local = {c['id']: c for c in cases if c.get('origin') == 'local'}
    dated = [c for c in local.values() if c.get('report_date')]
    windows = []
    for end in sorted({c['report_date'] for c in dated}):
        start = (day(end) - timedelta(days=span - 1)).isoformat()
        ids = sorted(c['id'] for c in dated if start <= c['report_date'] <= end)
        if len(ids) >= threshold:
            windows.append({'start': start, 'end': end, 'case_count': len(ids), 'case_ids': ids})
    involved = set().union(*(set(w['case_ids']) for w in windows)) if windows else set()
    return {'kind': 'descriptive_local_record_windows', 'days': span, 'threshold': threshold,
            'date_basis': 'report_date', 'peak_count': max((w['case_count'] for w in windows), default=0),
            'unique_cases_in_windows': len(involved), 'missing_report_date_local_cases': len(local) - len(dated),
            'windows': windows, 'note': '重叠窗口不可当多起事件；来源沿用原表属地口径，未证实传播链或正式暴发。'}


def _summary(cases, disease, threshold=None):
    count = _count(cases)
    count['multi_case_windows'] = rolling_windows(cases, disease, threshold) if threshold else None
    # No event surveillance denominator is present in these case workbooks.
    count['confirmed_outbreak_events'] = None
    count['confirmed_outbreak_cases'] = None
    count['outbreak_evidence_status'] = '未提供经核验事件清单，不能核定暴发次数或病例数'
    return count


def compile_history(case_registry, historical_weather=None):
    if case_registry.get('kind') != 'baoan_historical_case_registry':
        raise ValidationError('不是支持的历史病例库')
    out = copy.deepcopy(case_registry)
    out['kind'] = 'baoan_history_comparison'
    out['comparison_version'] = '1.0'
    out['weather_point_assignment'] = STREET_POINTS
    out['weather_assignment_note'] = '按街道指定公共背景代理，不是小区实测或已核验最近站。'
    weather = validate_history_weather(historical_weather) if historical_weather else None
    out['weather_metadata'] = {pid: {k: v for k, v in p.get('metadata', {}).items() if k != 'raw_response'} for pid, p in (weather or {}).get('points', {}).items()}
    out['weather_quality'] = {pid: p.get('quality') for pid, p in (weather or {}).get('points', {}).items()}
    out['climate_calendar'] = {}
    if weather:
        for disease in ('DENV', 'CHIKV'):
            dates = sorted(c['onset_date'] for c in out['cases'] if c.get('disease') == disease and c.get('status') == 'recorded' and c.get('onset_date'))
            if dates:
                out['climate_calendar'][disease] = {pid: climate_baseline(weather, dates[0], dates[-1], pid) for pid in weather['points']}
    # Preserve only necessary pseudonymous dimensions in the compiled resource.
    for c in out['cases']:
        c['occupation_group'] = occupation_group(c.get('occupation'))
        c['population_group'] = age_group(c.get('age'))
        c['climate_by_point'] = {}
        for s in c.get('sites', []):
            s['comparison_key'] = site_key(s.get('street'), s.get('name'))
        if weather and c.get('onset_date'):
            for pid in weather['points']:
                features = window_features(weather, pid, c['onset_date'])
                features['bin'] = climate_bin(features.get('temperature_mean_14d_c'), features.get('rainfall_14d_mm')) if features.get('complete') else None
                c['climate_by_point'][pid] = features
    out['fingerprint'] = digest({k: v for k, v in out.items() if k != 'fingerprint'})
    return out


def validate_history(history):
    if history.get('kind') != 'baoan_history_comparison' or history.get('schema_version') != '1.0':
        raise ValidationError('历史比较库类型或版本不支持')
    if digest({k: v for k, v in history.items() if k != 'fingerprint'}) != history.get('fingerprint'):
        raise ValidationError('历史比较库内部指纹漂移')
    ids = [c['id'] for c in history.get('cases', [])]
    if len(ids) != len(set(ids)):
        raise ValidationError('历史病例ID重复')
    return history


def load_registered_history(root, source='auto'):
    if source == 'none':
        return None, None
    if source == 'auto':
        pointer = Path(root) / 'profiles/history-resource.json'
        if not pointer.exists():
            return None, None
        registry_path = Path(read_json(pointer)['registry_path'])
    else:
        registry_path = Path(source).expanduser().resolve()
    registry = read_json(registry_path)
    if registry.get('status') != 'READY':
        raise ValidationError('历史资源未READY，请在维护阶段核查')
    for name, sha in registry['files'].items():
        path = (registry_path.parent / name).resolve()
        if not path.is_relative_to(registry_path.parent.resolve()) or not path.is_file() or file_hash(path) != sha:
            raise ValidationError('历史资源缺失或指纹漂移: ' + name)
    resource = registry_path.parent / registry['runtime_entry']
    history = validate_history(read_json(resource))
    return history, {'registry_path': str(registry_path), 'registry_sha256': file_hash(registry_path),
                     'original_path': str(resource), 'sha256': file_hash(resource), 'history_fingerprint': history['fingerprint']}


def _eligible_cases(history, disease, cutoff, exclude_ids=()):
    result, excluded = [], Counter()
    for c in history['cases']:
        if c.get('disease') != disease:
            continue
        if ({c['id']} | set(c.get('aliases', []))) & set(exclude_ids):
            excluded['current_case_explicitly_excluded'] += 1
            continue
        if c.get('status') in {'excluded', 'unconfirmed', 'diagnostic_conflict'}:
            excluded['excluded_or_unconfirmed'] += 1
            continue
        onset, report, positive = c.get('onset_date'), c.get('report_date'), c.get('positive_date')
        if not (onset or report or positive):
            excluded['undated'] += 1
            continue
        # Avoid later reports, not just later onset dates, in a retrospective cutoff.
        if any(d >= cutoff for d in (onset, report, positive) if d):
            excluded['not_before_cutoff'] += 1
            continue
        result.append(c)
    return result, dict(excluded)


def _place_cases(cases, street=None, key=None, community=None):
    return [c for c in cases if any(s.get('role') == 'residence' and
            (street is None or s.get('street') == street) and
            (key is None or s.get('comparison_key') == key) and
            (community is None or _community(s.get('community')) == community) for s in c.get('sites', []))]


def _place_match(history, site):
    catalog = {}
    communities = defaultdict(set)
    for c in history['cases']:
        for s in c.get('sites', []):
            if s.get('name') and s.get('role') == 'residence':
                catalog[s['comparison_key']] = s
                if s.get('community'):
                    communities[s['comparison_key']].add(_community(s['community']))
    explicit = site.get('historical_site_key')
    if explicit:
        if not site.get('historical_match_ref') or explicit not in catalog or catalog[explicit].get('street') != site.get('street'):
            raise ValidationError('人工历史场所匹配缺依据、key不存在或街道不符')
        key = explicit
    else:
        key = site_key(site.get('street'), site.get('name'))
    known = communities[key]
    provided = _community(site.get('community'))
    if key in catalog and ((len(known) > 1 and not provided) or (provided and known and provided not in known)):
        return {'status': 'ambiguous_community', 'key': None, 'candidates': [dict(key=key, name=catalog[key]['name'], community=c) for c in sorted(known)],
                'note': '同街道同名地点社区冲突；未明确前不合并为同一小区。'}
    if key in catalog:
        return {'status': 'reviewed' if explicit else 'exact_extracted_name', 'key': key, 'name': catalog[key]['name'],
                'community_filter': provided or None, 'evidence_ref': site.get('historical_match_ref'),
                'note': '按原表抽取候选同名统计；地址边界与同一小区仍需核验，未证明感染发生地'}
    name = str(site.get('name') or '')
    candidates = [dict(key=k, name=s['name'], street=s.get('street')) for k, s in catalog.items()
                  if site.get('street') and s.get('street') == site.get('street') and
                  len(s['name']) >= 3 and (s['name'] in name or (len(name) >= 3 and name in s['name']))]
    return {'status': 'candidate_requires_review' if candidates else 'not_matched_in_registry',
            'key': None, 'candidates': sorted(candidates, key=lambda s: s['key'])}


def _current_climate(weather, pid, anchor):
    point = weather.get('points', {}).get(pid, {})
    daily = {d['date']: d for d in point.get('daily', [])}
    dates = [(day(anchor) - timedelta(days=i)).isoformat() for i in range(14, 0, -1)]
    temp = [daily.get(d, {}).get('temperature_mean_c') for d in dates]
    rain = [daily.get(d, {}).get('precipitation_mm') for d in dates]
    # Existing current-weather module uses explicit daily field names.
    if all(t is None for t in temp):
        temp = [daily.get(d, {}).get('temperature_c_mean') for d in dates]
    if all(r is None for r in rain):
        rain = [daily.get(d, {}).get('precipitation_mm_sum') for d in dates]
    complete = len(temp) == 14 and all(isinstance(v, (int, float)) for v in temp + rain)
    t = sum(temp) / 14 if complete else None
    r = sum(rain) if complete else None
    return {'anchor_date': anchor, 'window_start': dates[0], 'window_end_exclusive': anchor,
            'complete': complete, 'temperature_mean_14d_c': t, 'rainfall_14d_mm': r,
            'bin': climate_bin(t, r) if complete else None, 'point_id': pid,
            'model': point.get('metadata', {}).get('model'), 'source_type': point.get('metadata', {}).get('source_type')}


def _climate_match(cases, climate, pid):
    comparable = [c for c in cases if c.get('climate_by_point', {}).get(pid, {}).get('bin')]
    key = (climate.get('bin') or {}).get('key')
    matches = [c for c in comparable if c['climate_by_point'][pid]['bin']['key'] == key] if key else None
    return matches, {'eligible_case_count': len(cases), 'cases_with_complete_weather': len(comparable),
                     'cases_missing_weather': len(cases) - len(comparable)}


def exposure_hints(case, activities):
    group = occupation_group(case.get('occupation'))
    advice = {
        '环卫/园林/农业': '重点核实日间户外、植被与积水点停留和驱避防护。',
        '建筑/施工': '重点核实工地积水、露天作业、工棚及宿舍共同暴露。',
        '外勤/配送/运输': '按实际站点、候客和装卸停留调查；不能把全部行驶路线作为疫点。',
        '保安/物业': '核实门岗巡逻、保洁绿化、植被积水、地下空间及班次的实际蚊暴露。',
        '商业服务': '核实门店开放程度、顾客接待区域、上下班及宿舍；销售不自动等于户外岗位。',
        '餐饮食品': '核实后厨、后场容器、露天就餐和休息区防蚊。',
        '工人': '区分封闭车间、装卸和户外工序，核实班次及厂区宿舍。',
        '学生/儿童': '核实学校、家庭及户外活动共同地点，不将同学关系直接认定感染。',
        '家务/待业/退休': '核实白天居家、社区活动和容器积水，不能推定全天在家。',
        '室内专业/行政': '核实门窗防蚊和室外停留，不能仅凭室内职业判低风险。',
        '未知/其他': '补充具体岗位、工作地点、班次、室内外停留和防蚊措施。',
    }
    advice_map = {'建筑装修及安装': '建筑/施工', '运输配送及流动服务': '外勤/配送/运输',
                  '保安保洁园林及巡查': '保安/物业', '生产制造维修': '工人',
                  '商业餐饮及门店服务': '商业服务', '学生及托幼': '学生/儿童',
                  '离退休': '家务/待业/退休', '家务待业及无固定职业': '家务/待业/退休',
                  '医疗教育': '室内专业/行政', '农业': '环卫/园林/农业', '办公研发及管理': '室内专业/行政'}
    reviewed = [a for a in activities if a.get('evidence_ref')]
    yes = any(a.get('mosquito_exposure') == 'yes' for a in reviewed)
    outdoor = any(a.get('outdoor') is True for a in reviewed)
    return {'case_id': case['case_id'], 'occupation_group': group,
            'exposure_hint': '已报告蚊暴露，优先核查具体场所时段' if yes else '已记录户外活动，优先核查防护与蚊暴露' if outdoor else '实际蚊暴露待核，不能按职业标签判高低',
            'task': advice[advice_map.get(group, '未知/其他')], 'population_group': age_group(case.get('age')),
            'care_hint': '年龄提示防护执行与照护需重点核实；不增加传染性分值' if isinstance(case.get('age'), (int, float)) and (case['age'] < 5 or case['age'] >= 60) else '共同活动和防护执行单列核实；人群构成不等于传播概率'}


def compare_history(data, weather, history):
    if history is None:
        return {'status': 'not_connected', 'message': '历史库未接入，历史病例与暴发数未知。', 'site_comparisons': []}
    validate_history(history)
    if history.get('comparison_version') == '2.0':
        return _compare_history_v2(data, weather, history)
    cases = {c['case_id']: c for c in data['cases']}
    links = defaultdict(set)
    for c in cases.values():
        for link in c.get('site_links', []):
            links[link['site_id']].add(c['case_id'])
    for a in data['activities']:
        links[a['site_id']].add(a['case_id'])
    result = {'status': 'available', 'history_fingerprint': history['fingerprint'], 'source_quality': history.get('quality'),
              'origin_scope_note': '本地/输入沿用历史表属地分类；未转换为省际输入口径，不能直接进入规范事件计数。',
              'statistics_note': '涉宝安登记含居民及工作/活动关联；不是居民总体、发病率或感染概率。输入病例的宝安背景天气不代表实际感染地气候。无记录不等于无风险。仅有发病日期者是回顾性比较，不能重建当时已知病例数。',
              'sources': history.get('sources'), 'site_comparisons': [], 'person_comparisons': []}
    for s in data['sites']:
        for disease in sorted({cases[c]['disease'] for c in links[s['site_id']]}):
            linked = [cases[c] for c in sorted(links[s['site_id']]) if cases[c]['disease'] == disease]
            anchors = sorted({c.get('onset_date') or (c.get('infectious_window') or {}).get('start', '')[:10] for c in linked} - {None, ''})
            anchor = anchors[0] if anchors else data['assessment_at'][:10]
            excluded_ids = [i for c in linked for i in c.get('historical_case_ids', [])]
            base, exclusions = _eligible_cases(history, disease, anchor, excluded_ids)
            matched = _place_match(history, s)
            same_street = _place_cases(base, street=s.get('street')) if s.get('street') else None
            same_site = _place_cases(base, key=matched['key'], community=matched.get('community_filter')) if matched.get('key') else None
            pid = s.get('weather_point_id') or STREET_POINTS.get(s.get('street'))
            anchor_weather = weather.get('comparison_windows', {}).get(anchor, weather)
            climate = _current_climate(anchor_weather, pid, anchor)
            climate['anchor_basis'] = '最早已记录发病/候选窗口起日' if anchors else '缺发病日，使用判定日前14日背景'
            same_climate, coverage = _climate_match(base, climate, pid)
            intersect, _ = _climate_match(same_site or [], climate, pid)
            climate_models = {m.get('model') for p, m in history.get('weather_metadata', {}).items() if p == pid}
            climate['comparison_kind'] = 'same_model_descriptive' if climate.get('model') and climate_models == {climate['model']} else 'cross_model_descriptive_requires_caution'
            row = {'site_id': s['site_id'], 'site_name': s['name'], 'street': s.get('street'), 'disease': disease,
                   'cutoff_exclusive': anchor, 'excluded': exclusions, 'place_match': matched,
                   'district_history': _summary(base, disease),
                   'street_history': _summary(same_street, disease, 10) if same_street is not None else None,
                   'site_history': _summary(same_site, disease, 3) if same_site is not None else None,
                   'climate': climate, 'climate_coverage': coverage,
                   'same_climate_history': _summary(same_climate, disease) if same_climate is not None else None,
                   'site_and_climate_history': _summary(intersect, disease) if same_site is not None and intersect is not None else None}
            sh = row['site_history']
            row['historical_hint'] = ('同名地点记录有历史本地多例时段，优先核实地址关联及现状' if sh and sh['multi_case_windows']['peak_count'] >= 3 else
                                      '同名地点记录有历史本地登记，结合地址核对与现况调查' if sh and sh['local'] else
                                      '已匹配历史地点，但不能据此判当前低风险' if sh else
                                      '小区历史匹配待核；先查看同街道背景与候选地点')
            result['site_comparisons'].append(row)
    for c in cases.values():
        anchor = _anchor(c, data['assessment_at'])
        base, _ = _eligible_cases(history, c['disease'], anchor, c.get('historical_case_ids', []))
        hints = exposure_hints(c, [a for a in data['activities'] if a['case_id'] == c['case_id']])
        hints['disease'] = c['disease']
        hints['cutoff_exclusive'] = anchor
        hints['occupation_history'] = _count([x for x in base if x['occupation_group'] == hints['occupation_group']])
        hints['population_history'] = _count([x for x in base if x['population_group'] == hints['population_group']]) if hints['population_group'] != '未知' else None
        result['person_comparisons'].append(hints)
    return result


def catalog(history):
    """Reusable per-disease tables; exact years and original origin counts stay visible."""
    result = {'fingerprint': history['fingerprint'], 'diseases': {}}
    for disease in ('DENV', 'CHIKV'):
        base, excluded = _eligible_cases(history, disease, '9999-12-31')
        groups = {name: defaultdict(list) for name in ('streets', 'sites', 'occupations', 'populations', 'climates')}
        for c in base:
            for street in {s.get('street') for s in c.get('sites', []) if s.get('role') == 'residence' and s.get('street')}:
                groups['streets'][street].append(c)
            for key in {s['comparison_key'] + '|' + (_community(s.get('community')) or '社区未知') for s in c.get('sites', []) if s.get('role') == 'residence' and s.get('name')}:
                groups['sites'][key].append(c)
            groups['occupations'][c['occupation_group']].append(c)
            groups['populations'][c['population_group']].append(c)
            for pid, w in c.get('climate_by_point', {}).items():
                if w.get('bin'):
                    groups['climates'][pid + '|' + w['bin']['key']].append(c)
        result['diseases'][disease] = {'total': _count(base), 'excluded': excluded, 'climate_calendar': history.get('climate_calendar', {}).get(disease, {}),
            **{kind: [{'name': name, **_summary(items, disease, 10 if kind == 'streets' else 3 if kind == 'sites' else None)} for name, items in sorted(g.items(), key=lambda kv: (-_count(kv[1])['local'], kv[0]))] for kind, g in groups.items()}}
    return result


def compare_previous(current, previous):
    rows = []
    for row in current['site_assessments']:
        matches = []
        for old in previous:
            if old.get('assessment_at', '') > current['assessment_at']:
                continue
            for r in old.get('site_assessments', []):
                if r.get('disease') == row['disease'] and site_key(r.get('street'), r.get('site_name')) == site_key(row.get('street'), row['site_name']):
                    if r.get('community') and row.get('community') and _community(r['community']) != _community(row['community']):
                        continue
                    if bool(r.get('community')) != bool(row.get('community')) and not (set(r.get('case_ids', [])) & set(row.get('case_ids', []))):
                        continue
                    matches.append((old, r))
        if not matches:
            continue
        old, prior = max(matches, key=lambda pair: pair[0]['assessment_at'])
        rows.append({'site_id': row['site_id'], 'site_name': row['site_name'], 'disease': row['disease'],
                     'previous_at': old['assessment_at'], 'previous_risk': prior['risk_level'], 'current_risk': row['risk_level'],
                     'previous_priority': prior['priority'], 'current_priority': row['priority'],
                     'previous_fingerprint': old.get('run_fingerprint'), 'source_path': old.get('_snapshot_source_path'),
                     'changed_factors': _previous_changes(current, old, row, prior),
                     'comparison_note': '按同街道同名场所匹配；时间、输入和规则可变，不能据此认定措施因果效果。'})
    return {'status': 'matched' if rows else 'no_matching_previous_result', 'rows': rows}


def collect_previous(root, data, paths=None):
    candidates = []
    if paths is None:
        pointer = Path(root) / 'profiles/history-resource.json'
        if pointer.exists():
            for directory in read_json(pointer).get('previous_result_roots', []):
                directory = Path(directory)
                if directory.is_dir():
                    candidates.extend(directory.rglob('assessment.json'))
    else:
        candidates = [Path(p) for p in paths]
    keys = {site_key(s.get('street'), s['name']) for s in data['sites']}
    previous, records = [], []
    for path in sorted(set(p.resolve() for p in candidates)):
        old = read_json(path)
        if not old.get('assessment_at') or old['assessment_at'] > data['assessment_at']:
            continue
        if not any(site_key(s.get('street'), s.get('site_name')) in keys for s in old.get('site_assessments', [])):
            continue
        old['_snapshot_source_path'] = str(path)
        previous.append(old)
        records.append({'original_path': str(path), 'sha256': file_hash(path), 'source_type': 'previous_assessment'})
    return previous, records


def _eligible_at_T(history, disease, cutoff, exclude_ids=(), *, strict=False):
    """Keep the source snapshot separate from facts actually known at cutoff."""
    base, exclusions = _eligible_cases(history, disease, cutoff, exclude_ids)
    if not strict:
        return base, exclusions
    out = []
    exclusions = Counter(exclusions)
    for original in base:
        known = original.get('case_known_at') or original.get('report_date') or original.get('positive_date')
        if not known or known[:10] >= cutoff:
            exclusions['case_known_at_unavailable_or_later'] += 1
            continue
        c = copy.deepcopy(original)
        c['case_knowledge_time_basis'] = 'explicit_known_at' if original.get('case_known_at') else 'report_or_positive_date_proxy_not_actual_received_timestamp'
        if not original.get('case_known_at'):
            exclusions['case_knowledge_uses_date_proxy'] += 1
        origin_known = c.get('origin_known_at') or c.get('origin_revision_known_at') or c.get('record_observed_at')
        if not origin_known or origin_known[:10] >= cutoff:
            c['origin_source_snapshot'] = c.get('origin')
            c['origin'] = 'unknown'
            c['origin_knowledge_status'] = 'classification_timing_unavailable_at_T'
            exclusions['origin_classification_not_known_at_T'] += 1
        else:
            c['origin_knowledge_status'] = 'source_label_observed_not_readjudicated'
        out.append(c)
    return out, dict(exclusions)


def _current_climate_v2(weather, pid, anchor, history):
    from .history_upgrade import climate_bin_v2, BIN_VERSION
    point = weather.get('weather_archive', {}).get('anchors', {}).get(anchor, {}).get('points', {}).get(pid, {})
    feature = point.get('features', {}).get('14', {})
    meta = point.get('metadata', {})
    histmeta = history.get('weather_metadata', {}).get(pid, {})
    complete = bool(feature.get('complete'))
    reasons = []
    fields = ['provider', 'model', 'source_type', 'grid_latitude', 'grid_longitude', 'timezone', 'units']
    for field in fields:
        if field not in meta or field not in histmeta or meta[field] != histmeta[field]:
            reasons.append('provenance_mismatch:' + field)
    if feature.get('days') != 14 or (feature.get('window_end_exclusive') or feature.get('end_exclusive')) != anchor:
        reasons.append('window_not_same_trailing_14_complete_days')
    t, r = feature.get('temperature_mean_c'), feature.get('precipitation_sum_mm')
    import math
    if not all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in [t, r]):
        complete = False
    if not complete:
        reasons.append('missing_or_incomplete_weather')
    comparable = complete and not reasons
    return {'anchor_date': anchor, 'point_id': pid, 'complete': complete,
        'temperature_mean_14d_c': t if complete else None, 'rainfall_14d_mm': r if complete else None,
        'humidity_mean_14d_pct': feature.get('humidity_mean_pct') if complete else None,
        'window_start': feature.get('window_start'), 'window_end_exclusive': anchor,
        'bin': climate_bin_v2(t, r) if comparable else None, 'bin_version': BIN_VERSION,
        'comparison_kind': 'same_source_model_grid_units_window' if comparable else 'not_comparable',
        'comparison_reasons': reasons, 'provenance': meta,
        'model': meta.get('model'), 'source_type': meta.get('source_type'),
        'climate_role': 'baoan_residence_background_not_imported_acquisition_weather',
        'availability_at_historical_T': 'not_verified_retrospective_reanalysis'}


def _climate_match_v2(cases, climate, pid):
    if not climate.get('bin'):
        return None, {'eligible_case_count': len(cases), 'cases_with_complete_weather': None,
                      'cases_missing_weather': None, 'status': 'current_climate_not_comparable'}
    available = []
    required = ['provider', 'model', 'source_type', 'grid_latitude', 'grid_longitude', 'timezone', 'units']
    for c in cases:
        h = c.get('climate_by_point', {}).get(pid, {})
        provenance = h.get('provenance', {})
        if h.get('complete') and h.get('bin', {}).get('version') == climate['bin_version'] and all(
                provenance.get(k) is not None and provenance[k] == climate['provenance'].get(k) for k in required):
            available.append(c)
    matched = [c for c in available if c['climate_by_point'][pid]['bin']['key'] == climate['bin']['key']]
    return matched, {'eligible_case_count': len(cases), 'cases_with_complete_weather': len(available),
                     'cases_missing_weather': len(cases) - len(available), 'status': 'comparable'}


def _self_exclusions(linked, history, site=None):
    ids = set()
    matches = []
    for c in linked:
        explicit = set(c.get('historical_case_ids', [])) | {c['case_id']}
        linked_ids = [h['id'] for h in history['cases'] if ({h['id']} | set(h.get('aliases', []))) & explicit]
        ids.update(explicit)
        candidates = []
        if not linked_ids and c.get('onset_date'):
            for h in history['cases']:
                if h.get('disease') != c['disease'] or h.get('onset_date') != c['onset_date']:
                    continue
                if site and any(s.get('comparison_key') == site_key(site.get('street'), site.get('name')) for s in h.get('sites', [])):
                    candidates.append(h['id'])
        matches.append({'case_id': c['case_id'], 'status': 'explicitly_excluded' if linked_ids else 'not_verified',
                        'excluded_historical_ids': linked_ids, 'possible_same_onset_place_ids': candidates,
                        'counts_may_include_current_case': bool(candidates),
                        'note': '未核验同人身份不自动合并；候选同日同址需核查并填historical_case_ids' if not linked_ids else '同时识别历史新ID和旧ID别名'})
    return ids, matches


def _comparison_counts(base, matched, street, climate, pid, disease):
    same_street = _place_cases(base, street=street) if street else None
    same_site = _place_cases(base, key=matched['key'], community=matched.get('community_filter')) if matched.get('key') else None
    same_climate, coverage = _climate_match_v2(base, climate, pid)
    same_site_climate, _ = _climate_match_v2(same_site or [], climate, pid)
    return {'district_history': _summary(base, disease),
        'street_history': _summary(same_street, disease, 10) if same_street is not None else None,
        'site_history': _summary(same_site, disease, 3) if same_site is not None else None,
        'same_climate_history': _summary(same_climate, disease) if same_climate is not None else None,
        'site_and_climate_history': _summary(same_site_climate, disease) if same_site is not None and same_site_climate is not None else None,
        'climate_coverage': coverage}


def _occupation_intersections(base, c, site, match, climate, pid):
    raw = c.get('occupation_raw') or c.get('occupation')
    group = occupation_group(raw)
    out = {'case_id': c['case_id'], 'occupation_raw': raw, 'occupation_group': group,
           'actual_exposure_history': None, 'actual_exposure_note': '历史队列未系统记录实际班次、户外时长和防护，不能用职业组代替暴露'}
    for label, selected in [
        ('exact_occupation', [h for h in base if h.get('occupation_raw') == raw] if raw else None),
        ('occupation_group', [h for h in base if h.get('occupation_group') == group] if group not in {'未提供', '未知', '其他或待核岗位'} else None)]:
        if selected is None:
            out[label] = None
            continue
        same_street = _place_cases(selected, street=site.get('street')) if site.get('street') else None
        same_site = _place_cases(selected, key=match.get('key'), community=match.get('community_filter')) if match.get('key') else None
        def climate_count(items):
            if items is None:
                return None
            found, _ = _climate_match_v2(items, climate, pid)
            return _count(found) if found is not None else None
        out[label] = {'history': _count(selected),
            'street_history': _count(same_street) if same_street is not None else None,
            'site_history': _count(same_site) if same_site is not None else None,
            'climate_history': climate_count(selected),
            'street_and_climate_history': climate_count(same_street),
            'site_and_climate_history': climate_count(same_site)}
    return out


def _compare_history_v2(data, weather, history):
    cases = {c['case_id']: c for c in data['cases']}
    cutoff = data['assessment_at'][:10]
    links = defaultdict(set)
    for c in cases.values():
        for link in c.get('site_links', []):
            links[link['site_id']].add(c['case_id'])
    for a in data['activities']:
        links[a['site_id']].add(a['case_id'])
    result = {'status': 'available', 'comparison_version': '2.0', 'history_fingerprint': history['fingerprint'],
        'source_quality': history.get('quality'), 'sources': history.get('sources'),
        'origin_scope_note': '主计数是最终来源标签回顾；严格T可知分类另列known_at_T。CHIKV本地是源表口径，DENV仅明确宝安感染才列本地；省市区候选来源不能互换。',
        'statistics_note': 'CHIKV主表与DENV宝安现住报卡分病种；旧补充队列不累加。无人口和阴性随访分母，数量不是发生率。ERA5为约25公里背景，不能代表小区实测。',
        'cutoff_exclusive': cutoff, 'cutoff_rule': 'assessment_date_start_conservative_unknown_intraday_time',
        'site_comparisons': [], 'person_comparisons': [], 'supplement_note': history.get('supplement_note')}
    for s in data['sites']:
        for disease in sorted({cases[c]['disease'] for c in links[s['site_id']]}):
            linked = [cases[c] for c in sorted(links[s['site_id']]) if cases[c]['disease'] == disease]
            anchors = sorted({_anchor(c, data['assessment_at']) for c in linked})
            anchor = anchors[0]
            exclude_ids, selfmatches = _self_exclusions(linked, history, s)
            base, excluded = _eligible_at_T(history, disease, cutoff, exclude_ids)
            known, known_excluded = _eligible_at_T(history, disease, cutoff, exclude_ids, strict=True)
            matched = _place_match(history, s)
            pid = s.get('weather_point_id') or STREET_POINTS.get(s.get('street'))
            climate = _current_climate_v2(weather, pid, anchor, history)
            climate['anchor_basis'] = '最早病例起病/候选窗口起日；缺失时评估日期'
            row = {'site_id': s['site_id'], 'site_name': s['name'], 'street': s.get('street'), 'disease': disease,
                'cutoff_exclusive': cutoff, 'historical_count_mode': 'retrospective_source_snapshot',
                'excluded': excluded, 'place_match': matched, 'self_exclusion': selfmatches,
                'climate': climate, **_comparison_counts(base, matched, s.get('street'), climate, pid, disease),
                'known_at_T': {'mode': 'strict_knowledge_cutoff', 'excluded': known_excluded,
                    'note': '来源修订/观察时刻不早于T或缺失者归未知；病例登记获知日期缺失时用报告/阳性日期代理，不宣称实际当时接收时刻。气候为事后重建，不是已核验实时可用特征。',
                    **_comparison_counts(known, matched, s.get('street'), climate, pid, disease)}}
            row['known_at_T']['weather_availability_at_T'] = 'unverified_retrospective_reanalysis_not_model_feature'
            row['known_at_T']['same_climate_history'] = None
            row['known_at_T']['site_and_climate_history'] = None
            row['occupational_intersections'] = [_occupation_intersections(base, c, s, matched, climate, pid) for c in linked]
            known_climate = dict(climate, bin=None)
            row['known_at_T']['occupational_intersections'] = [_occupation_intersections(known, c, s, matched, known_climate, pid) for c in linked]
            sh = row['site_history']
            row['historical_hint'] = ('同名候选场所有来源本地记录，优先核验地址、活动关联与当前蚊媒' if sh and sh['local'] else '未匹配本地登记不能判低风险；核实场所、来源和监测覆盖')
            supplement = dict(history, cases=history.get('supplemental_cases', []))
            supp, suppex = _eligible_cases(supplement, disease, cutoff, exclude_ids)
            row['imported_then_local_candidates'] = imported_local_candidates(base, disease, matched)
            other_disease = 'DENV' if disease == 'CHIKV' else 'CHIKV'
            other, _ = _eligible_at_T(history, other_disease, cutoff)
            row['other_disease_environment_context'] = {'disease': other_disease, 'not_combined_with_primary_disease': True,
                **_comparison_counts(other, matched, s.get('street'), climate, pid, other_disease)}
            row['supplemental_history_not_additive'] = {'district_history': _count(supp),
                'street_history': _count(_place_cases(supp, street=s.get('street'))) if s.get('street') else None,
                'excluded': suppex, 'note': history.get('supplement_note')}
            result['site_comparisons'].append(row)
    for c in cases.values():
        ids, matches = _self_exclusions([c], history)
        base, _ = _eligible_at_T(history, c['disease'], cutoff, ids)
        hints = exposure_hints(c, [a for a in data['activities'] if a['case_id'] == c['case_id']])
        raw = c.get('occupation_raw') or c.get('occupation')
        group = occupation_group(raw)
        hints.update(disease=c['disease'], cutoff_exclusive=cutoff, historical_count_mode='retrospective_source_snapshot', self_exclusion=matches)
        hints['occupation_history'] = _count([h for h in base if h['occupation_group'] == group]) if group not in {'未提供', '其他或待核岗位'} else None
        hints['exact_occupation_history'] = _count([h for h in base if h.get('occupation_raw') == raw]) if raw else None
        hints['population_history'] = _count([h for h in base if h['population_group'] == hints['population_group']]) if hints['population_group'] != '未知' else None
        result['person_comparisons'].append(hints)
    return result


def imported_local_candidates(cases, disease, matched=None):
    """Connected candidate pairs are not confirmed outbreaks or causal chains."""
    candidates = []
    input_cases = [c for c in cases if c.get('origin') == 'imported' and c.get('onset_date')]
    local_cases = [c for c in cases if c.get('onset_date') and (c.get('origin') == 'local' or
        (c.get('origin') == 'unknown' and '本地' in str(c.get('origin_label', ''))))]
    selected_key = (matched or {}).get('key')
    if matched is not None and not selected_key:
        return {'status': 'place_unmatched', 'candidate_pairs': None, 'candidate_episode_groups': None,
                'confirmed_transmission_events': None, 'confirmed_secondary_cases': None}
    def keys(c):
        return {(s.get('comparison_key'), _community(s.get('community'))) for s in c.get('sites', [])
            if s.get('role') == 'residence' and s.get('name') and s.get('comparison_key') and
            (selected_key is None or s['comparison_key'] == selected_key) and
            (not (matched or {}).get('community_filter') or _community(s.get('community')) == matched['community_filter'])}
    for a in input_cases:
        for b in local_cases:
            delta = (day(b['onset_date']) - day(a['onset_date'])).days
            if a['id'] == b['id'] or not 1 <= delta <= 56:
                continue
            for key, community in sorted(keys(a) & keys(b)):
                candidates.append({'imported_case_id': a['id'], 'later_local_label_case_id': b['id'],
                    'site_candidate_key': key, 'community': community or None,
                    'onset_gap_days': delta, 'later_local_label_scope': 'source_baoan_local' if b.get('origin') == 'local' else 'local_label_scope_unresolved',
                    'actual_infectious_presence_verified': False, 'evidence_level': 'onset_order_same_candidate_residence_only'})
    def groups(pairs):
        components = []
        for pair in pairs:
            scope = (pair['site_candidate_key'], pair['community'])
            ids = {pair['imported_case_id'], pair['later_local_label_case_id']}
            touched = [g for g in components if g['scope'] == scope and g['ids'] & ids]
            if not touched:
                components.append({'scope': scope, 'ids': ids, 'pairs': [pair]})
            else:
                first = touched[0]
                first['ids'].update(ids); first['pairs'].append(pair)
                for other in touched[1:]:
                    first['ids'].update(other['ids']); first['pairs'].extend(other['pairs']); components.remove(other)
        return [{'site_candidate_key': g['scope'][0], 'community': g['scope'][1],
                 'case_ids': sorted(g['ids']), 'pair_count': len(g['pairs']),
                 'candidate_family_id': 'candidate-' + digest([disease, g['scope'], sorted(g['ids'])])[:16]}
                for g in components]
    by_horizon = {}
    for days in (28, 42, 56):
        pairs = [p for p in candidates if p['onset_gap_days'] <= days]
        gg = groups(pairs)
        by_horizon[str(days)] = {'candidate_pair_count': len(pairs), 'candidate_episode_group_count': len(gg), 'groups': gg}
    return {'status': 'descriptive_candidate_search', 'disease': disease, 'candidate_pairs': candidates,
        'candidate_episode_groups': by_horizon, 'confirmed_transmission_events': None, 'confirmed_secondary_cases': None,
        'note': '同名候选居住地的起病先后线索；未核验输入感染性在位、感染地点或共同暴露。配对数不等于事件数；零匹配不是无本地传播。'}


def _previous_changes(current, previous, row, prior):
    keys = ('engine_version', 'rule_version', 'history_fingerprint', 'model_version')
    differences = {key: {'previous': previous.get(key), 'current': current.get(key)}
        for key in keys if previous.get(key) != current.get(key)}
    for key in ('case_ids', 'weather_point_id', 'evidence_gaps', 'origin_branch', 'risk_score', 'priority', 'risk_level'):
        if prior.get(key) != row.get(key):
            differences[key] = {'previous': prior.get(key), 'current': row.get(key)}
    old_history = previous.get('historical_comparison', {})
    new_history = current.get('historical_comparison', {})
    if old_history.get('history_fingerprint') != new_history.get('history_fingerprint'):
        differences['historical_resource'] = {'previous': old_history.get('history_fingerprint'), 'current': new_history.get('history_fingerprint')}
    def model_for(result, site):
        return next((r for r in result.get('risk_model_assessment', {}).get('rows', [])
                     if r['site_id'] == site['site_id'] and r['disease'] == site['disease']), {})
    old_model, new_model = model_for(previous, prior), model_for(current, row)
    for key in ('branch', 'score_1_to_10', 'score_status', 'model_version', 'probability'):
        if old_model.get(key) != new_model.get(key):
            differences['model_' + key] = {'previous': old_model.get(key), 'current': new_model.get(key)}
    for key in ('missing', 'weather_quality', 'weather_features', 'observations', 'interventions'):
        if prior.get(key) != row.get(key):
            differences[key] = {'previous': prior.get(key), 'current': row.get(key)}
    return differences
