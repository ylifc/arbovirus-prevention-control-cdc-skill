"""Strict local data contracts; unknowns remain unknown, never imputed facts."""
from __future__ import annotations

import copy
from .common import ValidationError, day, instant, finite, required_string

COLLECTIONS = ("cases", "sites", "activities", "households", "observations", "interventions", "prior_risks")
IDS = {"cases": "case_id", "sites": "site_id", "activities": "event_id", "households": "household_id", "observations": "observation_id", "interventions": "intervention_id", "prior_risks": "risk_id"}
LEVELS = ("待评估", "低", "关注", "高", "很高")


def validate_input(data, profile, rules):
    if not isinstance(data, dict):
        raise ValidationError("输入必须为JSON对象")
    allowed = {"schema_version", "profile_id", "assessment_at", "source_documents", "notes", *COLLECTIONS}
    unknown = set(data) - allowed
    if unknown:
        raise ValidationError(f"未知顶层字段（避免静默忽略）: {sorted(unknown)}")
    if data.get("schema_version") != "1.0" or data.get("profile_id") != profile["profile_id"]:
        raise ValidationError("schema_version或profile_id不匹配")
    as_of = instant(data.get("assessment_at"), "assessment_at")
    if as_of.date() < day(rules["effective_from"]) or as_of.date() > day(rules["review_due"]):
        raise ValidationError("判定日期不在当前规范核验有效窗口内，请在维护阶段核验适用版本；不得自动回退")
    result = copy.deepcopy(data)
    result["assessment_at"] = as_of.isoformat()
    warnings = []
    lookups = {}
    for name in COLLECTIONS:
        items = result.setdefault(name, [])
        if not isinstance(items, list):
            raise ValidationError(f"{name}必须为数组")
        lookup = {}
        cleaned = []
        for item in items:
            if not isinstance(item, dict):
                raise ValidationError(f"{name}条目必须为对象")
            key = required_string(item, IDS[name], name)
            if item.get('known_at') and instant(item['known_at']) > as_of:
                raise ValidationError(f'{key}含判定时点之后才获知的信息')
            if key in lookup:
                if item == lookup[key]:
                    warnings.append(f"{name}重复相同记录已去重: {key}")
                    continue
                raise ValidationError(f"{name}相同ID存在冲突: {key}")
            lookup[key] = item
            cleaned.append(item)
        result[name] = cleaned
        lookups[name] = lookup
    if not result["sites"]:
        raise ValidationError("至少提供一个待调查场所，不能凭空生成地点")
    points = {p["point_id"] for p in profile["weather_points"]}
    case_events = [c['case_event_id'] for c in result['cases'] if c.get('case_event_id')]
    if len(case_events) != len(set(case_events)):
        raise ValidationError('同一case_event_id出现多个版本；先按T核验有效修订，不可重复计数')
    for site in result["sites"]:
        sid = site["site_id"]
        required_string(site, "name", sid)
        if site.get("location_status", "unresolved") not in {"verified", "ambiguous", "unresolved"}:
            raise ValidationError(f"{sid}位置状态无效")
        street = site.get("street")
        if street is not None and street not in profile["streets"]:
            raise ValidationError(f"{sid}街道不属于宝安画像；跨区点需独立地区配置")
        if site.get("weather_point_id") is not None and site["weather_point_id"] not in points:
            raise ValidationError(f"{sid}天气点未注册")
        coord = site.get("coordinates")
        if coord is not None:
            if not isinstance(coord, dict):
                raise ValidationError(f"{sid}.coordinates必须为对象或null")
            lat, lon = coord.get("latitude"), coord.get("longitude")
            if not finite(lat) or not finite(lon) or not -90 <= lat <= 90 or not -180 <= lon <= 180:
                raise ValidationError(f"{sid}坐标无效")
            if coord.get("crs") not in {"WGS84", "GCJ-02", "BD-09"}:
                raise ValidationError(f"{sid}坐标系缺失或不支持")
            if site.get("location_status") == "verified" and not coord.get("source_ref"):
                raise ValidationError(f"{sid}已核验坐标需要source_ref")
        if site.get("location_status") != "verified":
            warnings.append(f"场所待消歧或核验: {sid}")
        surveillance = site.get("surveillance")
        if surveillance is not None:
            if not isinstance(surveillance, dict) or (surveillance.get("adequate") is not None and not isinstance(surveillance["adequate"], bool)):
                raise ValidationError(f"{sid}调查覆盖审核结构无效")
            if surveillance.get("assessed_at") and instant(surveillance["assessed_at"]) > as_of:
                raise ValidationError(f"{sid}调查覆盖审核晚于判定时刻")
    for case in result["cases"]:
        cid = case["case_id"]
        if case.get("age") is not None and (not finite(case["age"]) or not 0 <= case["age"] <= 120):
            raise ValidationError(f"{cid}.age须为0至120岁数值或null")
        if 'historical_case_ids' in case and (not isinstance(case['historical_case_ids'], list) or not all(isinstance(v, str) and v for v in case['historical_case_ids'])):
            raise ValidationError(f"{cid}.historical_case_ids须为非空字符串组成的数组")
        if case.get("disease") not in rules["diseases"]:
            raise ValidationError(f"{cid}病种未支持，禁止跨病种套用参数")
        if case.get("status") not in {"confirmed", "suspected", "unknown"}:
            raise ValidationError(f"{cid}病例状态无效")
        if case.get("origin", "unknown") not in {"local", "imported", "unknown"}:
            raise ValidationError(f"{cid}感染来源无效")
        if case.get('origin_scope') not in {None, 'baoan', 'shenzhen', 'guangdong', 'unknown'}:
            raise ValidationError(f'{cid}来源地理层级无效')
        for flag in ('diagnostic_conflict', 'origin_conflict'):
            if flag in case and not isinstance(case[flag], bool):
                raise ValidationError(f'{cid}.{flag}必须是布尔值')
        if case.get('origin_known_at') and instant(case['origin_known_at']) > as_of:
            raise ValidationError(f'{cid}来源订正晚于判定时点')
        if 'origins' in case:
            if not isinstance(case['origins'], dict) or set(case['origins']) - {'baoan', 'shenzhen', 'guangdong'}:
                raise ValidationError(f'{cid}.origins须按baoan/shenzhen/guangdong分层')
            for scope, origin in case['origins'].items():
                if not isinstance(origin, dict) or origin.get('classification') not in {'local', 'imported', 'unknown', 'conflict'}:
                    raise ValidationError(f'{cid}.{scope}来源分类无效')
                if origin.get('known_at') and instant(origin['known_at']) > as_of:
                    raise ValidationError(f'{cid}.{scope}来源订正晚于判定时点')
                if origin.get('reviewed') is not None and not isinstance(origin['reviewed'], bool):
                    raise ValidationError(f'{cid}.{scope}.reviewed必须为布尔值')
                if origin.get('reviewed') and not (origin.get('known_at') and origin.get('evidence_ref')):
                    raise ValidationError(f'{cid}.{scope}已核验来源须有known_at及evidence_ref')
        if case.get('diagnostic_conflict'):
            warnings.append(f'{cid}存在诊断矛盾，暂停计入严格确诊统计，保留调查优先级')
        if case.get('origin') != 'unknown' and not case.get('origin_scope') and not case.get('origins'):
            warnings.append(f'{cid}旧来源字段缺地理层级；按来源待核，不进入宝安本地确诊计数，保留病例处置优先级')
        if case.get("status") == "confirmed" and not case.get("confirmation_ref"):
            warnings.append(f"{cid}确诊缺证据引用，不计入规范确诊计数")
        for key in ("onset_date", "report_date"):
            if case.get(key) is not None and day(case[key], f"{cid}.{key}") > as_of.date():
                raise ValidationError(f"{cid}.{key}晚于判定日期")
        if case.get("known_at") and instant(case["known_at"], f"{cid}.known_at") > as_of:
            raise ValidationError(f"{cid}含判定时点之后才获知的信息")
        if case.get("household_id") is not None and case["household_id"] not in lookups["households"]:
            raise ValidationError(f"{cid}家庭ID不存在")
        links = case.get("site_links", [])
        if not isinstance(links, list):
            raise ValidationError(f"{cid}.site_links必须为数组")
        for link in links:
            if not isinstance(link, dict) or link.get("site_id") not in lookups["sites"]:
                raise ValidationError(f"{cid}关联场所不存在")
            if link.get("role") not in {"residence", "work", "other", "source_investigation"}:
                raise ValidationError(f"{cid}场所关联role无效")
            if link.get("aggregation_eligible") is not None and not isinstance(link["aggregation_eligible"], bool):
                raise ValidationError(f"{cid}聚集计数资格必须为true/false/null")
            if link.get("aggregation_eligible") is True and not link.get("evidence_ref"):
                raise ValidationError(f"{cid}聚集场所关联需要证据引用")
            if link.get('known_at') and instant(link['known_at']) > as_of:
                raise ValidationError(f'{cid}场所关联晚于判定时点才获知')
        window = case.get("infectious_window")
        if window:
            if window.get('known_at') and instant(window['known_at']) > as_of:
                raise ValidationError(f'{cid}感染性窗口晚于判定时点才获知')
            start, end = instant(window.get("start")), instant(window.get("end"))
            if start > end or window.get("status") not in {"reviewed", "candidate"} or not window.get("evidence_ref"):
                raise ValidationError(f"{cid}个体时间窗无效或缺证据")
    for activity in result["activities"]:
        eid = activity["event_id"]
        if activity.get("case_id") not in lookups["cases"] or activity.get("site_id") not in lookups["sites"]:
            raise ValidationError(f"{eid}病例或地点引用不存在")
        if activity.get("event_type") not in {"infectious_activity", "source_investigation", "unclassified_activity"}:
            raise ValidationError(f"{eid}活动类型无效")
        for key in ("start", "end"):
            if activity.get(key) is not None and instant(activity[key], f"{eid}.{key}") > as_of:
                raise ValidationError(f"{eid}.{key}晚于判定时刻")
        if activity.get("start") and activity.get("end"):
            start, end = instant(activity["start"]), instant(activity["end"])
            if start >= end or end > as_of:
                raise ValidationError(f"{eid}活动时段必须为正长度且不晚于判定时刻")
        else:
            warnings.append(f"{eid}活动时间不完整，不能声称精确时段")
        if activity.get("mosquito_exposure") not in {"yes", "no", "unknown", None}:
            raise ValidationError(f"{eid}mosquito_exposure无效")
        if activity.get('protection_status') not in {None, 'protected', 'unprotected', 'unknown'}:
            raise ValidationError(f'{eid}.protection_status无效')
        if not activity.get("evidence_ref"):
            warnings.append(f"{eid}缺活动证据引用")
    for household in result["households"]:
        size = household.get("member_count")
        if size is not None and (not isinstance(size, int) or isinstance(size, bool) or size < 1):
            raise ValidationError("同住人数必须为正整数或null")
        for key in ("age_groups", "care_needs", "symptom_notes"):
            if key in household and not isinstance(household[key], list):
                raise ValidationError(f"家庭{key}必须为数组")
    for obs in result["observations"]:
        oid = obs["observation_id"]
        if obs.get("site_id") not in lookups["sites"]:
            raise ValidationError(f"{oid}场所不存在")
        if instant(obs.get("observed_at"), oid) > as_of:
            raise ValidationError(f"{oid}观测来自未来")
        if obs.get("kind") not in {"vector", "environment"}:
            raise ValidationError(f"{oid}观测类型无效")
        if obs["kind"] == "environment":
            if obs.get("standing_water") not in {"yes", "no", "unknown", None}:
                raise ValidationError(f"{oid}积水状态无效")
        else:
            if obs.get("metric") not in {"BI", "MOI", "double_net_adults", "other"}:
                raise ValidationError(f"{oid}媒介指标无效")
            if obs.get("value") is not None and (not finite(obs["value"]) or obs["value"] < 0):
                raise ValidationError(f"{oid}媒介数值无效")
            if obs.get("metric") == "MOI" and obs.get("value") is not None and obs["value"] > 100:
                raise ValidationError(f"{oid}MOI不能超过100%")
        if not obs.get("evidence_ref"):
            warnings.append(f"{oid}缺原始调查证据引用")
    for action in result["interventions"]:
        if action.get("site_id") not in lookups["sites"]:
            raise ValidationError("处置记录地点不存在")
        if instant(action.get("performed_at")) > as_of:
            raise ValidationError("处置记录晚于判定时刻")
    for prior in result["prior_risks"]:
        if prior.get("site_id") not in lookups["sites"] or prior.get("disease") not in rules["diseases"]:
            raise ValidationError("既往风险记录的场所或病种无效")
        if prior.get("risk_level") not in LEVELS or prior.get("priority") not in {"P0", "P1", "P2", "P3"}:
            raise ValidationError("既往风险等级或优先级无效")
        if prior.get("status") not in {"open", "under_review", "in_progress", "closed"}:
            raise ValidationError("既往风险状态无效")
        if not prior.get("evidence_ref"):
            raise ValidationError("既往风险需要证据引用")
        if prior.get("status") == "closed" and not prior.get("closure_review_ref"):
            raise ValidationError("已关闭风险需要专业复核依据")
    result.setdefault("source_documents", [])
    if not isinstance(result["source_documents"], list):
        raise ValidationError("source_documents必须为数组")
    return result, warnings
