from __future__ import annotations

import csv
import html
import json
from pathlib import Path
from .common import write_json


def safe_csv(value):
    value = json.dumps(value, ensure_ascii=False, sort_keys=True) if isinstance(value, (dict, list)) else "" if value is None else str(value)
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else value


def write_outputs(out, assessment, data, weather):
    out = Path(out)
    write_json(out / "assessment.json", assessment)
    write_json(out / "risk_register.json", assessment["risk_register"])
    from .history_report import write_history_outputs, render_history
    history = assessment.get('historical_comparison', {})
    previous = assessment.get('previous_result_comparison', {})
    scientific = assessment.get('risk_model_assessment', {})
    write_json(out / 'risk_model_assessment.json', scientific)
    write_json(out / 'weather_archive.json', weather.get('weather_archive', {}))
    write_history_outputs(out, history, previous)
    write_json(out / "weather_quality.json", {"as_of": weather.get("as_of"), "provider_status": weather.get("provider_status"), "errors": weather.get("errors", []), "points": {k: {"metadata": {x: y for x, y in v.get("metadata", {}).items() if x not in {"raw_response"}}, "quality": v.get("quality"), "features": v.get("features")} for k, v in weather.get("points", {}).items()}})
    columns = ["risk_id", "version", "site_id", "site_name", "street", "disease", "event_type", "start", "end", "assessment_at", "risk_level", "priority", "confidence", "official_event_candidate", "official_response_level", "case_ids", "rule_ids", "reasons", "missing", "tasks", "status", "review_due_at", "closure"]
    with (out / "risk_register.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, columns)
        writer.writeheader()
        writer.writerows({k: safe_csv(row.get(k)) for k in columns} for row in assessment["risk_register"])
    for name in ("hourly", "daily"):
        rows = [{"point_id": key, **row} for key, point in weather.get("points", {}).items() for row in point.get(name, [])]
        fields = sorted({field for row in rows for field in row}) or ["point_id", "status"]
        with (out / f"weather_{name}.csv").open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fields); writer.writeheader()
            writer.writerows({k: safe_csv(row.get(k)) for k in fields} for row in rows)
    features = []
    map_warnings = []
    for site in data["sites"]:
        coord = site.get("coordinates")
        if not coord or coord.get("crs") != "WGS84" or site.get("location_status") != "verified":
            map_warnings.append(f'{site["site_id"]}: 未核验WGS84坐标，不绘图')
            continue
        features.append({"type": "Feature", "geometry": {"type": "Point", "coordinates": [coord["longitude"], coord["latitude"]]}, "properties": {"site_id": site["site_id"], "name": site["name"], "purpose": "内部调查点，非正式风险区边界"}})
    write_json(out / "sites.geojson", {"type": "FeatureCollection", "features": features, "warnings": map_warnings})
    escape = lambda x: html.escape(str(x))
    parts = ['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>宝安蚊媒风险研判</title><style>body{font:16px/1.7 system-ui,sans-serif;max-width:1100px;margin:2em auto;padding:0 1em;color:#18252c}h1,h2{line-height:1.35}table{border-collapse:collapse;width:100%;margin:1em 0}th,td{border:1px solid #cfd9df;text-align:left;padding:.6em;vertical-align:top}th{background:#edf2f6}code{overflow-wrap:anywhere}.muted{color:#536674}li{margin:.4em 0}</style>',
             '<h1>宝安区蚊媒传播风险与处置建议</h1>',
             f'<p>判定时点：{escape(assessment["assessment_at"])}。本报告为专业复核建议，未发布官方响应或确诊传播链。</p>',
             '<p>内部资料：含匿名病例关联及场所信息，请按授权范围使用。风险档位与工作优先级尚未经过预测校准；天气不代表媒介密度。</p>',
             f'<p>气象接入状态：{escape(assessment.get("weather_provider_status"))}</p>',
             '<h2>风险对象、来源与评分依据</h2><table><tr><th>场所／病种</th><th>来源分支与风险对象</th><th>1—10档／概率</th><th>评分状态与处置</th></tr>']
    for row in scientific.get('rows', []):
        values = [f"{row['site_name']}／{row['disease']}", f"{row['branch']}；{row['risk_target']}",
                  '暂不能校准：分数、概率均未知' if row['score_1_to_10'] is None else f"{row['score_1_to_10']}／{row['probability']}",
                  f"{row['evidence_rule_risk']}／{row['action_priority']}；" + '；'.join(row['blocking_reasons'])]
        parts.append('<tr>' + ''.join(f'<td>{escape(v)}</td>' for v in values) + '</tr>')
    parts.extend(['</table>', '<p>分数只由经验证的校准概率映射：min(10,1+floor(10×p))。历史登记数量和职业标签不直接加分。输入来源不自动代表低风险。</p>',
                  '<table><thead><tr><th>场所</th><th>病种</th><th>风险与优先级</th><th>规范分类候选</th><th>关键缺项</th></tr></thead><tbody>'])
    for row in assessment["site_assessments"]:
        parts.append('<tr>' + ''.join(f'<td>{escape(value)}</td>' for value in [row["site_name"], row["disease"], f'{row["risk_level"]} / {row["priority"]}', row["official_event_candidate"], '；'.join(row["missing"])]) + '</tr>')
    parts.append('</tbody></table>')
    parts.append(render_history(history, previous))
    if history.get('comparison_version') == '2.0':
        parts.append('<h2>历史对照的时间与来源约束</h2><p>最终表标签仅供回顾解释；严格当时可知数量另列，来源修订时刻不明不能作为当时已知本地病例。主队列与旧库补充不相加。</p>')
    parts.append('<h2>在位时间与传播事件证据</h2>')
    for row in scientific.get('rows', []):
        ev = row['episode_evidence']
        parts.append(f"<details><summary>{escape(row['site_name'])}／{escape(row['disease'])}：候选感染性在位时间与缺项</summary><pre style='white-space:pre-wrap'>{escape(json.dumps(ev, ensure_ascii=False, indent=2))}</pre></details>")
    for row in assessment["site_assessments"]:
        parts.extend([f'<h2>{escape(row["site_name"])} {escape(row["disease"])}</h2>', '<ul>'])
        for reason in row["reasons"]: parts.append(f'<li>{escape(reason)}</li>')
        parts.append('</ul><p>规则：' + escape('、'.join(row["rule_ids"])) + '</p>')
        for task in row["tasks"]:
            parts.append(f'<p>{escape(task["action"])}；责任角色：{escape(task["owner_role"])}；时间：{escape(task["deadline"])}（{escape(task["deadline_basis"])}）。</p>')
        if row["care_needs"]: parts.append('<p>家庭照护需求：' + escape('、'.join(row["care_needs"])) + '。此信息不用于增加传染性分值。</p>')
    parts.append('<h2>具体活动时段</h2><table><tr><th>场所</th><th>时段</th><th>事件类型</th><th>活动线索</th></tr>')
    for row in assessment["risk_register"]:
        if row["event_type"] == "site_assessment": continue
        parts.append('<tr>' + ''.join(f'<td>{escape(value)}</td>' for value in [row["site_name"], f'{row.get("start") or "未知"} — {row.get("end") or "未知"}', row["event_type"], f'{row["risk_level"]}；{row["window_relation"]}']) + '</tr>')
    parts.extend(['</table>', '<h2>气象覆盖</h2>'])
    for pid, point in weather.get("points", {}).items():
        parts.append(f'<h3>{escape(pid)}</h3><p>{escape(point.get("metadata", {}).get("source_type"))}；{escape(point.get("metadata", {}).get("spatial_resolution"))}</p>')
        parts.append('<pre style="white-space:pre-wrap">' + escape(json.dumps(point.get("quality", {}), ensure_ascii=False, indent=2)) + '</pre>')
    archive = weather.get('weather_archive', {})
    if archive:
        parts.append('<p>历史对照单独保留起病／评估日前84日ERA5序列及7、14、28、56、84日完整性；近期模型与再分析数据不拼接。详细来源及缺测见 weather_archive.json。</p>')
    if assessment["input_warnings"]: parts.append('<h2>输入核查项</h2><p>' + escape('；'.join(assessment["input_warnings"])) + '</p>')
    if assessment["weather_errors"]: parts.append('<h2>气象接入错误</h2><pre style="white-space:pre-wrap">' + escape(json.dumps(assessment["weather_errors"], ensure_ascii=False, indent=2)) + '</pre>')
    parts.append('<p class="muted">同一次冻结锁产生相同结构化结果。规范解除须结合连续观察、媒介监测与专业复核；不能按14日天气窗口自动关闭。</p></html>')
    (out / "report.html").write_text('\n'.join(parts), encoding="utf-8")
