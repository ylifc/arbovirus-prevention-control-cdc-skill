from __future__ import annotations

import hashlib
import json
import math
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Asia/Shanghai")


class ValidationError(ValueError):
    pass


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for part in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def read_json(path):
    path = Path(path)
    if not path.is_file():
        raise ValidationError(f"本地文件不存在: {path}")
    if path.stat().st_size > 100 * 1024 * 1024:
        raise ValidationError("JSON输入超过100 MiB上限")
    def reject_constant(value):
        raise ValidationError(f"JSON不允许非有限数: {value}")
    def unique_keys(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ValidationError(f"JSON重复键: {key}")
            out[key] = value
        return out
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"), parse_constant=reject_constant, object_pairs_hook=unique_keys)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ValidationError(f"JSON格式或编码错误: {exc}") from exc


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def instant(value, field="时间"):
    if not isinstance(value, str):
        raise ValidationError(f"{field}必须为带时区ISO时间")
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValidationError(f"{field}不是有效ISO时间: {value}") from exc
    if result.tzinfo is None:
        raise ValidationError(f"{field}缺少时区: {value}")
    return result.astimezone(TZ)


def day(value, field="日期"):
    try:
        if not isinstance(value, str) or len(value) != 10:
            raise ValueError()
        return date.fromisoformat(value)
    except ValueError as exc:
        raise ValidationError(f"{field}必须为YYYY-MM-DD: {value}") from exc


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def required_string(obj, key, context):
    value = obj.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValidationError(f"{context}.{key}不能为空")
    return value
