"""Descriptive frequency of complete 14-day climate windows.

An anchor day is a weather-reference day, not a disease-free control or a
person at risk. Adjacent windows overlap, so these counts are not independent
observations and cannot by themselves estimate incidence or causal risk.
"""
from __future__ import annotations

from datetime import timedelta

from .history_weather import _date, climate_bin, validate_history_weather, window_features


def climate_baseline(weather, start_date, end_date, point_id):
    """Count descriptive climate bins over inclusive anchor-date bounds.

    ``weather`` uses the historical_daily_weather schema, including explicit
    daily temperature_mean_c and precipitation_sum_mm. Both variables and
    their provenance must be usable for all 14 preceding natural days.
    Every bin is reported even when its count is zero; incomplete windows are
    counted separately and never assigned to a bin.
    """
    start, end = _date(start_date), _date(end_date)
    if end < start:
        raise ValueError("climate baseline anchor date range reversed")
    normalized = validate_history_weather(weather)
    if point_id not in normalized["points"]:
        raise ValueError("climate baseline requires a known weather point")
    entry = normalized["points"][point_id]
    metadata = entry["metadata"]
    bins = {}
    # These representative values enumerate the bins; their definitions live
    # in climate_bin, shared with the case-window comparison implementation.
    for temperature in (15, 22, 26, 30, 35):
        for rainfall in (0, 0.5, 5, 20, 75, 150):
            definition = climate_bin(temperature, rainfall)
            bins[definition["key"]] = {"bin": definition, "anchor_days": 0,
                                       "fraction_of_complete_days": None}
    expected = (end - start).days + 1
    missing = []
    for index in range(expected):
        anchor = start + timedelta(days=index)
        features = window_features(normalized, point_id, anchor)
        if not features["complete"]:
            missing.append(anchor.isoformat())
            continue
        definition = climate_bin(features["temperature_mean_14d_c"], features["rainfall_14d_mm"])
        if definition is None:
            missing.append(anchor.isoformat())
            continue
        bins[definition["key"]]["anchor_days"] += 1
    complete = expected - len(missing)
    if complete:
        for item in bins.values():
            item["fraction_of_complete_days"] = round(item["anchor_days"] / complete, 6)
    return {
        "schema_version": "1.0", "kind": "descriptive_climate_day_baseline",
        "point_id": point_id, "anchor_start_date": start.isoformat(),
        "anchor_end_date_inclusive": end.isoformat(), "timezone": "Asia/Shanghai",
        "window_rule": "每个anchor前14个完整自然日；anchor当天不计入；缺测不补0",
        "anchor_days_total": expected, "complete_anchor_days": complete,
        "incomplete_anchor_days": len(missing), "incomplete_anchor_dates": missing,
        "bins": bins, "definition_version": "descriptive-14d-bins-v1",
        "source_type": metadata.get("source_type"), "model": metadata.get("model"),
        "source_ref": metadata.get("source_ref"),
        "spatial_resolution": metadata.get("spatial_resolution"),
        "interpretation": "描述性气候出现日数；日期范围内包含有病例和无病例日期，不能称为无病例对照。不是人群暴露分母或发病率；连续14日窗口互相重叠。",
    }
