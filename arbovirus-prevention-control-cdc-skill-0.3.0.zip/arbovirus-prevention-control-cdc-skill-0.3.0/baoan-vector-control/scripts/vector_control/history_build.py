"""Build a new immutable local historical resource during explicit maintenance.

No production planner, source discovery, network acquisition, global registration
switch, or original workbook copying occurs here. READY is written last.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import os
from pathlib import Path

from .common import TZ, ValidationError, file_hash, read_json
from .history import catalog, compile_history, validate_history
from .history_import import build_registry
from .history_weather import validate_history_weather


def _safe_write(path, value):
    """Private permissions apply before contents are written, even with loose umask."""
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n")


def _safe_text(path, value):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        handle.write(value)


def _cell(value):
    return str(value if value is not None else "未知").replace("|", "／").replace("\n", " ")


def _table(rows, *, places=False, climate=False):
    lines = (["| 气候箱 | 资料日期范围内该气候天数 | 登记病例 | 宝安本地分类 | 输入分类 | 未明或冲突 |",
              "| --- | ---: | ---: | ---: | ---: | ---: |"] if climate else
             ["| 类别 | 登记病例 | 宝安本地分类 | 输入分类 | 未明或冲突 | 记录日期范围 |",
              "| --- | ---: | ---: | ---: | ---: | --- |"])
    for row in rows:
        label = row["name"]
        if places:
            label = label.replace("|", " / ")
        dates = f"{row.get('first_date') or '未知'} 至 {row.get('last_date') or '未知'}"
        values = ([label, row.get("anchor_days"), row["registered_cases"], row["local"], row["imported"], row["unknown_or_conflict"]]
                  if climate else [label, row["registered_cases"], row["local"], row["imported"], row["unknown_or_conflict"], dates])
        lines.append("| " + " | ".join(_cell(v) for v in values) + " |")
    if not rows:
        lines.append("| 无可用登记记录 | 0 | 0 | 0 | 0 | 未知 |")
    return "\n".join(lines)


def _climate_labels(history):
    labels = {}
    for case in history["cases"]:
        for point, features in case.get("climate_by_point", {}).items():
            if features.get("bin"):
                labels[point + "|" + features["bin"]["key"]] = features["bin"]["label"]
    return labels


def _render_summary(history, tables, created_at):
    quality = history["quality"]
    coverage = history.get("coverage", {})
    lines = [
        "# 宝安区历史病例与气候对照汇总",
        "",
        f"构建时间：{created_at}。本资源用于新流调的历史对照与调查优先级提示。",
        "",
        "## 开始使用前的计数口径",
        "",
        f"本次明确输入的 {len(history.get('sources', []))} 份工作簿合计纳入 {quality['raw_case_records']} 条可用病例记录，"
        f"严格合并 {quality['merged_duplicate_records']} 条重复记录后保留 {quality['deduplicated_cases']} 个病例事件。"
        f"起病日期覆盖 {coverage.get('onset_start') or '未知'} 至 {coverage.get('onset_end') or '未知'}。"
        "来源年份以manifest和每例日期字段为准，不能将历史累计解释为当前年度疫情。",
        "",
        f"另有 {quality.get('possible_same_name_duplicate_groups_unmerged', 0)} 组、"
        f"{quality.get('possible_same_name_records_unmerged', 0)} 个同名记录未达到严格归并证据条件，仍保持分开。"
        "因此以下为保守去重后的登记病例计数，可能存在残余重复，不能声称已取得完全去重的真实感染总人数。",
        "",
        f"{quality.get('missing_onset', 0)} 个病例事件缺少精确起病日，"
        f"{quality.get('year_imputed_onset', 0)} 个使用来源明确年份补足月日并保留标志。"
        "统计表排除核销、未确认病例以及起病日、报卡日、阳性日期均缺失的事件；存在报卡日或阳性日期而起病日缺失者可进入地点/职业统计，不能进入起病前14天气候对照。",
        "",
        "**未提供官方暴发事件编号、核验成员或完整事件清单，暴发次数及暴发病例数均为未知。**"
        "同地点多例或滚动窗口仅是描述性线索，不能替代暴发认定。",
        "",
        "本地、输入和未明分类保留原表宝安属地判断及来源冲突，不能直接转换为国家方案的省际输入/本地口径。"
        "居住地代表病例关联地点，不证明该小区就是感染地。",
        "",
        "街道和小区表按居住关联去重；同一病例如有多处居住地点，可分别关联各地点，行数不能简单求和。"
        "工作及活动涉病例保留在病例库，并与居民地点角色分开。职业与年龄表包含本次可用病例范围，不能与仅居民地点表强求一致。",
        "",
        "**没有职业人口、小区人口或完整事件监测分母；以下数字不是发病率、相对风险或感染概率。**"
        "气候出现天数是资料日期范围内的天气描述，日期可能有病例也可能无病例，不能作为人群风险分母。"
        "表中记录较多的类别是优先复核历史线索，不能直接宣告当前风险高；无记录也不代表无风险。",
        "",
        "## 数据质量与原始记录",
        "",
        "| 项目 | 数量或状态 |",
        "| --- | ---: |",
    ]
    for key, value in sorted(quality.get("by_disease_status", {}).items()):
        lines.append(f"| {_cell(key)} | {value} |")
    for key, value in sorted(quality.get("excluded_rows", {}).items()):
        label = {"name_only_tracking_row": "仅姓名追踪行，未计入病例", "no_case_identity": "无病例基本信息行，未计入病例",
                 "unresolved_administrative_copy": "未能归并的行政副本，未新增计数"}.get(key, key)
        lines.append(f"| {_cell(label)} | {value} |")
    lines += [f"| 来源分类冲突 | {quality.get('conflicting_origins', 0)} |", "| 正式暴发资料 | 未提供 |", ""]
    labels = _climate_labels(history)
    point_labels = {"baoan_south_background": "南部公共背景点", "baoan_north_background": "北部公共背景点"}
    disease_labels = {"DENV": "登革热（DENV）", "CHIKV": "基孔肯雅热（CHIKV）"}
    for disease in ("DENV", "CHIKV"):
        table = tables["diseases"][disease]
        total = table["total"]
        counts = quality.get("by_disease_status", {})
        recorded = counts.get(disease + ":recorded", 0)
        unconfirmed = counts.get(disease + ":unconfirmed", 0)
        cancelled = counts.get(disease + ":excluded", 0)
        undated = table.get("excluded", {}).get("undated", 0)
        lines += [f"## {disease_labels[disease]}", "",
                  f"来源保守归并后为已登记状态（recorded）{recorded} 个事件，另有未确认 {unconfirmed} 个、核销 {cancelled} 个。"
                  f"未确认和核销事件不进入本节；已登记事件再排除起病日、报卡日及阳性日期均未知的 {undated} 个，"
                  f"得到可比较登记事件 {total['registered_cases']} 个。这些事件仍可能涉及前述未合并同名记录，不能称为完全唯一患者数。", "",
                  f"本节可比较登记事件中：宝安本地分类 {total['local']} 例，"
                  f"输入分类 {total['imported']} 例，未明或冲突 {total['unknown_or_conflict']} 例。"
                  f"记录年份分布：{json.dumps(total['by_year'], ensure_ascii=False)}。", "",
                  "### 街道居住关联", "", _table(table["streets"]), "",
                  "### 前20个候选小区及居住地点", "",
                  "以下名称由原地址文本保守抽取，按历史本地分类病例数排序；尚未完成标准地址库及边界核验。"
                  "新的流调名称与候选名称不完全一致时，须先核验同一地点，不进行模糊自动合并。", "",
                  _table(table["sites"][:20], places=True), "",
                  "### 工作类别", "",
                  "职业标签只能提出核查方向。实际风险需要结合室内外、班次、工作点、停留时长、门窗防蚊及日间叮咬情况；"
                  "销售不自动视为外勤，工人不自动视为户外岗位。", "",
                  _table(table["occupations"]), "",
                  "### 年龄人群", "",
                  "年龄分组反映登记构成。幼儿及高龄人员的防护执行和照护需求应核实，不能据年龄自动提高传染性分值。", "",
                  _table(table["populations"]), "",
                  "### 起病前14日相似气候箱", "",
                  "窗口为起病日前14个完整自然日，排除起病当日及之后天气；温度取均值、降雨取累计。"
                  "只纳入温度及降雨均完整的窗口。分箱边界是透明描述规则，不是生物学高低风险阈值。", "",
                  "同一病例分别在南北两个公共背景点计算对照，以下两个点是独立的背景敏感性对照，不能跨点相加。"
                  "具体新病例按其街道使用预设公共代理点；公共格点不是小区实测，不能由天气箱证明存在感染蚊。", ""]
        climates = table["climates"]
        calendar = table.get("climate_calendar", {})
        for point in sorted({row["name"].split("|", 1)[0] for row in climates} | set(calendar)):
            rows = []
            by_bin = {}
            for row in climates:
                if row["name"].split("|", 1)[0] == point:
                    by_bin[row["name"].split("|", 1)[1]] = row
            point_calendar = calendar.get(point, {})
            calendar_bins = point_calendar.get("bins", {})
            for key in sorted(set(by_bin) | {k for k, value in calendar_bins.items() if value.get("anchor_days", 0) > 0}):
                item = dict(by_bin.get(key, {"registered_cases": 0, "local": 0, "imported": 0, "unknown_or_conflict": 0}))
                calbin = calendar_bins.get(key, {})
                item["name"] = calbin.get("bin", {}).get("label") or labels.get(point + "|" + key) or "温度或降雨分组标签未知"
                item["anchor_days"] = calbin.get("anchor_days")
                rows.append(item)
            lines += [f"#### {point_labels.get(point, point)}", ""]
            if point_calendar:
                lines += [f"资料日期范围：{point_calendar.get('anchor_start_date', '未知')} 至 "
                          f"{point_calendar.get('anchor_end_date_inclusive', '未知')}；完整前14日窗口对应 "
                          f"{point_calendar.get('complete_anchor_days', '未知')} 天，不完整 "
                          f"{point_calendar.get('incomplete_anchor_days', '未知')} 天。"
                          "下表显示出现过的气候箱或有病例的气候箱；相邻14日窗口重叠，出现天数不是独立人群暴露次数。", ""]
            else:
                lines += ["尚未提供该背景点的完整日期频次对照，气候天数显示未知。", ""]
            lines += [_table(rows, climate=True), ""]
        if not climates:
            lines += ["暂无完整、可比较的历史气候窗口。", ""]
        lines += ["本节排除项：" + ("；".join(f"{_cell(k)}={v}" for k, v in table["excluded"].items()) or "无") + "。", ""]
    lines += ["## 气候与文件证据", ""]
    for point, meta in history.get("weather_metadata", {}).items():
        lines.append(f"- {_cell(point_labels.get(point, point))}：模型 {_cell(meta.get('model'))}，数据类型 {_cell(meta.get('source_type'))}，"
                     f"空间分辨率 {_cell(meta.get('spatial_resolution'))}。来源：{meta.get('documentation_url') or meta.get('source_ref') or '未知'}。")
    lines += ["", "原始工作簿只读使用，不复制到本资源。source-manifest.json保存输入路径、指纹与显式字段映射；"
              "case-registry.json保存匿名事件与来源sheet/row；catalog.json保存完整统计及来源定位；"
              "registry.json锁定核心资源文件SHA256，history.json是正式运行入口。", "",
              "每次新流调应按起病日或明确候选日期设置历史截点，排除本次病例及未来记录，"
              "分别列出同街道、候选同小区、同气候箱及小区与气候交集的病例数与本地分类数，再说明现况证据和处置。", ""]
    return "\n".join(lines)


def build_history_resource(manifest_path, weather_path, output_path):
    """Validate explicit local inputs, then create one new private READY directory.

    The output directory must not already exist. Existing source workbooks, weather
    snapshots, manifests and READY registries are never modified or replaced.
    Returns absolute paths and a compact summary; no raw case data is printed.
    """
    manifest_path = Path(manifest_path).expanduser().resolve()
    weather_path = Path(weather_path).expanduser().resolve()
    output_path = Path(output_path).expanduser().resolve()
    if output_path.exists():
        raise ValidationError("历史资源输出目录已存在；请使用新的版本目录，不覆盖既有资源")
    if not manifest_path.is_file() or not weather_path.is_file():
        raise ValidationError("历史manifest或本地天气输入不存在")
    manifest = read_json(manifest_path)
    if not isinstance(manifest, dict) or not manifest.get("sources"):
        raise ValidationError("历史manifest缺少明确来源")
    original_sources = []
    for source in manifest["sources"]:
        path = Path(source.get("path", "")).expanduser()
        if not path.is_absolute() or not path.is_file():
            raise ValidationError("历史来源必须是已解析的绝对本地文件路径")
        sha = file_hash(path)
        if sha != source.get("sha256"):
            raise ValidationError("历史来源指纹漂移，需重新维护manifest")
        original_sources.append({"source_id": source.get("source_id"), "path": str(path.resolve()), "sha256": sha})
    manifest_sha, weather_sha = file_hash(manifest_path), file_hash(weather_path)
    weather = validate_history_weather(read_json(weather_path))
    # All preflight and scientific compilation happen before directory mutation.
    salt = os.urandom(32)
    case_registry = build_registry(manifest, salt)
    history = validate_history(compile_history(case_registry, weather))
    tables = catalog(history)
    if file_hash(manifest_path) != manifest_sha or file_hash(weather_path) != weather_sha:
        raise ValidationError("构建期间输入文件发生变化，请重新维护")
    for source in original_sources:
        if file_hash(source["path"]) != source["sha256"]:
            raise ValidationError("构建期间历史工作簿发生变化，请重新维护")
    output_path.mkdir(mode=0o700, parents=False, exist_ok=False)
    created_at = datetime.now(TZ).isoformat(timespec="seconds")
    summary = {"raw_case_records": case_registry["quality"]["raw_case_records"],
               "deduplicated_events": len(case_registry["cases"]),
               "case_status_counts": case_registry["quality"]["by_disease_status"],
               "catalog_counts": {d: tables["diseases"][d]["total"]["registered_cases"] for d in ("DENV", "CHIKV")},
               "coverage": case_registry.get("coverage"), "history_fingerprint": history["fingerprint"]}
    try:
        descriptor = os.open(output_path / "salt.key", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(salt)
        for filename, value in [("history.json", history), ("case-registry.json", case_registry),
                                ("weather.json", weather), ("source-manifest.json", manifest), ("catalog.json", tables)]:
            _safe_write(output_path / filename, value)
        _safe_text(output_path / "历史汇总.md", _render_summary(history, tables, created_at))
        knowledge = {"timestamp": created_at, "operation": "build_historical_resource", "phase": "BOOTSTRAP",
                     "operation_scope": "historical_resource_maintenance", "status": "validated",
                     "source_manifest_path": str(manifest_path), "source_manifest_sha256": manifest_sha,
                     "weather_input_path": str(weather_path), "weather_input_sha256": weather_sha,
                     "original_sources": original_sources, "summary": summary,
                     "validation": ["all_source_fingerprints_match", "weather_schema_validated", "compiled_history_fingerprint_validated", "no_source_workbooks_copied"],
                     "global_pointer_changed": False}
        _safe_text(output_path / "knowledge.jsonl", json.dumps(knowledge, ensure_ascii=False, sort_keys=True) + "\n")
        files = {path.name: file_hash(path) for path in sorted(output_path.iterdir()) if path.is_file()}
        registry = {"schema_version": "1.0", "resource_type": "baoan_historical_comparison", "status": "READY",
                    "phase": "BOOTSTRAP", "operation_scope": "historical_resource_maintenance", "created_at": created_at,
                    "runtime_entry": "history.json", "history_fingerprint": history["fingerprint"], "files": files,
                    "original_sources": original_sources, "source_manifest_sha256": manifest_sha,
                    "weather_input_sha256": weather_sha, "summary": summary,
                    "self_hash_note": "registry.json is excluded from its own files map; caller can lock its external SHA256."}
        # Verify written bytes before registration; READY is the final write.
        for name, sha in files.items():
            if file_hash(output_path / name) != sha:
                raise ValidationError("历史资源写入后校验失败")
        validate_history(read_json(output_path / "history.json"))
        _safe_write(output_path / "registry.json", registry)
    except Exception:
        # Keep bounded partial evidence for explicit repair, never silently READY.
        failed_path = output_path / "BUILD_FAILED.json"
        if not failed_path.exists():
            _safe_write(failed_path, {"status": "INCOMPLETE", "phase": "BOOTSTRAP", "created_at": created_at,
                                      "message": "Build did not complete; do not use this directory as READY."})
        raise
    return {"output_path": str(output_path), "registry_path": str(output_path / "registry.json"),
            "history_path": str(output_path / "history.json"), "summary_path": str(output_path / "历史汇总.md"),
            "summary": summary}


def main(argv=None):
    parser = argparse.ArgumentParser(description="在维护阶段构建新的宝安匿名历史病例与气候资源；不覆盖、不切换指针")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--weather", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    result = build_history_resource(args.manifest, args.weather, args.output)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
