"""Read-only ERA5 archive reuse and bounded acquisition during prepare only.

The 84 calendar days preceding each anchor are retained. Reanalysis and the
recent IFS snapshot are never spliced; neither represents a community station.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
from collections import Counter
from datetime import date, timedelta
from pathlib import Path
from urllib.parse import urlencode

from . import weather as w

ENDPOINT = "https://archive-api.open-meteo.com/v1/archive"
MODEL = "era5"
DAYS = 84
HOURLY = ("temperature_2m", "relative_humidity_2m", "precipitation", "wind_speed_10m")
DAILY = ("temperature_2m_mean", "temperature_2m_min", "temperature_2m_max", "precipitation_sum", "rain_sum", "wind_speed_10m_max")
FEATURE_UNITS = {"temperature_mean_c": "°C", "precipitation_sum_mm": "mm", "humidity_mean_pct": "%"}


def _sha(raw):
    return hashlib.sha256(raw.encode("utf-8") if isinstance(raw, str) else raw).hexdigest()


def _date(value):
    if not isinstance(value, str) or len(value) != 10:
        raise ValueError("weather anchor must be YYYY-MM-DD")
    return date.fromisoformat(value)


def _dates(start, end):
    return [start + timedelta(days=i) for i in range((end - start).days + 1)]


def _numeric(value, lower, upper):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and lower <= value <= upper


def _payload(raw):
    payload = json.loads(raw)
    if not isinstance(payload, dict) or payload.get("error"):
        raise ValueError("ERA5 provider error or unexpected schema")
    if payload.get("utc_offset_seconds") != 28800:
        raise ValueError("ERA5 timezone must be Asia/Shanghai")
    for key in HOURLY:
        expected = "°C" if key == "temperature_2m" else "%" if "humidity" in key else "mm" if key == "precipitation" else "m/s"
        if payload.get("hourly_units", {}).get(key) != expected:
            raise ValueError("ERA5 hourly unit mismatch: " + key)
    for key in DAILY:
        expected = "°C" if "temperature" in key else "m/s" if "wind" in key else "mm"
        if payload.get("daily_units", {}).get(key) != expected:
            raise ValueError("ERA5 daily unit mismatch: " + key)
    for kind, fields in (("hourly", HOURLY), ("daily", DAILY)):
        block = payload.get(kind, {})
        times = block.get("time")
        if not isinstance(times, list) or any(not isinstance(block.get(k), list) or len(block[k]) != len(times) for k in fields):
            raise ValueError("ERA5 array length mismatch: " + kind)
    for key, low, high in (("latitude", -90, 90), ("longitude", -180, 180)):
        if not _numeric(payload.get(key), low, high):
            raise ValueError("ERA5 returned grid coordinate missing/invalid")
    return payload


def _source(raw, point, *, retrieved_at, request_url, key, origin, **extra):
    payload = _payload(raw)
    return {"key": key, "point_id": point["point_id"], "requested_latitude": point["latitude"],
            "requested_longitude": point["longitude"], "provider": "open-meteo", "source_type": "reanalysis",
            "model": MODEL, "source_ref": ENDPOINT, "request_url": request_url,
            "grid_latitude": payload["latitude"], "grid_longitude": payload["longitude"],
            "timezone": "Asia/Shanghai", "published_at": None, "retrieved_at": retrieved_at,
            "raw_response": raw, "raw_sha256": _sha(raw), "origin": origin, **extra}


def _rows(source):
    if _sha(source["raw_response"]) != source["raw_sha256"]:
        raise ValueError("ERA5 raw response SHA256 mismatch")
    data = _payload(source["raw_response"])
    if (source.get("grid_latitude"), source.get("grid_longitude")) != (data["latitude"], data["longitude"]):
        raise ValueError("ERA5 source grid metadata mismatch")
    hourly, daily = data["hourly"], data["daily"]
    times = hourly["time"]
    frequencies = Counter(times)
    day_frequencies = Counter(daily["time"])
    by_day = {}
    for i, time in enumerate(times):
        if not isinstance(time, str):
            raise ValueError("ERA5 invalid hourly timestamp")
        by_day.setdefault(time[:10], []).append(i)
    rows = {}
    for i, ds in enumerate(daily["time"]):
        _date(ds)
        indexes = by_day.get(ds, [])
        expected = {f"{ds}T{hour:02d}:00" for hour in range(24)}
        issues = []
        if len(indexes) != 24 or {times[j] for j in indexes} != expected or any(frequencies[times[j]] != 1 for j in indexes):
            issues.append("incomplete_or_duplicate_hourly_timestamps")
        if day_frequencies[ds] != 1:
            issues.append("duplicate_daily_date")
        hvalues = {k: [hourly[k][j] for j in indexes] for k in HOURLY}
        for key, values in hvalues.items():
            bounds = (-100, 70) if key == "temperature_2m" else (0, 100) if "humidity" in key else (0, 150) if "wind" in key else (0, 3000)
            if len(values) != 24 or not all(_numeric(v, *bounds) for v in values):
                issues.append("missing_or_invalid_hourly:" + key)
        values = {key: daily[key][i] for key in DAILY}
        for key, value in values.items():
            bounds = (-100, 70) if "temperature" in key else (0, 150) if "wind" in key else (0, 3000)
            if not _numeric(value, *bounds):
                issues.append("missing_or_invalid_daily:" + key)
        if not issues and not values["temperature_2m_min"] <= values["temperature_2m_mean"] <= values["temperature_2m_max"]:
            issues.append("temperature_order_anomaly")
        if not issues and values["rain_sum"] > values["precipitation_sum"] + 0.2:
            issues.append("rain_exceeds_precipitation")
        complete = not issues
        rows[ds] = {"date": ds, "temperature_mean_c": values["temperature_2m_mean"] if complete else None,
                    "temperature_min_c": values["temperature_2m_min"] if complete else None,
                    "temperature_max_c": values["temperature_2m_max"] if complete else None,
                    "precipitation_sum_mm": values["precipitation_sum"] if complete else None,
                    "rain_sum_mm": values["rain_sum"] if complete else None,
                    "humidity_mean_pct": sum(hvalues["relative_humidity_2m"]) / 24 if complete else None,
                    "wind_speed_mean_ms": sum(hvalues["wind_speed_10m"]) / 24 if complete else None,
                    "complete": complete, "source_key": source["key"], "issues": issues}
    return rows


def _verify_public_source(source, point):
    if (source.get("point_id") != point["point_id"] or source.get("requested_latitude") != point["latitude"]
            or source.get("requested_longitude") != point["longitude"] or source.get("model") != MODEL
            or source.get("provider") != "open-meteo" or source.get("source_type") != "reanalysis"
            or source.get("source_ref") != ENDPOINT):
        raise ValueError("ERA5 cached/public source identity mismatch")
    _rows(source)


def _local_sources(manifest_path, points, needed):
    if not manifest_path:
        return [], None
    path = Path(manifest_path).expanduser().resolve()
    raw_manifest = path.read_bytes()
    manifest = json.loads(raw_manifest)
    if manifest.get("model") != MODEL or manifest.get("source_type") != "reanalysis" or manifest.get("endpoint") != ENDPOINT:
        raise ValueError("local ERA5 archive manifest identity mismatch")
    result = []
    for shard in manifest.get("shards", []):
        pid = shard.get("point_id")
        if pid not in points or shard.get("failed"):
            continue
        params = shard.get("parameters", {})
        start, end = _date(params.get("start_date")), _date(params.get("end_date"))
        if not any(start <= day <= end for day in needed):
            continue
        p = points[pid]
        if (params.get("latitude"), params.get("longitude"), params.get("models"), params.get("timezone"), params.get("cell_selection", "land")) != (p["latitude"], p["longitude"], MODEL, "Asia/Shanghai", "land"):
            raise ValueError("local ERA5 archive request mismatch")
        rawpath = (path.parent / shard["raw_file"]).resolve()
        if not rawpath.is_relative_to(path.parent):
            raise ValueError("local ERA5 raw path escapes archive")
        raw = rawpath.read_bytes()
        if len(raw) > w.MAX_BYTES or _sha(raw) != shard["sha256"]:
            raise ValueError("local ERA5 archive raw SHA256/size mismatch")
        result.append(_source(raw.decode("utf-8"), p, retrieved_at=shard.get("retrieved_at"), request_url=shard.get("url"),
                              key="local:" + shard["sha256"], origin="verified_local_archive", original_raw_path=str(rawpath)))
    return result, {"path": str(path), "sha256": _sha(raw_manifest), "read_only": True}


def _cache_read(cache_root, point, needed):
    result = []
    if cache_root is None or not Path(cache_root).exists():
        return result
    for path in sorted(Path(cache_root).glob("era5-*.json")):
        raw = path.read_bytes()
        if len(raw) > w.MAX_BYTES * 2:
            raise ValueError("ERA5 cache exceeds size limit")
        record = json.loads(raw)
        source = record.get("source", {})
        # Verify every entry's content address before selecting, never replace drift.
        if record.get("schema_version") != "1.0" or record.get("source_sha256") != _sha(json.dumps(source, sort_keys=True, ensure_ascii=False)):
            raise ValueError("ERA5 cache record SHA256 mismatch")
        if path.name != "era5-" + record["source_sha256"] + ".json":
            raise ValueError("ERA5 cache content-addressed filename mismatch")
        if source.get("point_id") != point["point_id"]:
            continue
        _verify_public_source(source, point)
        rows = _rows(source)
        if any(d.isoformat() in rows for d in needed):
            result.append(source)
    return result


def _cache_write(cache_root, source):
    if cache_root is None:
        return
    root = Path(cache_root)
    root.mkdir(parents=True, exist_ok=True)
    checksum = _sha(json.dumps(source, sort_keys=True, ensure_ascii=False))
    record = {"schema_version": "1.0", "source_sha256": checksum, "source": source}
    payload = json.dumps(record, ensure_ascii=False, indent=2) + "\n"
    path = root / ("era5-" + checksum + ".json")
    try:
        with path.open("x", encoding="utf-8") as handle:
            handle.write(payload)
    except FileExistsError:
        if path.read_text(encoding="utf-8") != payload:
            raise ValueError("existing ERA5 cache drift; repair separately")


def _merged(sources, point_id):
    result = {}
    grids = {s["key"]: (s["grid_latitude"], s["grid_longitude"]) for s in sources if s["point_id"] == point_id}
    # Preserve local snapshots first; conflicting complete revisions are explicit gaps.
    for source in sources:
        if source["point_id"] != point_id:
            continue
        for ds, row in _rows(source).items():
            previous = result.get(ds)
            if previous and previous["complete"] and row["complete"]:
                fields = (*FEATURE_UNITS, "temperature_min_c", "temperature_max_c", "rain_sum_mm", "wind_speed_mean_ms")
                if any(previous[k] != row[k] for k in fields) or grids[previous["source_key"]] != grids[row["source_key"]]:
                    result[ds] = {**dict.fromkeys(fields), "date": ds, "complete": False, "source_key": None,
                                  "issues": ["source_revision_conflict"], "conflict": True}
            elif previous and previous.get("conflict"):
                continue
            elif previous is None or not previous["complete"]:
                result[ds] = row
    return result


def _ranges(dates):
    result = []
    for day in sorted(dates):
        if result and day == result[-1][1] + timedelta(days=1) and (day - result[-1][0]).days < 365:
            result[-1] = (result[-1][0], day)
        else:
            result.append((day, day))
    return result


def _acquire(point, start, end, timeout, retries):
    params = {"latitude": point["latitude"], "longitude": point["longitude"], "start_date": start.isoformat(), "end_date": end.isoformat(),
              "hourly": ",".join(HOURLY), "daily": ",".join(DAILY), "models": MODEL, "timezone": "Asia/Shanghai",
              "temperature_unit": "celsius", "wind_speed_unit": "ms", "precipitation_unit": "mm", "cell_selection": "land"}
    url = ENDPOINT + "?" + urlencode(params)
    raw = w._request(url, timeout, retries)
    return _source(raw, point, retrieved_at=w._iso(w._now()), request_url=url, key="network:" + _sha(raw), origin="network")


def _window(rows, point_id, anchor, sources):
    daily = []
    for day in _dates(anchor - timedelta(days=DAYS), anchor - timedelta(days=1)):
        daily.append(rows.get(day.isoformat(), {"date": day.isoformat(), **dict.fromkeys(FEATURE_UNITS), "complete": False,
                                                "source_key": None, "issues": ["missing_day"]}))
    used = {r.get("source_key") for r in daily if r.get("complete")}
    used_sources = [s for s in sources if s["point_id"] == point_id and s["key"] in used]
    grids = {(s["grid_latitude"], s["grid_longitude"]) for s in used_sources}
    grid = next(iter(grids)) if len(grids) == 1 else (None, None)
    features = {}
    for n in (7, 14, 28, 56, 84):
        window = daily[-n:]
        window_used = {r.get("source_key") for r in window if r.get("complete")}
        window_grids = {(s["grid_latitude"], s["grid_longitude"]) for s in used_sources if s["key"] in window_used}
        ok = all(r.get("complete") for r in window) and len(window_grids) == 1
        features[str(n)] = {"days": n, "window_start": (anchor - timedelta(days=n)).isoformat(), "end_exclusive": anchor.isoformat(),
                            "complete": ok, "temperature_mean_c": round(sum(r["temperature_mean_c"] for r in window) / n, 6) if ok else None,
                            "precipitation_sum_mm": round(sum(r["precipitation_sum_mm"] for r in window), 6) if ok else None,
                            "humidity_mean_pct": round(sum(r["humidity_mean_pct"] for r in window) / n, 6) if ok else None,
                            "missing_days": [r["date"] for r in window if not r.get("complete")], "grid_consistent": len(window_grids) == 1}
    return {"daily": daily, "features": features, "metadata": {"point_id": point_id, "provider": "open-meteo", "source_type": "reanalysis",
            "model": MODEL, "source_ref": ENDPOINT, "grid_latitude": grid[0], "grid_longitude": grid[1], "timezone": "Asia/Shanghai",
            "units": dict(FEATURE_UNITS), "daily_semantics": "provider daily aggregates in Asia/Shanghai; humidity mean of 24 complete hourly values",
            "spatial_resolution": "0.25 degrees (~25 km); background reanalysis, not community observation", "published_at": None,
            "source_keys": sorted(used), "retrospective_retrieval": True},
            "quality": {"expected_days": DAYS, "complete_days": sum(r.get("complete", False) for r in daily), "complete_84_days": features["84"]["complete"],
                        "issues": (["grid_changed_within_window"] if len(grids) > 1 else []) + ["publication_time_unknown", "retrospective_data_not_prospective_evidence"]}}


def validate_archive(archive, points, assessment_at):
    """Offline reconstruction from saved raw responses, without trusting features."""
    if archive.get("schema_version") != "1.0" or archive.get("kind") != "era5_anchor_archive" or archive.get("model") != MODEL:
        raise ValueError("weather archive contract mismatch")
    known = w._points(points)
    cutoff = w._dt(assessment_at).date()
    out = copy.deepcopy(archive)
    sources = out.get("sources", [])
    for source in sources:
        pid = source.get("point_id")
        if pid not in known:
            raise ValueError("weather archive contains unknown point")
        _verify_public_source(source, known[pid])
    for anchor_text in out.get("anchors", {}):
        anchor = _date(anchor_text)
        if anchor > cutoff:
            raise ValueError("weather anchor is after assessment")
        out["anchors"][anchor_text] = {"anchor_date": anchor_text, "excludes_anchor_date": True,
                                      "points": {pid: _window(_merged(sources, pid), pid, anchor, sources) for pid in known}}
    return out


def prepare_archive(points, assessment_at, anchors=(), *, cache_root=None, archive_manifest=None, timeout=15, retries=1):
    known = w._points(points)
    cutoff = w._dt(assessment_at)
    now = w._now()
    if not 0 < timeout <= 120 or not isinstance(retries, int) or not 0 <= retries <= 3:
        raise ValueError("timeout must be 0..120 seconds; retries 0..3")
    anchor_dates = {_date(cutoff.date().isoformat()), *(_date(a) for a in anchors)}
    if any(a > cutoff.date() or a < date(1940, 3, 25) for a in anchor_dates):
        raise ValueError("weather anchor future or outside supported 84-day ERA5 history")
    needed = {day for anchor in anchor_dates for day in _dates(anchor - timedelta(days=DAYS), anchor - timedelta(days=1))}
    sources, manifest_record = _local_sources(archive_manifest, known, needed)
    archive = {"schema_version": "1.0", "kind": "era5_anchor_archive", "model": MODEL, "source_type": "reanalysis", "timezone": "Asia/Shanghai",
               "history_days": DAYS, "main_lag_days": 56, "created_at": w._iso(now), "local_manifest": manifest_record, "sources": sources,
               "anchors": {a.isoformat(): {} for a in sorted(anchor_dates)}, "errors": [], "provider_status": "pending"}
    if cutoff > now + timedelta(minutes=5):
        archive["errors"].append({"code": "future_as_of", "message": "No future weather acquisition permitted"})
    else:
        for pid, point in known.items():
            sources.extend(_cache_read(cache_root, point, needed))
            rows = _merged(sources, pid)
            missing = {d for d in needed if not rows.get(d.isoformat(), {}).get("complete") and not rows.get(d.isoformat(), {}).get("conflict")}
            for start, end in _ranges(missing):
                try:
                    source = _acquire(point, start, end, timeout, retries)
                except (ValueError, TypeError, KeyError, RuntimeError) as exc:
                    archive["errors"].append({"point_id": pid, "start_date": start.isoformat(), "end_date": end.isoformat(), "code": "archive_fetch_failed", "message": str(exc)})
                    continue
                _cache_write(cache_root, source)
                sources.append(source)
    # Deduplicate immutable raw evidence copied from both cache and local snapshot.
    archive["sources"] = list({(s["point_id"], s["key"]): s for s in sources}.values())
    out = validate_archive(archive, points, assessment_at)
    complete = all(p["quality"]["complete_84_days"] for a in out["anchors"].values() for p in a["points"].values())
    any_data = any(p["quality"]["complete_days"] for a in out["anchors"].values() for p in a["points"].values())
    out["provider_status"] = "complete_reanalysis" if complete else "partial_reanalysis" if any_data else "failed_or_missing"
    out["attribution"] = "Open-Meteo / Copernicus Climate Change Service ERA5, CC BY 4.0"
    out["availability_note"] = "ERA5 publication is normally delayed about 5 days; recent gaps remain null and are not filled from IFS."
    return out
