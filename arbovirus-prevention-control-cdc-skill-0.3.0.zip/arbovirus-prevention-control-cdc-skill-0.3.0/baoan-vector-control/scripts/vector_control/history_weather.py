"""Historical daily weather and strictly complete, trailing 14-day windows.

Acquisition belongs to maintenance/prepare, never frozen production. Only
public profile coordinates are sent to the fixed public weather endpoint.
ERA5 is a coarse background reanalysis, not community observations.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
from datetime import date, datetime, timedelta
from urllib.parse import urlencode

from .weather import _points, _request, _now, _iso

SCHEMA_VERSION = "1.0"
# The provider's ERA5-Land does not expose precipitation. Use ERA5 for BOTH
# variables instead of silently combining models with different grids.
MODEL = "era5"
ENDPOINT = "https://archive-api.open-meteo.com/v1/archive"
DOCUMENTATION = "https://open-meteo.com/en/docs/historical-weather-api"
SOURCE_TYPES = {"observation", "interpolated_observation", "reanalysis", "model", "unknown"}
DAILY_UNITS = {"temperature_mean_c": "°C", "precipitation_sum_mm": "mm"}


def _date(value):
    if isinstance(value, datetime):
        raise ValueError("date must not contain a time")
    if isinstance(value, date):
        return value
    if not isinstance(value, str) or len(value) != 10:
        raise ValueError("date must be YYYY-MM-DD")
    return date.fromisoformat(value)


def _value(value, key, issues):
    if value is None or value == "":
        return None
    try:
        number = float(value)
        if isinstance(value, bool) or not math.isfinite(number):
            raise ValueError
        if key == "precipitation_sum_mm" and number < 0:
            raise ValueError
        # Reject impossible/unconverted weather while retaining missingness.
        if key == "temperature_mean_c" and not -100 <= number <= 70:
            raise ValueError
        return number
    except (ValueError, TypeError):
        issues.add("invalid_numeric:" + key)
        return None


def validate_history_weather(snapshot, points=None):
    """Validate local daily weather; recompute coverage without network.

    Conflicting duplicate days become missing. Raw responses, when present,
    must match their saved digest. Supplied provenance is not certification of
    an observation station. Unverified/unknown provenance is never comparable.
    """
    if not isinstance(snapshot, dict) or snapshot.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unsupported historical weather schema_version")
    if snapshot.get("kind") != "historical_daily_weather" or snapshot.get("timezone") != "Asia/Shanghai":
        raise ValueError("historical weather kind/timezone mismatch")
    start, end = _date(snapshot.get("start_date")), _date(snapshot.get("end_date"))
    if end < start:
        raise ValueError("historical weather date range reversed")
    if not isinstance(snapshot.get("points"), dict):
        raise ValueError("historical weather points object required")
    known = _points(points) if points is not None else None
    if known is not None and set(snapshot["points"]) - set(known):
        raise ValueError("historical weather contains unknown public points")
    out = copy.deepcopy(snapshot)
    out.setdefault("errors", [])
    for pid, entry in out["points"].items():
        if not isinstance(pid, str) or not pid or not isinstance(entry, dict):
            raise ValueError("invalid historical weather point")
        meta = entry.get("metadata")
        if not isinstance(meta, dict) or not isinstance(entry.get("daily"), list):
            raise ValueError("historical point metadata/daily required")
        source_type = meta.get("source_type", "unknown")
        if source_type not in SOURCE_TYPES:
            raise ValueError("invalid historical weather source_type")
        if (meta.get("provider") == "open-meteo" or "open-meteo.com" in str(meta.get("source_ref", ""))) and source_type in {"observation", "interpolated_observation"}:
            raise ValueError("Open-Meteo reanalysis cannot be labeled observation")
        if meta.get("units") != DAILY_UNITS:
            raise ValueError("historical daily weather units mismatch")
        if known is not None:
            for field in ("latitude", "longitude"):
                if meta.get(field) != known[pid][field]:
                    raise ValueError("historical weather public coordinate mismatch")
        if meta.get("raw_response") is not None:
            raw = meta["raw_response"]
            if not isinstance(raw, str) or hashlib.sha256(raw.encode()).hexdigest() != meta.get("raw_sha256"):
                raise ValueError("historical weather raw response SHA256 mismatch")
        issues = set(entry.get("quality", {}).get("issues", []))
        if not meta.get("source_ref"):
            issues.add("missing_source_ref")
        if source_type == "unknown":
            issues.add("unknown_source_type")
        by_date, conflicts = {}, set()
        for raw in entry["daily"]:
            if not isinstance(raw, dict):
                raise ValueError("historical daily row must be an object")
            try:
                day = _date(raw.get("date"))
            except (ValueError, TypeError):
                issues.add("invalid_date_filtered")
                continue
            if not start <= day <= end:
                issues.add("outside_requested_dates_filtered")
                continue
            row = {"date": day.isoformat(), **{k: _value(raw.get(k), k, issues) for k in DAILY_UNITS}}
            if day in by_date:
                if by_date[day] != row:
                    conflicts.add(day)
                    issues.add("duplicate_date_conflict")
                else:
                    issues.add("duplicate_date_identical")
            else:
                by_date[day] = row
        for day in conflicts:
            by_date[day] = {"date": day.isoformat(), **dict.fromkeys(DAILY_UNITS)}
        expected = (end - start).days + 1
        entry["daily"] = [by_date[d] for d in sorted(by_date)]
        counts = {key: sum(row[key] is not None for row in by_date.values()) for key in DAILY_UNITS}
        entry["quality"] = {
            "expected_days": expected, "rows_available": len(by_date),
            "available_days": counts,
            "missing_days": {key: expected - n for key, n in counts.items()},
            "complete": all(n == expected for n in counts.values()),
            "provenance_usable": bool(meta.get("source_ref")) and source_type != "unknown",
            "issues": sorted(issues),
        }
    return out


def build_history_weather(start_date, end_date, points, *, timeout=15, retries=1):
    """Fetch daily temperature/rainfall from one fixed reanalysis model.

    No mixing of missing station observations and reanalysis is performed.
    Provider failures/partial dates remain explicit, never zero-imputed.
    """
    start, end = _date(start_date), _date(end_date)
    if end < start or start < date(1940, 1, 1):
        raise ValueError("invalid ERA5 historical date range")
    if end >= _now().date():
        raise ValueError("historical daily weather must end before today")
    if not 0 < timeout <= 120 or not isinstance(retries, int) or not 0 <= retries <= 3:
        raise ValueError("timeout must be 0..120 seconds; retries 0..3")
    known = _points(points)
    snapshot = {"schema_version": SCHEMA_VERSION, "kind": "historical_daily_weather",
                "timezone": "Asia/Shanghai", "source_type": "reanalysis", "model": MODEL,
                "start_date": start.isoformat(), "end_date": end.isoformat(),
                "created_at": _iso(_now()), "points": {}, "errors": []}
    for pid, point in known.items():
        params = {"latitude": point["latitude"], "longitude": point["longitude"],
                  "start_date": start.isoformat(), "end_date": end.isoformat(),
                  "daily": "temperature_2m_mean,precipitation_sum", "timezone": "Asia/Shanghai",
                  "temperature_unit": "celsius", "precipitation_unit": "mm", "models": MODEL}
        url = ENDPOINT + "?" + urlencode(params)
        meta = {**point, "provider": "open-meteo", "source_type": "reanalysis", "model": MODEL,
                "source_ref": ENDPOINT, "documentation_url": DOCUMENTATION, "request_url": url,
                "point_source_ref": point["source_ref"], "units": dict(DAILY_UNITS),
                "spatial_resolution": "0.25 degrees (~25 km); public background grid, not community observation",
                "daily_semantics": "Asia/Shanghai complete calendar day; daily mean temperature and total precipitation",
                "attribution": "Open-Meteo / Copernicus Climate Change Service ERA5; CC BY 4.0",
                "published_at": None, "retrospective_retrieval": True,
                "model_selection_note": "Fixed ERA5 supplies both temperature and precipitation; this provider's ERA5-Land precipitation is unavailable. No cross-model variable splice.",
                "availability_note": "ERA5 is normally published with about 5 days delay; missing recent days remain missing"}
        entry = snapshot["points"][pid] = {"metadata": meta, "daily": []}
        try:
            raw = _request(url, timeout, retries)
            payload = json.loads(raw)
            meta.update(raw_response=raw, raw_sha256=hashlib.sha256(raw.encode()).hexdigest(), retrieved_at=_iso(_now()))
            if not isinstance(payload, dict) or payload.get("error"):
                raise ValueError("historical provider returned error/unexpected schema")
            if payload.get("utc_offset_seconds") != 28800:
                raise ValueError("historical provider timezone mismatch")
            units, daily = payload.get("daily_units", {}), payload.get("daily", {})
            if units.get("temperature_2m_mean") != "°C" or units.get("precipitation_sum") != "mm":
                raise ValueError("historical provider daily unit mismatch")
            times = daily.get("time")
            if not isinstance(times, list) or any(not isinstance(daily.get(k), list) or len(daily[k]) != len(times) for k in ("temperature_2m_mean", "precipitation_sum")):
                raise ValueError("historical provider daily array length mismatch")
            meta.update(provider_grid_latitude=payload.get("latitude"), provider_grid_longitude=payload.get("longitude"))
            entry["daily"] = [{"date": day, "temperature_mean_c": daily["temperature_2m_mean"][i],
                               "precipitation_sum_mm": daily["precipitation_sum"][i]} for i, day in enumerate(times)]
        except (ValueError, TypeError, KeyError, RuntimeError) as exc:
            snapshot["errors"].append({"point_id": pid, "code": "history_weather_fetch_failed", "message": str(exc)})
    return validate_history_weather(snapshot, points)


def window_features(snapshot, point_id, anchor_date, days=14):
    """Use only anchor minus 14 through anchor minus 1 calendar dates.

    Call validate_history_weather once at the boundary before repeated calls.
    A separate complete flag and missing-day lists make partial data unusable
    for climate-category case comparisons. No future/onset-day weather leaks.
    """
    if days != 14:
        raise ValueError("historical climate comparison requires exactly 14 complete days")
    anchor = _date(anchor_date)
    start = anchor - timedelta(days=days)
    entry = snapshot.get("points", {}).get(point_id, {})
    meta = entry.get("metadata", {})
    by_date = {r["date"]: r for r in entry.get("daily", [])}
    dates = [(start + timedelta(days=i)).isoformat() for i in range(days)]
    missing = {key: [d for d in dates if by_date.get(d, {}).get(key) is None] for key in DAILY_UNITS}
    usable = (meta.get("source_type") in SOURCE_TYPES - {"unknown"} and bool(meta.get("source_ref")))
    temperature = None if missing["temperature_mean_c"] or not usable else sum(by_date[d]["temperature_mean_c"] for d in dates) / days
    rainfall = None if missing["precipitation_sum_mm"] or not usable else sum(by_date[d]["precipitation_sum_mm"] for d in dates)
    return {
        "point_id": point_id, "anchor_date": anchor.isoformat(), "window_start": start.isoformat(),
        "window_end_exclusive": anchor.isoformat(), "days": days,
        "temperature_mean_14d_c": round(temperature, 6) if temperature is not None else None,
        "rainfall_14d_mm": round(rainfall, 6) if rainfall is not None else None,
        "complete": temperature is not None and rainfall is not None,
        "missing_temperature_days": missing["temperature_mean_c"],
        "missing_rainfall_days": missing["precipitation_sum_mm"],
        "source_type": meta.get("source_type", "unknown"), "model": meta.get("model"),
        "source_ref": meta.get("source_ref"), "spatial_resolution": meta.get("spatial_resolution"),
        "comparison_limit": "描述性历史气候匹配；背景格点不是小区实测，不证明当地存在感染蚊或传播。",
    }


def climate_bin(temperature_mean_14d_c, rainfall_14d_mm):
    """Transparent descriptive bins; boundaries are not biological cutoffs.

    The 25–<28 °C / 1–<10 mm cell permits comparison with the earlier report,
    but is not presumed the highest risk cell for either disease.
    """
    issues = set()
    t = _value(temperature_mean_14d_c, "temperature_mean_c", issues)
    r = _value(rainfall_14d_mm, "precipitation_sum_mm", issues)
    if t is None or r is None:
        return None
    if t < 20:
        tid, tlabel = "lt20", "<20℃"
    elif t < 25:
        tid, tlabel = "20to25", "20–<25℃"
    elif t < 28:
        tid, tlabel = "25to28", "25–<28℃"
    elif t < 32:
        tid, tlabel = "28to32", "28–<32℃"
    else:
        tid, tlabel = "ge32", "≥32℃"
    if r == 0:
        rid, rlabel = "zero", "0毫米"
    elif r < 1:
        rid, rlabel = "0to1", ">0–<1毫米"
    elif r < 10:
        rid, rlabel = "1to10", "1–<10毫米"
    elif r < 50:
        rid, rlabel = "10to50", "10–<50毫米"
    elif r < 100:
        rid, rlabel = "50to100", "50–<100毫米"
    else:
        rid, rlabel = "ge100", "≥100毫米"
    return {"key": tid + "__" + rid, "temperature_key": tid, "rainfall_key": rid,
            "label": "14日均温" + tlabel + "；14日累计降雨" + rlabel,
            "definition_version": "descriptive-14d-bins-v1", "interpretation": "描述性分组；非高低风险阈值、非暴发判定标准"}
