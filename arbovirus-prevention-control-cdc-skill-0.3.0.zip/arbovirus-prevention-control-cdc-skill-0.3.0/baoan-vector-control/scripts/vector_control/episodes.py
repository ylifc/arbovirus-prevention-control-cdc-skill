"""Place episode evidence, without imputing transmission or negative outcomes."""
from __future__ import annotations

from collections import defaultdict
from .common import instant
from .engine import activity_window


def reviewed_origin(case, at):
    """A provincial local label cannot establish acquisition within Baoan."""
    if case.get('diagnostic_conflict') or case.get('origin_conflict'):
        return 'unknown'
    origin = (case.get('origins') or {}).get('baoan')
    if origin is not None:
        if (origin.get('reviewed') is True and origin.get('evidence_ref')
                and origin.get('known_at') and instant(origin['known_at']) <= instant(at)):
            return origin.get('classification') if origin.get('classification') in {'local', 'imported'} else 'unknown'
        return 'unknown'
    if (case.get('origin_scope') == 'baoan' and case.get('origin_ref')
            and case.get('origin_known_at') and instant(case['origin_known_at']) <= instant(at)):
        return case.get('origin') if case.get('origin') in {'local', 'imported'} else 'unknown'
    return 'unknown'


def _union_hours(intervals):
    merged = []
    for start, end in sorted(intervals):
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(end, merged[-1][1])
        else:
            merged.append([start, end])
    return round(sum((b - a).total_seconds() / 3600 for a, b in merged), 6)


def presence_evidence(data, site_id, disease, rules):
    """Union intervals per person; unknown protection never becomes protected."""
    cases = {c['case_id']: c for c in data['cases'] if c['disease'] == disease}
    intervals = defaultdict(list)
    by_protection = defaultdict(lambda: defaultdict(list))
    present_cases = set()
    missing, evidence = [], []
    for event in data['activities']:
        if event['site_id'] != site_id or event['case_id'] not in cases or event['event_type'] == 'source_investigation':
            continue
        case = cases[event['case_id']]
        if case.get('status') != 'confirmed' or not case.get('confirmation_ref') or case.get('diagnostic_conflict'):
            missing.append(event['event_id'] + ':diagnosis_not_reviewed_positive')
            continue
        window = activity_window(case, rules['diseases'][disease])
        if not event.get('start') or not event.get('end') or not event.get('evidence_ref') or not window['start']:
            missing.append(event['event_id'] + ':presence_time_or_evidence_unknown')
            continue
        start = max(instant(event['start']), instant(window['start']))
        end = min(instant(event['end']), instant(window['end']), instant(data['assessment_at']))
        if start >= end:
            continue
        cid = case['case_id']
        person = case.get('person_id') or cid
        present_cases.add(cid)
        intervals[person].append((start, end))
        protection = event.get('protection_status', 'unknown')
        if protection not in {'protected', 'unprotected'} or not event.get('protection_ref'):
            protection = 'unknown'
        by_protection[protection][person].append((start, end))
        evidence.append({'case_id': cid, 'event_id': event['event_id'], 'start': start.isoformat(), 'end_exclusive': end.isoformat(),
                         'window_status': window['status'], 'protection': protection, 'evidence_ref': event['evidence_ref']})
    return {'possible_infectious_presence_person_hours': sum(_union_hours(v) for v in intervals.values()) if intervals else None,
            'by_protection_person_hours': {k: sum(_union_hours(v) for v in by_protection[k].values()) if by_protection[k] else None
                                           for k in ('protected', 'unprotected', 'unknown')},
            'case_ids_with_presence': sorted(present_cases), 'intervals': evidence, 'missing': missing,
            'note': '候选感染性窗口交集，不证明该人在位时实际有传染性；保护状态分组可能重叠，不可相加。无活动记录是未知，不是零小时。'}


def summarize_episode(data, row, rules):
    members = [c for c in data['cases'] if c['case_id'] in row['current_case_ids']]
    origins = {c['case_id']: reviewed_origin(c, data['assessment_at']) for c in members}
    positive = {c['case_id'] for c in members if c.get('status') == 'confirmed' and c.get('confirmation_ref') and not c.get('diagnostic_conflict')}
    presence = presence_evidence(data, row['site_id'], row['disease'], rules)
    reviewed_local = [c['case_id'] for c in members if c['case_id'] in positive and origins[c['case_id']] == 'local'
                      and any(l['site_id'] == row['site_id'] and l.get('aggregation_eligible') is True and l.get('evidence_ref') for l in c.get('site_links', []))]
    imported_presence = sorted(positive & {cid for cid, origin in origins.items() if origin == 'imported'} & set(presence['case_ids_with_presence']))
    branch = 'local' if reviewed_local else 'imported' if imported_presence and all(v == 'imported' for v in origins.values()) else 'unknown_or_conflict'
    place = next(s for s in data['sites'] if s['site_id'] == row['site_id'])
    if place.get('location_status') != 'verified':
        branch = 'unknown_or_conflict'
    family_ids = sorted({c['episode_family_id'] for c in members if c.get('episode_family_id')})
    return {'site_id': row['site_id'], 'disease': row['disease'], 'branch': branch,
            'source_scenarios': ['imported', 'local'] if branch == 'unknown_or_conflict' else [branch],
            'reviewed_baoan_origins': origins, 'reviewed_local_activity_case_ids': reviewed_local,
            'imported_presence_case_ids': imported_presence, 'episode_family_ids': family_ids,
            'family_status': 'provided_requires_review' if family_ids else 'not_adjudicated',
            'place_status': place.get('location_status', 'unresolved'),
            'presence': presence, 'outcome': None, 'followup_status': 'not_adjudicated',
            'confirmed_transmission_chains': None,
            'note': '输入与本地共存时采用本地扩展情景并保留输入在位；输入不是阴性对照。续发结局须另核验完整随访。'}
