"""Readable historical comparisons, retaining nulls and source limitations."""
import csv
import html
from .common import write_json


def _e(value):
    return html.escape(str(value))


def _n(value):
    return '未能核定' if value is None else str(value)


def render_history(comparison, previous):
    parts = ['<h2>历史对照与具体提示</h2>']
    if comparison.get('status') != 'available':
        parts.append('<p>历史库未接入，历史病例与暴发数未知。</p>')
    else:
        parts.append('<p>' + _e(comparison.get('statistics_note', '历史登记不是人口发病率。')) + ' ' + _e(comparison.get('origin_scope_note', '来源口径需核验')) + ' 缺正式事件资料，暴发数量显示“未能核定”。</p>')
        for row in comparison['site_comparisons']:
            parts.append(f'<h3>{_e(row["street"])} · {_e(row["site_name"])} · {_e(row["disease"])}</h3>')
            parts.append(f'<p><strong>{_e(row["historical_hint"])}</strong>。历史截点：{_e(row["cutoff_exclusive"])}之前。地点匹配：{_e(row["place_match"]["status"])}。</p>')
            parts.append('<table><tr><th>比较范围</th><th>登记病例</th><th>本地</th><th>输入</th><th>未定/冲突</th><th>日期范围</th><th>确证暴发病例</th></tr>')
            for key, label in [('street_history', '同街道居住关联'), ('site_history', '同名小区候选/已核对地点'),
                               ('same_climate_history', '本库相同气候分箱'), ('site_and_climate_history', '该小区与相同气候交集')]:
                record = row.get(key)
                values = [label, *([_n(record.get(k)) for k in ('registered_cases', 'local', 'imported', 'unknown_or_conflict')] if record else ['未能匹配'] * 4),
                          (str(record.get('first_date')) + ' 至 ' + str(record.get('last_date'))) if record else '未知',
                          _n(record.get('confirmed_outbreak_cases')) if record else '未能核定']
                parts.append('<tr>' + ''.join('<td>' + _e(v) + '</td>' for v in values) + '</tr>')
            parts.append('</table>')
            if row.get('known_at_T'):
                parts.append('<p><strong>当时可知来源对照：</strong>' + _e(row['known_at_T']['note']) + '</p>')
                parts.append(_counts_table(row['known_at_T'], [('street_history', '同街道'), ('site_history', '同小区'), ('same_climate_history', '同气候'), ('site_and_climate_history', '小区∩气候')]))
            for inter in row.get('occupational_intersections', []):
                parts.append('<h4>职业交集：' + _e(inter['case_id']) + ' · ' + _e(inter.get('occupation_raw')) + '</h4>')
                for key, label in [('exact_occupation', '职业原词完全一致'), ('occupation_group', '同标准职业组')]:
                    parts.append('<p>' + label + '</p>')
                    parts.append(_counts_table(inter.get(key) or {}, [('history', '该职业'), ('street_history', '职业∩街道'), ('site_history', '职业∩小区'), ('climate_history', '职业∩气候'), ('street_and_climate_history', '职业∩街道∩气候'), ('site_and_climate_history', '职业∩小区∩气候')]))
                parts.append('<p>' + _e(inter.get('actual_exposure_note')) + '</p>')
            for check in row.get('self_exclusion', []):
                if check.get('status') != 'explicitly_excluded':
                    parts.append('<p>当前病例排除状态：' + _e(check.get('status')) + '；' + _e(check.get('note')) + '</p>')
            climate = row['climate']
            parts.append('<p>气候锚点：' + _e(climate['anchor_basis']) + '；' + _e(climate['window_start']) + ' 至 ' + _e(climate['window_end_exclusive']) + '（不含末日）。' +
                         ('均温 %.2f℃，累计雨量 %.1f毫米；%s。' % (climate['temperature_mean_14d_c'], climate['rainfall_14d_mm'], _e(climate['bin'].get('label') or climate['bin'].get('key'))) if climate['complete'] and climate.get('bin') else '该窗口缺完整同口径温雨，不计算相同气候病例数。') + '</p>')
            coverage = row['climate_coverage']
            parts.append(f'<p>历史气候覆盖：{coverage["cases_with_complete_weather"]}/{coverage["eligible_case_count"]}条；缺气候{coverage["cases_missing_weather"]}条。比较类型：{_e(climate["comparison_kind"])}。公共背景格点不等于小区实测，跨模型相似分箱只作描述性对照。</p>')
            for label, key in [('小区', 'site_history'), ('街道', 'street_history')]:
                win = (row.get(key) or {}).get('multi_case_windows')
                if win:
                    parts.append(f'<p>{label}历史多例时段：按报告日{win["days"]}日窗口筛查，达到{win["threshold"]}条门槛的窗口峰值{win["peak_count"]}条，涉及去重本地登记{win["unique_cases_in_windows"]}条。缺报告日期本地记录{win["missing_report_date_local_cases"]}条未进入窗口统计。重叠窗口不是多起暴发。</p>')
            if row['place_match'].get('candidates'):
                parts.append('<p>待核地点候选：' + '；'.join(_e(s['key'] + ' ' + s['name'] + ' ' + str(s.get('community') or '')) for s in row['place_match']['candidates']) + '。未选定前不把候选合计当该小区数量。</p>')
            candidate = row.get('imported_then_local_candidates')
            if candidate:
                groups = candidate.get('candidate_episode_groups') or {}
                overview = '；'.join(f"{d}日：{x['candidate_pair_count']}个时序配对／{x['candidate_episode_group_count']}组候选" for d, x in groups.items())
                parts.append('<p><strong>输入后本地线索检索：</strong>' + _e(overview or '场所未匹配，无法核定') + '。确证传播事件和续发人数未知。' + _e(candidate.get('note', '')) + '</p>')
            context = row.get('other_disease_environment_context')
            if context:
                parts.append('<details><summary>另一病种环境背景：' + _e(context['disease']) + '（不计入当前病种分子）</summary>' + _counts_table(context, [('street_history', '同街道'), ('site_history', '同名小区'), ('same_climate_history', '同气候')]) + '</details>')
        parts.append('<h3>工作类别与人群提示</h3><table><tr><th>病例/类别</th><th>历史本地/登记</th><th>实际暴露提示</th><th>核查要点</th></tr>')
        for p in comparison['person_comparisons']:
            o, g = p['occupation_history'], p['population_history']
            parts.append('<tr>' + ''.join('<td>' + _e(v) + '</td>' for v in [p['case_id'] + ' / ' + p['occupation_group'],
                         ('同工作类别' + (f"{o['local']}/{o['registered_cases']}" if o else '未知') + '；同年龄组') + (f"{g['local']}/{g['registered_cases']}" if g else '未知'), p['exposure_hint'], p['task'] + p['care_hint']]) + '</tr>')
        parts.append('</table><p>上述比例为病例内部来源构成，缺职业与年龄人口分母，不是该类人群发病率。历史负担与实际暴露提示不会自动覆盖当前媒介证据或改变正式响应。</p>')
    parts.append('<h2>与之前研判结果比较</h2>')
    if previous.get('rows'):
        for r in previous['rows']:
            parts.append(f'<p>{_e(r["site_name"])} {_e(r["disease"])}：{_e(r["previous_at"])}为{_e(r["previous_risk"])}/{_e(r["previous_priority"])}，本次为{_e(r["current_risk"])}/{_e(r["current_priority"])}。{_e(r["comparison_note"])}</p>')
            if r.get('changed_factors'):
                import json
                parts.append('<details><summary>变化依据：来源、数据、天气及版本</summary><pre style="white-space:pre-wrap">' + _e(json.dumps(r['changed_factors'], ensure_ascii=False, indent=2)) + '</pre></details>')
    else:
        parts.append('<p>在已登记结果目录中未匹配到此前同街道、同名场所的评估；这不等于没有历史病例。</p>')
    parts.append('<p>完整统计、数据范围和原表行号见 <a href="historical_comparison.json">历史比较证据</a>。</p>')
    return '\n'.join(parts)


def _counts_table(mapping, scopes):
    parts = ['<table><tr><th>范围</th><th>登记数</th><th>来源本地</th><th>来源输入</th><th>未定／冲突</th></tr>']
    for key, label in scopes:
        counts = mapping.get(key)
        values = [label] + ([_n(counts.get(k)) for k in ('registered_cases', 'local', 'imported', 'unknown_or_conflict')] if counts is not None else ['未能比较'] * 4)
        parts.append('<tr>' + ''.join('<td>' + _e(v) + '</td>' for v in values) + '</tr>')
    return '\n'.join(parts + ['</table>'])


def write_history_outputs(out, comparison, previous):
    write_json(out / 'historical_comparison.json', comparison)
    write_json(out / 'previous_result_comparison.json', previous)
    # Flatten all intersections and strict-T tables, preserving unknown vs zero.
    from .report import safe_csv
    with (out / 'historical_intersections.csv').open('w', encoding='utf-8-sig', newline='') as f:
        columns_all = ['site_id', 'disease', 'mode', 'case_id', 'occupation_match', 'scope', 'registered_cases', 'local', 'imported', 'unknown_or_conflict']
        writer_all = csv.DictWriter(f, columns_all); writer_all.writeheader()
        for row in comparison.get('site_comparisons', []):
            for mode, source in [('source_snapshot', row), ('known_at_T', row.get('known_at_T', {}))]:
                for item in source.get('occupational_intersections', []):
                    for match in ('exact_occupation', 'occupation_group'):
                        for scope, counts in (item.get(match) or {}).items():
                            writer_all.writerow({k: safe_csv(v) for k, v in dict(site_id=row['site_id'], disease=row['disease'], mode=mode, case_id=item['case_id'], occupation_match=match, scope=scope,
                                **{k: (counts or {}).get(k) for k in ('registered_cases', 'local', 'imported', 'unknown_or_conflict')}).items()})
    columns = ['site_id', 'site_name', 'street', 'disease', 'scope', 'cutoff_exclusive', 'registered_cases', 'local', 'imported', 'unknown_or_conflict', 'confirmed_outbreak_cases', 'match_status']
    with (out / 'historical_comparison.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, columns)
        writer.writeheader()
        for row in comparison.get('site_comparisons', []):
            for scope in ('street_history', 'site_history', 'same_climate_history', 'site_and_climate_history'):
                counts = row.get(scope) or {}
                item = {k: row.get(k) for k in ('site_id', 'site_name', 'street', 'disease', 'cutoff_exclusive')}
                item.update(scope=scope, match_status=row['place_match']['status'])
                for k in ('registered_cases', 'local', 'imported', 'unknown_or_conflict', 'confirmed_outbreak_cases'):
                    item[k] = counts.get(k) if counts.get(k) is not None else '未知'
                writer.writerow({k: "'" + str(v) if str(v).lstrip().startswith(('=', '+', '-', '@')) else v for k, v in item.items()})
