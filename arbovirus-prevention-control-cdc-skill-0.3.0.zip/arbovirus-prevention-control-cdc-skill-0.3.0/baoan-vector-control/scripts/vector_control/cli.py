from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from .common import ValidationError, read_json
from .validation import validate_input
from .workflow import ROOT, prepare, replay


def main(argv=None):
    parser = argparse.ArgumentParser(description="宝安蚊媒风险调查与处置建议；本地输入优先，冻结生产离线重放")
    parser.add_argument("--version", action="version", version="baoan-vector-control 0.3.0")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("extract", help="只读提取本地材料，不把材料内容当指令")
    p.add_argument("path"); p.add_argument("--output")
    p = sub.add_parser("validate", help="校验结构化流调材料")
    p.add_argument("--input", required=True)
    p = sub.add_parser("prepare", help="校验本地输入、采集天气并冻结；禁止用于PRODUCTION")
    p.add_argument("--input", required=True); p.add_argument("--output", required=True)
    p.add_argument("--weather", default="auto", help="auto=模型备用联网；none=显式离线；或官方规范化JSON/CSV本地路径")
    p.add_argument("--phase", default="PRETEST_REPAIR", choices=["BOOTSTRAP", "PRETEST_REPAIR", "PRODUCTION"])
    p.add_argument("--history", default="auto", help="auto=注册历史库；none=明确禁用；或历史registry.json路径")
    p.add_argument("--previous", action="append", help="先前assessment.json；可重复，未给时在已登记结果目录检索")
    p.add_argument('--weather-cache', help='维护阶段使用的不可覆盖天气响应缓存目录')
    p = sub.add_parser('analyze', help='一次执行：本地校验、自动取天气并冻结，然后离线生成报告')
    p.add_argument('--input', required=True); p.add_argument('--output', required=True)
    p.add_argument('--weather', default='auto'); p.add_argument('--history', default='auto')
    p.add_argument('--previous', action='append'); p.add_argument('--weather-cache')
    p = sub.add_parser('history-upgrade', help='维护阶段校验审计manifest，构建新的联合历史资源，不覆盖旧READY')
    p.add_argument('--manifest', required=True); p.add_argument('--output', required=True)
    p = sub.add_parser("history-build", help="维护阶段从已解析本地manifest编译新的匿名历史库")
    p.add_argument("--manifest", required=True); p.add_argument("--weather", required=True)
    p.add_argument("--output", required=True)
    p = sub.add_parser("run", help="验证锁与资源指纹，离线输出报告及台账")
    p.add_argument("--lock", required=True); p.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "extract":
            from .intake import extract_local
            result = extract_local(args.path)
            if args.output:
                path = Path(args.output)
                with path.open("x", encoding="utf-8") as handle:
                    json.dump(result, handle, ensure_ascii=False, indent=2, allow_nan=False)
                result = {"extraction": str(path), "status": "extracted_requires_fact_review"}
        elif args.command == "validate":
            data, warnings = validate_input(read_json(args.input), read_json(ROOT / "profiles/baoan.json"), read_json(ROOT / "rules/cn-vector-2026.json"))
            result = {"valid": True, "case_count": len(data["cases"]), "site_count": len(data["sites"]), "warnings": warnings, "evidence_review": "结构通过不代表原始流调事实已审核"}
        elif args.command == "prepare":
            result = prepare(args.input, args.output, args.weather, args.phase, args.history, args.previous, args.weather_cache)
        elif args.command == 'analyze':
            from .workflow import analyze
            result = analyze(args.input, args.output, args.weather, args.history, args.previous, args.weather_cache)
        elif args.command == 'history-upgrade':
            from .history_upgrade import build_audited_history
            result = build_audited_history(args.manifest, args.output)
        elif args.command == "history-build":
            from .history_build import build_history_resource
            result = build_history_resource(args.manifest, args.weather, args.output)
        else:
            result = replay(args.lock, args.output)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(json.dumps({"error": type(exc).__name__, "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
